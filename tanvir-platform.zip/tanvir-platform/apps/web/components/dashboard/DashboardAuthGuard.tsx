"use client";

import { useRouter } from "next/navigation";
import * as React from "react";

import { useAuth } from "@/lib/auth/AuthProvider";

/**
 * Protected-route wrapper foundation (Phase 2.7 §3, "the dashboard is
 * unusable and unsafe to build further without this in place first" —
 * Phase 2.8 §19 step 2).
 *
 * This sprint implements session-presence checking only (redirect to
 * /login if unauthenticated). Permission-level checks (RBAC — is this
 * user allowed to see this specific screen) are layered on once the
 * Users & Roles backend module and `require_permission`-equivalent
 * frontend checks exist (Sprint 2).
 */
export function DashboardAuthGuard({ children }: { children: React.ReactNode }) {
  const { session, loading } = useAuth();
  const router = useRouter();

  React.useEffect(() => {
    if (!loading && !session) {
      router.replace("/login");
    }
  }, [loading, session, router]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center text-body-sm text-neutral-400">
        Loading…
      </div>
    );
  }

  if (!session) return null;

  return <>{children}</>;
}
