"use client";

import { Drawer } from "@tanvir-platform/ui";
import Link from "next/link";
import { usePathname } from "next/navigation";
import * as React from "react";

import { NAV_ITEMS } from "@/lib/constants/nav";
import { useVisibleNavItems } from "@/lib/hooks/useCurrentUser";

/**
 * Mobile nav (Phase 2.4 §2 — "sidebar collapses to a slide-over drawer
 * below tablet width"). Reuses the Drawer primitive built earlier this
 * sprint and the same NAV_ITEMS source of truth as the desktop sidebar,
 * filtered by the current user's permissions so the two never diverge.
 */
export function MobileNav() {
  const [open, setOpen] = React.useState(false);
  const pathname = usePathname();
  const { items } = useVisibleNavItems(NAV_ITEMS);

  // Close automatically on route change so the drawer doesn't stay open
  // after navigating.
  React.useEffect(() => setOpen(false), [pathname]);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Open navigation menu"
        className="flex h-9 w-9 items-center justify-center rounded-sm text-neutral-600 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-2 md:hidden"
      >
        <span aria-hidden className="block h-0.5 w-5 bg-current relative before:absolute before:-top-1.5 before:h-0.5 before:w-5 before:bg-current after:absolute after:top-1.5 after:h-0.5 after:w-5 after:bg-current" />
      </button>

      <Drawer open={open} onClose={() => setOpen(false)} title="Tamvir Islam" side="left">
        <nav className="mt-4 flex flex-col gap-1" aria-label="Mobile dashboard navigation">
          {items.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-md px-2 py-2 text-body-sm text-neutral-700 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-1"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </Drawer>
    </>
  );
}
