"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import * as React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";

import { Button, FormField, Input } from "@tanvir-platform/ui";

import { AuthError } from "@/components/dashboard/states/AuthError";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

/**
 * Login form (Phase 3.1's core requirement). Email/password only, via
 * Supabase Auth directly — no custom credential handling on the backend
 * (Phase 2.8 §5). There is deliberately no "Sign up" link or public
 * registration path anywhere on this page or the surrounding (auth)
 * layout, per this sprint's explicit instruction; admin accounts are
 * created via Supabase invite (Phase 2.4 §10), not self-registration.
 */
const loginSchema = z.object({
  email: z.string().min(1, "Email is required").email("Enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export function LoginForm() {
  const router = useRouter();
  const [authError, setAuthError] = React.useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormValues>({ resolver: zodResolver(loginSchema) });

  async function onSubmit(values: LoginFormValues) {
    setAuthError(null);
    const supabase = createSupabaseBrowserClient();

    const { error } = await supabase.auth.signInWithPassword({
      email: values.email,
      password: values.password,
    });

    if (error) {
      // Deliberately generic — never confirms whether the email exists,
      // matching Phase 2.8 §5's enumeration-prevention rule.
      setAuthError("Incorrect email or password.");
      return;
    }

    router.replace("/dashboard");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col gap-4">
      {authError && <AuthError message={authError} />}

      <FormField label="Email" htmlFor="email" error={errors.email?.message}>
        <Input
          id="email"
          type="email"
          autoComplete="email"
          hasError={!!errors.email}
          {...register("email")}
        />
      </FormField>

      <FormField label="Password" htmlFor="password" error={errors.password?.message}>
        <Input
          id="password"
          type="password"
          autoComplete="current-password"
          hasError={!!errors.password}
          {...register("password")}
        />
      </FormField>

      <Button type="submit" loading={isSubmitting} disabled={isSubmitting} className="mt-2">
        Sign in
      </Button>
    </form>
  );
}
