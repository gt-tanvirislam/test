"use client";

import { Moon, Sun } from "lucide-react";

import { useTheme } from "@/lib/theme/ThemeProvider";

/**
 * Theme switch (Phase 2.4 §2's top bar spec, Phase 2.6 §12's "instant
 * switch, no page reload"). Reuses the ThemeProvider built in Sprint 0 —
 * no new theme logic here, only the UI control.
 */
export function ThemeSwitch() {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={theme === "light" ? "Switch to dark theme" : "Switch to light theme"}
      className="flex h-9 w-9 items-center justify-center rounded-sm text-neutral-500 transition-colors hover:bg-neutral-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/40 dark:text-text-dark-secondary dark:hover:bg-surface-dark-2"
    >
      {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
    </button>
  );
}
