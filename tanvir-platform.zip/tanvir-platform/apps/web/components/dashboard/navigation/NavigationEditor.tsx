"use client";

import type { Navigation, ReplaceNavigationInput } from "@tanvir-platform/types";
import { Button, Card, FormField, Input, Skeleton, useToast } from "@tanvir-platform/ui";
import { ArrowDown, ArrowUp, Plus, Trash2 } from "lucide-react";
import * as React from "react";

import { ApiError } from "@/lib/api/client";
import { useNavigation, useReplaceNavigation } from "@/lib/hooks/useNavigation";

interface LinkRow {
  label: string;
  url: string;
}

interface ColumnRow {
  title: string;
  items: LinkRow[];
}

interface FormState {
  header: LinkRow[];
  footer: ColumnRow[];
}

function toFormState(nav: Navigation): FormState {
  return {
    header: nav.header.map((h) => ({ label: h.label, url: h.url })),
    footer: nav.footer.map((c) => ({
      title: c.title,
      items: c.items.map((i) => ({ label: i.label, url: i.url })),
    })),
  };
}

/** Drop fully-blank rows/columns so an empty editor row never reaches the
 * backend validator (which requires non-empty label/url). Rows with either
 * field filled are kept so the backend surfaces the specific error. */
function toPayload(form: FormState): ReplaceNavigationInput {
  const cleanLinks = (rows: LinkRow[]) =>
    rows
      .map((r) => ({ label: r.label.trim(), url: r.url.trim() }))
      .filter((r) => r.label !== "" || r.url !== "");

  return {
    header: cleanLinks(form.header),
    footer: form.footer
      .map((c) => ({ title: c.title.trim(), items: cleanLinks(c.items) }))
      .filter((c) => c.title !== "" || c.items.length > 0),
  };
}

/** Move item at `index` by `delta` (±1) within an array, immutably. */
function move<T>(arr: T[], index: number, delta: number): T[] {
  const target = index + delta;
  if (target < 0 || target >= arr.length) return arr;
  const next = [...arr];
  [next[index], next[target]] = [next[target], next[index]];
  return next;
}

export function NavigationEditor() {
  const { data: nav, isLoading, isError } = useNavigation();
  const replace = useReplaceNavigation();
  const { showToast } = useToast();

  const [form, setForm] = React.useState<FormState | null>(null);

  React.useEffect(() => {
    if (nav && form === null) setForm(toFormState(nav));
  }, [nav, form]);

  if (isLoading || (form === null && !isError)) {
    return (
      <Card className="space-y-4">
        <Skeleton className="h-11 w-full" />
        <Skeleton className="h-11 w-full" />
        <Skeleton className="h-24 w-full" />
      </Card>
    );
  }

  if (isError || form === null) {
    return (
      <Card>
        <p className="text-body-sm text-error-500">
          We couldn&apos;t load the navigation. Please refresh and try again.
        </p>
      </Card>
    );
  }

  const state = form; // narrowed non-null for handlers below

  // ---- Header mutators ----------------------------------------------------
  const setHeader = (rows: LinkRow[]) => setForm({ ...state, header: rows });
  const setHeaderField = (i: number, key: keyof LinkRow, value: string) =>
    setHeader(state.header.map((r, idx) => (idx === i ? { ...r, [key]: value } : r)));
  const addHeader = () => setHeader([...state.header, { label: "", url: "" }]);
  const removeHeader = (i: number) => setHeader(state.header.filter((_, idx) => idx !== i));

  // ---- Footer mutators ----------------------------------------------------
  const setFooter = (cols: ColumnRow[]) => setForm({ ...state, footer: cols });
  const setColumnTitle = (ci: number, title: string) =>
    setFooter(state.footer.map((c, idx) => (idx === ci ? { ...c, title } : c)));
  const addColumn = () => setFooter([...state.footer, { title: "", items: [] }]);
  const removeColumn = (ci: number) => setFooter(state.footer.filter((_, idx) => idx !== ci));
  const setColumnLink = (ci: number, li: number, key: keyof LinkRow, value: string) =>
    setFooter(
      state.footer.map((c, idx) =>
        idx === ci
          ? { ...c, items: c.items.map((r, ridx) => (ridx === li ? { ...r, [key]: value } : r)) }
          : c
      )
    );
  const addColumnLink = (ci: number) =>
    setFooter(
      state.footer.map((c, idx) => (idx === ci ? { ...c, items: [...c.items, { label: "", url: "" }] } : c))
    );
  const removeColumnLink = (ci: number, li: number) =>
    setFooter(
      state.footer.map((c, idx) =>
        idx === ci ? { ...c, items: c.items.filter((_, ridx) => ridx !== li) } : c
      )
    );

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await replace.mutateAsync(toPayload(state));
      showToast("Navigation saved");
    } catch (err) {
      if (err instanceof ApiError) {
        showToast(err.message || "Please check the highlighted values and try again.", "error");
      } else {
        showToast("Couldn't save navigation. Check your connection and try again.", "error");
      }
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Header menu */}
      <Card className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-card-title font-semibold text-neutral-800 dark:text-text-dark-primary">
              Header menu
            </h3>
            <p className="mt-1 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
              The primary navigation shown in the site header. URLs are site paths (e.g. <code>/about</code>)
              or absolute links.
            </p>
          </div>
          <Button type="button" variant="secondary" size="sm" onClick={addHeader}>
            <Plus size={16} /> Add link
          </Button>
        </div>

        {state.header.length === 0 ? (
          <p className="text-body-sm text-neutral-400">No header links yet.</p>
        ) : (
          <ul className="space-y-3">
            {state.header.map((row, i) => (
              <li key={i} className="flex items-start gap-2">
                <div className="w-44 shrink-0">
                  <Input
                    aria-label={`Header link ${i + 1} label`}
                    value={row.label}
                    onChange={(e) => setHeaderField(i, "label", e.target.value)}
                    placeholder="About"
                    maxLength={120}
                  />
                </div>
                <div className="flex-1">
                  <Input
                    aria-label={`Header link ${i + 1} URL`}
                    value={row.url}
                    onChange={(e) => setHeaderField(i, "url", e.target.value)}
                    placeholder="/about"
                    maxLength={500}
                  />
                </div>
                <Button type="button" variant="tertiary" size="sm" onClick={() => setHeader(move(state.header, i, -1))} aria-label={`Move header link ${i + 1} up`} disabled={i === 0}>
                  <ArrowUp size={16} />
                </Button>
                <Button type="button" variant="tertiary" size="sm" onClick={() => setHeader(move(state.header, i, 1))} aria-label={`Move header link ${i + 1} down`} disabled={i === state.header.length - 1}>
                  <ArrowDown size={16} />
                </Button>
                <Button type="button" variant="tertiary" size="sm" onClick={() => removeHeader(i)} aria-label={`Remove header link ${i + 1}`}>
                  <Trash2 size={16} />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* Footer columns */}
      <Card className="space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-card-title font-semibold text-neutral-800 dark:text-text-dark-primary">
              Footer columns
            </h3>
            <p className="mt-1 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
              Each column has a title and a list of links, shown in the site footer.
            </p>
          </div>
          <Button type="button" variant="secondary" size="sm" onClick={addColumn}>
            <Plus size={16} /> Add column
          </Button>
        </div>

        {state.footer.length === 0 ? (
          <p className="text-body-sm text-neutral-400">No footer columns yet.</p>
        ) : (
          <div className="space-y-5">
            {state.footer.map((column, ci) => (
              <div
                key={ci}
                className="rounded-md border border-neutral-200 p-4 dark:border-surface-dark-border"
              >
                <div className="flex items-end gap-2">
                  <div className="flex-1">
                    <FormField label={`Column ${ci + 1} title`} htmlFor={`col-${ci}-title`}>
                      <Input
                        id={`col-${ci}-title`}
                        value={column.title}
                        onChange={(e) => setColumnTitle(ci, e.target.value)}
                        placeholder="Site"
                        maxLength={120}
                      />
                    </FormField>
                  </div>
                  <Button type="button" variant="tertiary" size="sm" onClick={() => setFooter(move(state.footer, ci, -1))} aria-label={`Move column ${ci + 1} up`} disabled={ci === 0}>
                    <ArrowUp size={16} />
                  </Button>
                  <Button type="button" variant="tertiary" size="sm" onClick={() => setFooter(move(state.footer, ci, 1))} aria-label={`Move column ${ci + 1} down`} disabled={ci === state.footer.length - 1}>
                    <ArrowDown size={16} />
                  </Button>
                  <Button type="button" variant="tertiary" size="sm" onClick={() => removeColumn(ci)} aria-label={`Remove column ${ci + 1}`}>
                    <Trash2 size={16} />
                  </Button>
                </div>

                <div className="mt-3 space-y-2 border-t border-neutral-100 pt-3 dark:border-surface-dark-border/60">
                  {column.items.length === 0 ? (
                    <p className="text-body-sm text-neutral-400">No links in this column yet.</p>
                  ) : (
                    <ul className="space-y-2">
                      {column.items.map((link, li) => (
                        <li key={li} className="flex items-start gap-2">
                          <div className="w-40 shrink-0">
                            <Input
                              aria-label={`Column ${ci + 1} link ${li + 1} label`}
                              value={link.label}
                              onChange={(e) => setColumnLink(ci, li, "label", e.target.value)}
                              placeholder="About"
                              maxLength={120}
                            />
                          </div>
                          <div className="flex-1">
                            <Input
                              aria-label={`Column ${ci + 1} link ${li + 1} URL`}
                              value={link.url}
                              onChange={(e) => setColumnLink(ci, li, "url", e.target.value)}
                              placeholder="/about"
                              maxLength={500}
                            />
                          </div>
                          <Button type="button" variant="tertiary" size="sm" onClick={() => removeColumnLink(ci, li)} aria-label={`Remove column ${ci + 1} link ${li + 1}`}>
                            <Trash2 size={16} />
                          </Button>
                        </li>
                      ))}
                    </ul>
                  )}
                  <Button type="button" variant="tertiary" size="sm" onClick={() => addColumnLink(ci)}>
                    <Plus size={16} /> Add link
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <div className="flex justify-end">
        <Button type="submit" loading={replace.isPending}>
          Save changes
        </Button>
      </div>
    </form>
  );
}
