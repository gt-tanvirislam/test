"use client";

import { usePathname } from "next/navigation";
import Link from "next/link";
import { ChevronRight } from "lucide-react";
import * as React from "react";

/**
 * Breadcrumb (Phase 2.5 §3.1). Derives segments from the pathname rather
 * than requiring each dashboard page to declare its own breadcrumb array
 * — a reasonable default for this sprint's placeholder pages; a future
 * sprint can override labels per-route (e.g. showing a post title instead
 * of a raw id segment) once real content exists to look up.
 */
export function Breadcrumb() {
  const pathname = usePathname();
  const segments = pathname.split("/").filter(Boolean);

  if (segments.length <= 1) return null;

  return (
    <nav aria-label="Breadcrumb" className="mb-4 flex items-center gap-1 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
      {segments.map((segment, index) => {
        const href = "/" + segments.slice(0, index + 1).join("/");
        const isLast = index === segments.length - 1;
        const label = segment.charAt(0).toUpperCase() + segment.slice(1).replace(/-/g, " ");

        return (
          <React.Fragment key={href}>
            {index > 0 && <ChevronRight size={14} aria-hidden />}
            {isLast ? (
              <span aria-current="page" className="text-neutral-800 dark:text-text-dark-primary">
                {label}
              </span>
            ) : (
              <Link href={href} className="hover:text-neutral-800 dark:hover:text-text-dark-primary">
                {label}
              </Link>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
}
