"use client";

import { LogOut } from "lucide-react";
import * as React from "react";

import { createSupabaseBrowserClient } from "@/lib/supabase/client";
import { useCurrentUser } from "@/lib/hooks/useCurrentUser";

/**
 * User menu (Phase 2.4 §2's top bar spec). Session presence already
 * comes from AuthProvider (Sprint 0); this sprint adds the real logout
 * action and displays the resolved backend user (name/email) rather than
 * just "logged in."
 */
export function UserMenu() {
  const { user } = useCurrentUser();
  const [open, setOpen] = React.useState(false);
  const menuRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  async function handleLogout() {
    const supabase = createSupabaseBrowserClient();
    await supabase.auth.signOut();
    window.location.href = "/login";
  }

  const initials = user?.full_name
    ? user.full_name
        .split(" ")
        .map((part) => part[0])
        .slice(0, 2)
        .join("")
        .toUpperCase()
    : "…";

  return (
    <div ref={menuRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label="User menu"
        className="flex h-9 w-9 items-center justify-center rounded-full bg-accent-500 text-caption font-medium text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/40"
      >
        {initials}
      </button>

      {open && (
        <div
          role="menu"
          className="absolute right-0 top-11 z-dropdown w-56 rounded-md border border-neutral-200 bg-neutral-0 p-2 shadow-md dark:border-surface-dark-border dark:bg-surface-dark-2"
        >
          <div className="px-2 py-1.5">
            <p className="text-body-sm font-medium text-neutral-800 dark:text-text-dark-primary">
              {user?.full_name ?? "Loading…"}
            </p>
            <p className="text-caption text-neutral-500 dark:text-text-dark-secondary">{user?.email}</p>
          </div>
          <div className="my-1 h-px bg-neutral-200 dark:bg-surface-dark-border" />
          <button
            type="button"
            role="menuitem"
            onClick={handleLogout}
            className="flex w-full items-center gap-2 rounded-sm px-2 py-2 text-left text-body-sm text-neutral-700 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-1"
          >
            <LogOut size={16} />
            Log out
          </button>
        </div>
      )}
    </div>
  );
}
