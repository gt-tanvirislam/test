"use client";

import type { MediaAsset, Service, ServiceListItemInput } from "@tanvir-platform/types";
import { Input, Label, Skeleton, Tabs, TabsContent, TabsList, TabsTrigger, useToast } from "@tanvir-platform/ui";
import * as React from "react";

import {
  AutosaveIndicator,
  ContentEditorShell,
  emptySeoPanelValues,
  ExcerptField,
  FeaturedImageField,
  GalleryField,
  PublishPanel,
  RichTextField,
  SeoPanel,
  ServiceListItemsField,
  TagInput,
  TitleSlugFields,
} from "@/components/features/content-editor";
import type { SeoPanelValues } from "@/components/features/content-editor";
import { CategorySelectField } from "@/components/features/taxonomy";
import { AuthorSelect } from "@/components/features/users";
import { useAutosave } from "@/lib/hooks/useAutosave";
import { useTags } from "@/lib/hooks/useBlog";
import { useMediaAsset } from "@/lib/hooks/useMedia";
import {
  useCheckServiceSlugAvailability,
  useCreateServiceCategory,
  useServiceCategories,
  useServiceGallery,
  useServiceLifecycle,
  useSetServiceBenefits,
  useSetServiceFeatures,
  useSetServiceGallery,
  useSetServiceProcessSteps,
  useUpdateService,
} from "@/lib/hooks/useServices";

export interface ServiceEditorProps {
  service: Service;
}

/**
 * ServiceEditor — the third reference composition (Sprint 8). Structurally
 * identical to Blog/PortfolioEditor for every shared field; the
 * genuinely new part is mounting ServiceListItemsField three times
 * (Features/Benefits/Process) against the same unified backend table.
 */
export function ServiceEditor({ service }: ServiceEditorProps) {
  const { showToast } = useToast();

  const [title, setTitle] = React.useState(service.title);
  const [slug, setSlug] = React.useState(service.slug);
  const [shortDescription, setShortDescription] = React.useState(service.short_description ?? "");
  const [fullDescription, setFullDescription] = React.useState(service.full_description);
  const [categoryId, setCategoryId] = React.useState<string | null>(service.category_id);
  const [tagNames, setTagNames] = React.useState<string[]>(service.tags.map((t) => t.name));
  const [featuredImage, setFeaturedImage] = React.useState<MediaAsset | null>(null);
  const [galleryAssets, setGalleryAssets] = React.useState<MediaAsset[]>([]);
  const [iconKey, setIconKey] = React.useState(service.icon_key ?? "");
  const [pricingText, setPricingText] = React.useState(service.pricing_text ?? "");
  const [deliveryTime, setDeliveryTime] = React.useState(service.delivery_time ?? "");
  const [ctaText, setCtaText] = React.useState(service.cta_text ?? "");
  const [ctaLink, setCtaLink] = React.useState(service.cta_link ?? "");
  const [sortOrder, setSortOrder] = React.useState(service.sort_order);
  const [features, setFeatures] = React.useState<ServiceListItemInput[]>(
    service.list_items.filter((i) => i.item_type === "feature").map(({ title, description }) => ({ title, description }))
  );
  const [benefits, setBenefits] = React.useState<ServiceListItemInput[]>(
    service.list_items.filter((i) => i.item_type === "benefit").map(({ title, description }) => ({ title, description }))
  );
  const [processSteps, setProcessSteps] = React.useState<ServiceListItemInput[]>(
    service.list_items.filter((i) => i.item_type === "process_step").map(({ title, description }) => ({ title, description }))
  );
  const [seo, setSeo] = React.useState<SeoPanelValues>(emptySeoPanelValues);
  const [ogImage, setOgImage] = React.useState<MediaAsset | null>(null);
  const [authorId, setAuthorId] = React.useState<string>(service.author_id);

  const { data: hydratedFeaturedImage } = useMediaAsset(service.featured_image_id);
  React.useEffect(() => {
    if (hydratedFeaturedImage) setFeaturedImage(hydratedFeaturedImage);
  }, [hydratedFeaturedImage]);

  const { data: hydratedGallery } = useServiceGallery(service.id);
  React.useEffect(() => {
    if (hydratedGallery) setGalleryAssets(hydratedGallery);
  }, [hydratedGallery]);

  const { data: categories = [] } = useServiceCategories();
  const { data: allTags = [] } = useTags();
  const createCategory = useCreateServiceCategory();
  const updateService = useUpdateService(service.id);
  const lifecycle = useServiceLifecycle(service.id);
  const checkSlugAvailability = useCheckServiceSlugAvailability(service.id);
  const setGallery = useSetServiceGallery(service.id);
  const setFeaturesMutation = useSetServiceFeatures(service.id);
  const setBenefitsMutation = useSetServiceBenefits(service.id);
  const setProcessMutation = useSetServiceProcessSteps(service.id);

  const autosavePayload = React.useMemo(
    () => ({
      title, slug, short_description: shortDescription, full_description: fullDescription,
      category_id: categoryId, tag_names: tagNames, author_id: authorId,
      icon_key: iconKey || null, pricing_text: pricingText || null, delivery_time: deliveryTime || null,
      cta_text: ctaText || null, cta_link: ctaLink || null, sort_order: sortOrder,
    }),
    [title, slug, shortDescription, fullDescription, categoryId, tagNames, authorId, iconKey,
     pricingText, deliveryTime, ctaText, ctaLink, sortOrder]
  );

  const { status: autosaveStatus, lastSavedAt } = useAutosave({
    data: autosavePayload,
    onSave: async (data) => {
      try {
        await updateService.mutateAsync(data);
      } catch {
        showToast("Couldn't save your changes", "error");
        throw new Error("autosave failed");
      }
    },
  });

  async function handleSaveDraft() {
    try {
      await updateService.mutateAsync(autosavePayload);
      showToast("Draft saved");
    } catch {
      showToast("Couldn't save the draft", "error");
    }
  }

  async function runLifecycleAction(action: () => Promise<unknown>, successMessage: string) {
    try {
      await action();
      showToast(successMessage);
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Something went wrong", "error");
    }
  }

  function handleGalleryChange(assets: MediaAsset[]) {
    setGalleryAssets(assets);
    setGallery.mutate(assets.map((a) => a.id));
  }

  function handleFeaturesChange(items: ServiceListItemInput[]) {
    setFeatures(items);
    setFeaturesMutation.mutate(items.filter((i) => i.title.trim()));
  }
  function handleBenefitsChange(items: ServiceListItemInput[]) {
    setBenefits(items);
    setBenefitsMutation.mutate(items.filter((i) => i.title.trim()));
  }
  function handleProcessChange(items: ServiceListItemInput[]) {
    setProcessSteps(items);
    setProcessMutation.mutate(items.filter((i) => i.title.trim()));
  }

  return (
    <ContentEditorShell
      title={service.title || "New service"}
      saveBar={<AutosaveIndicator status={autosaveStatus} lastSavedAt={lastSavedAt} />}
      mainPanel={
        <div className="flex flex-col gap-6">
          <TitleSlugFields
            title={title}
            onTitleChange={setTitle}
            slug={slug}
            onSlugChange={setSlug}
            urlPrefix="/services"
            initialSlug={service.slug}
            checkSlugAvailability={checkSlugAvailability}
          />
          <ExcerptField value={shortDescription} onChange={setShortDescription} />
          <RichTextField value={fullDescription} onChange={setFullDescription} label="Full description" />

          <ServiceListItemsField label="Features" value={features} onChange={handleFeaturesChange} />
          <ServiceListItemsField label="Benefits" value={benefits} onChange={handleBenefitsChange} />
          <ServiceListItemsField
            label="Process"
            value={processSteps}
            onChange={handleProcessChange}
            placeholder="Step title"
          />

          <GalleryField value={galleryAssets} onChange={handleGalleryChange} />
        </div>
      }
      sidebarPanel={
        <Tabs defaultTab="content">
          <TabsList>
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="seo">SEO</TabsTrigger>
          </TabsList>

          <TabsContent value="content">
            <div className="flex flex-col gap-4">
              <PublishPanel
                status={service.status}
                scheduledAt={service.scheduled_at}
                isSaving={updateService.isPending}
                onSaveDraft={handleSaveDraft}
                onPublish={() => runLifecycleAction(() => lifecycle.publish.mutateAsync(), "Service published")}
                onUnpublish={() => runLifecycleAction(() => lifecycle.unpublish.mutateAsync(), "Service unpublished")}
                onSchedule={(iso) => runLifecycleAction(() => lifecycle.schedule.mutateAsync(iso), "Service scheduled")}
                onArchive={() => runLifecycleAction(() => lifecycle.archive.mutateAsync(), "Service archived")}
                onRestore={() => runLifecycleAction(() => lifecycle.restore.mutateAsync(), "Service restored to draft")}
              />

              {service.featured_image_id && !featuredImage ? (
                <Skeleton className="aspect-video w-full" />
              ) : (
                <FeaturedImageField value={featuredImage} onChange={setFeaturedImage} />
              )}

              <AuthorSelect value={authorId} onChange={(id) => id && setAuthorId(id)} mode="assign" />

              <CategorySelectField
                categories={categories}
                value={categoryId}
                onChange={setCategoryId}
                onCreateCategory={(name) => createCategory.mutateAsync({ name })}
                isCreating={createCategory.isPending}
              />

              <TagInput label="Tags" value={tagNames} onChange={setTagNames} suggestions={allTags.map((t) => t.name)} />
            </div>
          </TabsContent>

          <TabsContent value="details">
            <div className="flex flex-col gap-4">
              <div>
                <Label htmlFor="icon-key">Icon (Lucide icon name)</Label>
                <Input id="icon-key" value={iconKey} onChange={(e) => setIconKey(e.target.value)} placeholder="e.g. Video, Image, Palette" />
              </div>
              <div>
                <Label htmlFor="pricing-text">Pricing</Label>
                <Input id="pricing-text" value={pricingText} onChange={(e) => setPricingText(e.target.value)} placeholder="e.g. Custom quote based on scope" />
              </div>
              <div>
                <Label htmlFor="delivery-time">Delivery time</Label>
                <Input id="delivery-time" value={deliveryTime} onChange={(e) => setDeliveryTime(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="sort-order">Display priority (lower shows first)</Label>
                <Input
                  id="sort-order"
                  type="number"
                  value={sortOrder}
                  onChange={(e) => setSortOrder(Number(e.target.value) || 0)}
                />
              </div>
              <div>
                <Label htmlFor="cta-text">CTA text</Label>
                <Input id="cta-text" value={ctaText} onChange={(e) => setCtaText(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="cta-link">CTA link</Label>
                <Input id="cta-link" value={ctaLink} onChange={(e) => setCtaLink(e.target.value)} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="seo">
            <SeoPanel
              values={seo}
              onChange={setSeo}
              ogImage={ogImage}
              onOgImageChange={setOgImage}
              fallbackTitle={title}
              fallbackDescription={shortDescription}
            />
          </TabsContent>
        </Tabs>
      }
    />
  );
}
