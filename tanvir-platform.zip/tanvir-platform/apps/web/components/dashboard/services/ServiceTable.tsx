"use client";

import type { ServiceListItemSlim } from "@tanvir-platform/types";
import { Badge, Button, Table, TableBody, TableCell, TableHead, TableHeaderCell, TableRow } from "@tanvir-platform/ui";
import type { BadgeProps } from "@tanvir-platform/ui";
import Link from "next/link";

const STATUS_TONE: Record<string, NonNullable<BadgeProps["tone"]>> = {
  draft: "neutral",
  scheduled: "warning",
  published: "success",
  archived: "error",
};

export interface ServiceTableProps {
  items: ServiceListItemSlim[];
  selectedIds: string[];
  onSelectionChange: (ids: string[]) => void;
  onDelete: (id: string) => void;
}

/** Mirrors PortfolioTable's shape exactly (Sprint 6/8). */
export function ServiceTable({ items, selectedIds, onSelectionChange, onDelete }: ServiceTableProps) {
  const allSelected = items.length > 0 && selectedIds.length === items.length;

  function toggleAll() {
    onSelectionChange(allSelected ? [] : items.map((i) => i.id));
  }

  function toggleOne(id: string) {
    onSelectionChange(selectedIds.includes(id) ? selectedIds.filter((i) => i !== id) : [...selectedIds, id]);
  }

  return (
    <Table>
      <TableHead>
        <tr>
          <TableHeaderCell className="w-10">
            <input
              type="checkbox"
              checked={allSelected}
              onChange={toggleAll}
              aria-label="Select all services"
              className="h-4 w-4 rounded-sm border-neutral-300 text-accent-500"
            />
          </TableHeaderCell>
          <TableHeaderCell>Title</TableHeaderCell>
          <TableHeaderCell>Status</TableHeaderCell>
          <TableHeaderCell>Category</TableHeaderCell>
          <TableHeaderCell>Priority</TableHeaderCell>
          <TableHeaderCell>Updated</TableHeaderCell>
          <TableHeaderCell className="w-20">Actions</TableHeaderCell>
        </tr>
      </TableHead>
      <TableBody>
        {items.map((item) => (
          <TableRow key={item.id}>
            <TableCell>
              <input
                type="checkbox"
                checked={selectedIds.includes(item.id)}
                onChange={() => toggleOne(item.id)}
                aria-label={`Select ${item.title}`}
                className="h-4 w-4 rounded-sm border-neutral-300 text-accent-500"
              />
            </TableCell>
            <TableCell>
              <Link
                href={`/dashboard/services/${item.id}/edit`}
                className="font-medium text-neutral-800 hover:text-accent-500 dark:text-text-dark-primary"
              >
                {item.title}
              </Link>
              {item.featured && (
                <Badge tone="accent" className="ml-2">
                  Featured
                </Badge>
              )}
            </TableCell>
            <TableCell>
              <Badge tone={STATUS_TONE[item.status]}>{item.status}</Badge>
            </TableCell>
            <TableCell>{item.category?.name ?? "—"}</TableCell>
            <TableCell>{item.sort_order}</TableCell>
            <TableCell>{new Date(item.updated_at).toLocaleDateString()}</TableCell>
            <TableCell>
              <Button variant="tertiary" size="sm" onClick={() => onDelete(item.id)}>
                Delete
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
