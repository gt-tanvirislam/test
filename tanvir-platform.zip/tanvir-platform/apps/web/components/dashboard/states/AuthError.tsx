import { AlertCircle } from "lucide-react";

/**
 * Inline authentication error (this sprint's §8). Used directly in the
 * login form (app/(auth)/login/page.tsx) — deliberately not a full-page
 * state like AccessDenied/SessionExpired, since a failed login attempt
 * should keep the person on the form, not redirect them away from it.
 */
export function AuthError({ message }: { message: string }) {
  return (
    <div
      role="alert"
      className="flex items-start gap-2 rounded-sm border border-error-500/30 bg-error-50 px-3 py-2.5 text-body-sm text-error-500"
    >
      <AlertCircle size={16} className="mt-0.5 shrink-0" aria-hidden />
      <span>{message}</span>
    </div>
  );
}
