import { Clock } from "lucide-react";

import { Button, EmptyState } from "@tanvir-platform/ui";

/**
 * Session Expired state — shown when an API call returns UNAUTHORIZED
 * for a previously-authenticated user (token expired mid-session, as
 * opposed to never having logged in, which redirects via
 * DashboardAuthGuard instead). Wired into real API error handling once
 * content modules make authenticated calls that can actually expire
 * mid-session (future sprint).
 */
export function SessionExpired() {
  return (
    <EmptyState
      icon={<Clock size={28} />}
      title="Your session has expired"
      description="For your security, you've been signed out. Sign in again to continue."
      action={
        <Button onClick={() => (window.location.href = "/login")}>Sign in again</Button>
      }
    />
  );
}
