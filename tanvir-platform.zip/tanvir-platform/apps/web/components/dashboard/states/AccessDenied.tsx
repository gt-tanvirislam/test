import { ShieldAlert } from "lucide-react";

import { EmptyState } from "@tanvir-platform/ui";

/**
 * Access Denied state (this sprint's §8 requirement). Distinct from 404 —
 * the route exists, the user is authenticated, but their role/permissions
 * don't allow it. Used once permission-gated dashboard screens exist
 * (future sprint); the component itself is ready now.
 */
export function AccessDenied({ requiredPermission }: { requiredPermission?: string }) {
  return (
    <EmptyState
      icon={<ShieldAlert size={28} />}
      title="You don't have access to this page"
      description={
        requiredPermission
          ? `This requires the "${requiredPermission}" permission. Contact an administrator if you believe this is a mistake.`
          : "Contact an administrator if you believe this is a mistake."
      }
    />
  );
}
