"use client";

import type { MediaAsset } from "@tanvir-platform/types";
import { Button, Drawer, FormField, Input } from "@tanvir-platform/ui";
import { formatBytes } from "@tanvir-platform/utils";
import * as React from "react";

import { useDeleteMediaAsset, useUpdateMediaAsset } from "@/lib/hooks/useMedia";

interface MediaAssetDrawerProps {
  asset: MediaAsset | null;
  onClose: () => void;
}

/**
 * Asset detail drawer (Phase 2.4 §8): preview, alt text edit, "Copy URL,"
 * delete — blocked with a clear message if the backend reports the asset
 * is in use (Phase 2.3 §8's CONFLICT response), consistent with "prevent
 * before-confirm deletion of in-use assets" rather than a silent failure.
 */
export function MediaAssetDrawer({ asset, onClose }: MediaAssetDrawerProps) {
  const [altText, setAltText] = React.useState(asset?.alt_text ?? "");
  const [deleteError, setDeleteError] = React.useState<string | null>(null);
  const [copied, setCopied] = React.useState(false);

  const updateAsset = useUpdateMediaAsset();
  const deleteAsset = useDeleteMediaAsset();

  React.useEffect(() => {
    setAltText(asset?.alt_text ?? "");
    setDeleteError(null);
  }, [asset]);

  if (!asset) return null;

  async function handleSave() {
    if (!asset) return;
    await updateAsset.mutateAsync({ assetId: asset.id, altText });
  }

  async function handleDelete() {
    if (!asset) return;
    setDeleteError(null);
    try {
      await deleteAsset.mutateAsync(asset.id);
      onClose();
    } catch {
      setDeleteError(
        "This file is used elsewhere and can't be deleted yet. Remove it from that content first."
      );
    }
  }

  function handleCopyUrl() {
    if (!asset) return;
    navigator.clipboard.writeText(asset.public_url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <Drawer open={!!asset} onClose={onClose} title={asset.file_name}>
      <div className="flex flex-col gap-4">
        {asset.mime_type.startsWith("image/") && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={asset.public_url} alt={asset.alt_text ?? ""} className="w-full rounded-md" />
        )}

        <dl className="grid grid-cols-2 gap-y-1 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
          <dt>Type</dt>
          <dd className="text-neutral-800 dark:text-text-dark-primary">{asset.mime_type}</dd>
          <dt>Size</dt>
          <dd className="text-neutral-800 dark:text-text-dark-primary">
            {formatBytes(asset.file_size_bytes)}
          </dd>
          {asset.width && asset.height && (
            <>
              <dt>Dimensions</dt>
              <dd className="text-neutral-800 dark:text-text-dark-primary">
                {asset.width} × {asset.height}
              </dd>
            </>
          )}
        </dl>

        {asset.mime_type.startsWith("image/") && (
          <FormField label="Alt text" htmlFor="drawer-alt-text">
            <Input id="drawer-alt-text" value={altText} onChange={(e) => setAltText(e.target.value)} />
          </FormField>
        )}

        <div className="flex gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={handleSave}
            loading={updateAsset.isPending}
            disabled={updateAsset.isPending || altText === asset.alt_text}
          >
            Save changes
          </Button>
          <Button variant="secondary" size="sm" onClick={handleCopyUrl}>
            {copied ? "Copied" : "Copy URL"}
          </Button>
        </div>

        <div className="mt-2 border-t border-neutral-200 pt-4 dark:border-surface-dark-border">
          {deleteError && <p className="mb-2 text-body-sm text-error-500">{deleteError}</p>}
          <Button
            variant="destructive"
            size="sm"
            onClick={handleDelete}
            loading={deleteAsset.isPending}
            disabled={deleteAsset.isPending}
          >
            Delete file
          </Button>
        </div>
      </div>
    </Drawer>
  );
}
