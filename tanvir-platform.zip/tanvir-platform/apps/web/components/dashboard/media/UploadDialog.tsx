"use client";

import { Button, FormField, Input, Modal } from "@tanvir-platform/ui";
import * as React from "react";

import { useUploadMedia } from "@/lib/hooks/useMedia";

interface UploadDialogProps {
  file: File | null;
  onClose: () => void;
}

/**
 * Upload confirmation dialog (Phase 2.4 §8). Collects alt text before
 * submitting for image files — the backend rejects an image confirm
 * without alt text (Phase 2.2 §4.5's SEO enforcement), so this dialog
 * makes that requirement visible at the moment of upload rather than
 * surfacing it as a confusing API error afterward.
 */
export function UploadDialog({ file, onClose }: UploadDialogProps) {
  const [altText, setAltText] = React.useState("");
  const [error, setError] = React.useState<string | null>(null);
  const upload = useUploadMedia();

  const isImage = file?.type.startsWith("image/");

  React.useEffect(() => {
    setAltText("");
    setError(null);
  }, [file]);

  async function handleUpload() {
    if (!file) return;
    if (isImage && !altText.trim()) {
      setError("Alt text is required for images.");
      return;
    }

    try {
      await upload.mutateAsync({ file, altText: altText.trim() || undefined });
      onClose();
    } catch {
      setError("Upload failed. Please try again.");
    }
  }

  return (
    <Modal open={!!file} onClose={onClose} title="Upload file">
      {file && (
        <div className="flex flex-col gap-4">
          <p className="text-body-sm text-neutral-600 dark:text-text-dark-secondary">{file.name}</p>

          {isImage && (
            <FormField label="Alt text" htmlFor="alt-text" error={error ?? undefined}>
              <Input
                id="alt-text"
                value={altText}
                onChange={(e) => setAltText(e.target.value)}
                placeholder="Describe the image for accessibility and SEO"
                hasError={!!error}
              />
            </FormField>
          )}

          {!isImage && error && <p className="text-body-sm text-error-500">{error}</p>}

          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={onClose} disabled={upload.isPending}>
              Cancel
            </Button>
            <Button onClick={handleUpload} loading={upload.isPending} disabled={upload.isPending}>
              Upload
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}
