"use client";

import { Button } from "@tanvir-platform/ui";
import { Upload } from "lucide-react";
import * as React from "react";

interface MediaUploadButtonProps {
  onFileSelected: (file: File) => void;
}

/** Upload trigger (Phase 2.4 §8 — "drag multiple files onto the grid" is
 * the fuller future interaction; this sprint implements single-file
 * click-to-upload as the functional baseline, with drag-and-drop as a
 * clearly scoped follow-up rather than a partially-working attempt now). */
export function MediaUploadButton({ onFileSelected }: MediaUploadButtonProps) {
  const inputRef = React.useRef<HTMLInputElement>(null);

  return (
    <>
      <Button onClick={() => inputRef.current?.click()}>
        <Upload size={16} />
        Upload file
      </Button>
      <input
        ref={inputRef}
        type="file"
        accept="image/*,video/*,application/pdf"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onFileSelected(file);
          e.target.value = ""; // allow re-selecting the same file later
        }}
      />
    </>
  );
}
