"use client";

import type { MediaAsset } from "@tanvir-platform/types";
import { FileText, Video } from "lucide-react";

interface MediaGridProps {
  assets: MediaAsset[];
  onSelect: (asset: MediaAsset) => void;
}

/**
 * Media grid (Phase 2.4 §8). Hover-preview and folder-tree filtering are
 * layered on incrementally; this sprint's grid renders real uploaded
 * assets with type-appropriate previews and opens the detail drawer on
 * click — the core loop the rest of Phase 2.4 §8 builds on top of.
 */
export function MediaGrid({ assets, onSelect }: MediaGridProps) {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
      {assets.map((asset) => (
        <button
          key={asset.id}
          type="button"
          onClick={() => onSelect(asset)}
          className="group flex aspect-square flex-col items-center justify-center overflow-hidden rounded-md border border-neutral-200 bg-neutral-50 transition-shadow hover:shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/40 dark:border-surface-dark-border dark:bg-surface-dark-1"
        >
          {asset.mime_type.startsWith("image/") ? (
            // eslint-disable-next-line @next/next/no-img-element -- dashboard
            // thumbnail grid; next/image is used for public-site images
            // once content modules render them (Phase 2.7 §12).
            <img
              src={asset.public_url}
              alt={asset.alt_text ?? ""}
              className="h-full w-full object-cover"
            />
          ) : asset.mime_type.startsWith("video/") ? (
            <Video size={24} className="text-neutral-400" />
          ) : (
            <FileText size={24} className="text-neutral-400" />
          )}
          <span className="mt-2 w-full truncate px-2 text-caption text-neutral-500 dark:text-text-dark-secondary">
            {asset.file_name}
          </span>
        </button>
      ))}
    </div>
  );
}
