"use client";

import * as React from "react";

import { AccessDenied } from "@/components/dashboard/states/AccessDenied";
import { AuthError } from "@/components/dashboard/states/AuthError";
import { useCurrentUser } from "@/lib/hooks/useCurrentUser";

/**
 * Page-level RBAC gate for dashboard screens. Renders children only when
 * the resolved current user holds `permission`; otherwise shows the shared
 * AccessDenied state. While the user is still resolving it shows a light
 * loading line, and if /auth/me fails it surfaces AuthError.
 *
 * IMPORTANT: this is a UX guard, not a security boundary. The backend
 * enforces `require_permission` on every endpoint, so a user who reaches a
 * gated screen by other means still cannot read or mutate data they lack
 * permission for. This component's job is to fail *gracefully* (a clear
 * "no access" screen instead of a wall of failed requests), not to be the
 * thing that keeps data safe.
 */
export function PermissionGate({
  permission,
  children,
  fallback,
}: {
  permission: string;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}) {
  const { user, isLoading, isError } = useCurrentUser();

  if (isLoading) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center text-body-sm text-neutral-400">
        Loading…
      </div>
    );
  }

  if (isError) {
    return (
      <div className="mx-auto max-w-md py-10">
        <AuthError message="We couldn't verify your permissions. Please refresh, or sign in again." />
      </div>
    );
  }

  if (!user?.permissions.includes(permission)) {
    return <>{fallback ?? <AccessDenied requiredPermission={permission} />}</>;
  }

  return <>{children}</>;
}
