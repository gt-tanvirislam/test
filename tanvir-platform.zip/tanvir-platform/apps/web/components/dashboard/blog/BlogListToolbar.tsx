"use client";

import type { BlogPostListFilters, ContentStatus } from "@tanvir-platform/types";
import { ActionBar, Input, Select } from "@tanvir-platform/ui";

import { AuthorSelect } from "@/components/features/users";
import { useBlogCategories, useTags } from "@/lib/hooks/useBlog";

export interface BlogListToolbarProps {
  filters: BlogPostListFilters;
  onChange: (filters: BlogPostListFilters) => void;
}

const STATUS_OPTIONS: { value: ContentStatus | ""; label: string }[] = [
  { value: "", label: "All statuses" },
  { value: "draft", label: "Draft" },
  { value: "scheduled", label: "Scheduled" },
  { value: "published", label: "Published" },
  { value: "archived", label: "Archived" },
];

/**
 * Blog list filter bar (this sprint's requirement: search, status,
 * category, tag filters). Built on the shared ActionBar shell (Sprint 2)
 * — a future PortfolioListToolbar copies this file's shape, swapping the
 * category/tag data sources for Portfolio's own hooks.
 */
export function BlogListToolbar({ filters, onChange }: BlogListToolbarProps) {
  const { data: categories = [] } = useBlogCategories();
  const { data: tags = [] } = useTags();

  function set<K extends keyof BlogPostListFilters>(key: K, value: BlogPostListFilters[K]) {
    onChange({ ...filters, [key]: value, page: 1 });
  }

  return (
    <ActionBar>
      <div className="flex flex-1 flex-wrap items-center gap-2">
        <Input
          placeholder="Search posts…"
          value={filters.search ?? ""}
          onChange={(e) => set("search", e.target.value || undefined)}
          className="max-w-xs"
        />

        <Select
          value={filters.status ?? ""}
          onChange={(e) => set("status", (e.target.value || undefined) as ContentStatus | undefined)}
          className="w-auto"
        >
          {STATUS_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </Select>

        <Select
          value={filters.category_id ?? ""}
          onChange={(e) => set("category_id", e.target.value || undefined)}
          className="w-auto"
        >
          <option value="">All categories</option>
          {categories.map((category) => (
            <option key={category.id} value={category.id}>
              {category.name}
            </option>
          ))}
        </Select>

        <Select
          value={filters.tag_id ?? ""}
          onChange={(e) => set("tag_id", e.target.value || undefined)}
          className="w-auto"
        >
          <option value="">All tags</option>
          {tags.map((tag) => (
            <option key={tag.id} value={tag.id}>
              {tag.name}
            </option>
          ))}
        </Select>

        <div className="w-48">
          <AuthorSelect
            value={filters.author_id ?? null}
            onChange={(authorId) => set("author_id", authorId ?? undefined)}
            mode="filter"
            label=""
          />
        </div>
      </div>
    </ActionBar>
  );
}
