"use client";

import type { BlogPost, MediaAsset } from "@tanvir-platform/types";
import { Skeleton, Tabs, TabsContent, TabsList, TabsTrigger, useToast } from "@tanvir-platform/ui";
import * as React from "react";

import {
  AutosaveIndicator,
  ContentEditorShell,
  emptySeoPanelValues,
  ExcerptField,
  FeaturedImageField,
  PublishPanel,
  RichTextField,
  SeoPanel,
  TagInput,
  TitleSlugFields,
} from "@/components/features/content-editor";
import type { SeoPanelValues } from "@/components/features/content-editor";
import { CategorySelectField } from "@/components/features/taxonomy";
import { AuthorSelect } from "@/components/features/users";
import { useAutosave } from "@/lib/hooks/useAutosave";
import {
  useBlogCategories,
  useBlogPostLifecycle,
  useCheckSlugAvailability,
  useCreateBlogCategory,
  useTags,
  useUpdateBlogPost,
} from "@/lib/hooks/useBlog";
import { useMediaAsset } from "@/lib/hooks/useMedia";

export interface BlogEditorProps {
  post: BlogPost;
}

/**
 * BlogEditor — the reference Universal Content Editor composition
 * (Sprint 4), refined this sprint to fix the featured-image preview bug,
 * wire real slug-availability checking, add the author selector, and
 * surface save errors via Toast instead of failing silently.
 */
export function BlogEditor({ post }: BlogEditorProps) {
  const { showToast } = useToast();

  const [title, setTitle] = React.useState(post.title);
  const [slug, setSlug] = React.useState(post.slug);
  const [excerpt, setExcerpt] = React.useState(post.excerpt ?? "");
  const [body, setBody] = React.useState(post.body_mdx);
  const [categoryId, setCategoryId] = React.useState<string | null>(post.category_id);
  const [tagNames, setTagNames] = React.useState<string[]>(post.tags.map((t) => t.name));
  const [featuredImage, setFeaturedImage] = React.useState<MediaAsset | null>(null);
  const [seo, setSeo] = React.useState<SeoPanelValues>(emptySeoPanelValues);
  const [ogImage, setOgImage] = React.useState<MediaAsset | null>(null);
  const [authorId, setAuthorId] = React.useState<string>(post.author_id);

  // Sprint 5 fix: hydrate the full MediaAsset (with public_url) from the
  // post's stored ID, rather than the Sprint 4 placeholder object that
  // had no public_url and rendered a broken image.
  const { data: hydratedFeaturedImage } = useMediaAsset(post.featured_image_id);
  React.useEffect(() => {
    if (hydratedFeaturedImage) setFeaturedImage(hydratedFeaturedImage);
  }, [hydratedFeaturedImage]);

  const { data: categories = [] } = useBlogCategories();
  const { data: allTags = [] } = useTags();
  const createCategory = useCreateBlogCategory();
  const updatePost = useUpdateBlogPost(post.id);
  const lifecycle = useBlogPostLifecycle(post.id);
  const checkSlugAvailability = useCheckSlugAvailability(post.id);

  const autosavePayload = React.useMemo(
    () => ({
      title,
      slug,
      excerpt,
      body_mdx: body,
      category_id: categoryId,
      tag_names: tagNames,
      author_id: authorId,
    }),
    [title, slug, excerpt, body, categoryId, tagNames, authorId]
  );

  const { status: autosaveStatus, lastSavedAt } = useAutosave({
    data: autosavePayload,
    onSave: async (data) => {
      try {
        await updatePost.mutateAsync(data);
      } catch {
        showToast("Couldn't save your changes. Check your connection and try again.", "error");
        throw new Error("autosave failed"); // lets useAutosave's own status also reflect "error"
      }
    },
  });

  async function handleSaveDraft() {
    try {
      await updatePost.mutateAsync(autosavePayload);
      showToast("Draft saved");
    } catch {
      showToast("Couldn't save the draft", "error");
    }
  }

  async function runLifecycleAction(action: () => Promise<unknown>, successMessage: string) {
    try {
      await action();
      showToast(successMessage);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Something went wrong";
      showToast(message, "error");
    }
  }

  return (
    <ContentEditorShell
      title={post.title || "New post"}
      saveBar={<AutosaveIndicator status={autosaveStatus} lastSavedAt={lastSavedAt} />}
      mainPanel={
        <div className="flex flex-col gap-6">
          <TitleSlugFields
            title={title}
            onTitleChange={setTitle}
            slug={slug}
            onSlugChange={setSlug}
            urlPrefix="/blog"
            initialSlug={post.slug}
            checkSlugAvailability={checkSlugAvailability}
          />
          <ExcerptField value={excerpt} onChange={setExcerpt} />
          <RichTextField value={body} onChange={setBody} label="Post content" />
        </div>
      }
      sidebarPanel={
        <Tabs defaultTab="content">
          <TabsList>
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="seo">SEO</TabsTrigger>
          </TabsList>

          <TabsContent value="content">
            <div className="flex flex-col gap-4">
              <PublishPanel
                status={post.status}
                scheduledAt={post.scheduled_at}
                isSaving={updatePost.isPending}
                onSaveDraft={handleSaveDraft}
                onPublish={() => runLifecycleAction(() => lifecycle.publish.mutateAsync(), "Post published")}
                onUnpublish={() => runLifecycleAction(() => lifecycle.unpublish.mutateAsync(), "Post unpublished")}
                onSchedule={(iso) =>
                  runLifecycleAction(() => lifecycle.schedule.mutateAsync(iso), "Post scheduled")
                }
                onArchive={() => runLifecycleAction(() => lifecycle.archive.mutateAsync(), "Post archived")}
                onRestore={() => runLifecycleAction(() => lifecycle.restore.mutateAsync(), "Post restored to draft")}
              />

              {post.featured_image_id && !featuredImage ? (
                <Skeleton className="aspect-video w-full" />
              ) : (
                <FeaturedImageField value={featuredImage} onChange={setFeaturedImage} />
              )}

              <AuthorSelect value={authorId} onChange={(id) => id && setAuthorId(id)} mode="assign" />

              <CategorySelectField
                categories={categories}
                value={categoryId}
                onChange={setCategoryId}
                onCreateCategory={(name) => createCategory.mutateAsync({ name })}
                isCreating={createCategory.isPending}
              />

              <TagInput
                label="Tags"
                value={tagNames}
                onChange={setTagNames}
                suggestions={allTags.map((t) => t.name)}
              />
            </div>
          </TabsContent>

          <TabsContent value="seo">
            <SeoPanel
              values={seo}
              onChange={setSeo}
              ogImage={ogImage}
              onOgImageChange={setOgImage}
              fallbackTitle={title}
              fallbackDescription={excerpt}
            />
          </TabsContent>
        </Tabs>
      }
    />
  );
}
