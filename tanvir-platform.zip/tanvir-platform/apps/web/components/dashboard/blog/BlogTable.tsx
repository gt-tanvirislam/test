"use client";

import type { BlogPostListItem } from "@tanvir-platform/types";
import { Badge, Button, Table, TableBody, TableCell, TableHead, TableHeaderCell, TableRow } from "@tanvir-platform/ui";
import type { BadgeProps } from "@tanvir-platform/ui";
import Link from "next/link";
import * as React from "react";

const STATUS_TONE: Record<string, NonNullable<BadgeProps["tone"]>> = {
  draft: "neutral",
  scheduled: "warning",
  published: "success",
  archived: "error",
};

export interface BlogTableProps {
  posts: BlogPostListItem[];
  selectedIds: string[];
  onSelectionChange: (ids: string[]) => void;
  onDelete: (id: string) => void;
}

/**
 * Blog table (this sprint's requirement: list + bulk actions). Built
 * entirely on the shared Table primitives (Sprint 2) — no new table
 * component, per this sprint's reuse rule. A future PortfolioTable
 * copies this shape with different columns.
 */
export function BlogTable({ posts, selectedIds, onSelectionChange, onDelete }: BlogTableProps) {
  const allSelected = posts.length > 0 && selectedIds.length === posts.length;

  function toggleAll() {
    onSelectionChange(allSelected ? [] : posts.map((p) => p.id));
  }

  function toggleOne(id: string) {
    onSelectionChange(
      selectedIds.includes(id) ? selectedIds.filter((i) => i !== id) : [...selectedIds, id]
    );
  }

  return (
    <Table>
      <TableHead>
        <tr>
          <TableHeaderCell className="w-10">
            <input
              type="checkbox"
              checked={allSelected}
              onChange={toggleAll}
              aria-label="Select all posts"
              className="h-4 w-4 rounded-sm border-neutral-300 text-accent-500"
            />
          </TableHeaderCell>
          <TableHeaderCell>Title</TableHeaderCell>
          <TableHeaderCell>Status</TableHeaderCell>
          <TableHeaderCell>Category</TableHeaderCell>
          <TableHeaderCell>Updated</TableHeaderCell>
          <TableHeaderCell className="w-20">Actions</TableHeaderCell>
        </tr>
      </TableHead>
      <TableBody>
        {posts.map((post) => (
          <TableRow key={post.id}>
            <TableCell>
              <input
                type="checkbox"
                checked={selectedIds.includes(post.id)}
                onChange={() => toggleOne(post.id)}
                aria-label={`Select ${post.title}`}
                className="h-4 w-4 rounded-sm border-neutral-300 text-accent-500"
              />
            </TableCell>
            <TableCell>
              <Link
                href={`/dashboard/blog/${post.id}/edit`}
                className="font-medium text-neutral-800 hover:text-accent-500 dark:text-text-dark-primary"
              >
                {post.title}
              </Link>
              {post.featured && (
                <Badge tone="accent" className="ml-2">
                  Featured
                </Badge>
              )}
            </TableCell>
            <TableCell>
              <Badge tone={STATUS_TONE[post.status]}>{post.status}</Badge>
            </TableCell>
            <TableCell>{post.category?.name ?? "—"}</TableCell>
            <TableCell>{new Date(post.updated_at).toLocaleDateString()}</TableCell>
            <TableCell>
              <Button variant="tertiary" size="sm" onClick={() => onDelete(post.id)}>
                Delete
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
