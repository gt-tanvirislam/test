"use client";

import type { BeforeAfterPairDraft, MediaAsset, PortfolioItem } from "@tanvir-platform/types";
import { Input, Label, Skeleton, Tabs, TabsContent, TabsList, TabsTrigger, Textarea, useToast } from "@tanvir-platform/ui";
import * as React from "react";

import {
  AutosaveIndicator,
  BeforeAfterPairsField,
  ContentEditorShell,
  emptySeoPanelValues,
  ExcerptField,
  FeaturedImageField,
  GalleryField,
  PublishPanel,
  RichTextField,
  SeoPanel,
  TagInput,
  TitleSlugFields,
} from "@/components/features/content-editor";
import type { SeoPanelValues } from "@/components/features/content-editor";
import { CategorySelectField } from "@/components/features/taxonomy";
import { AuthorSelect } from "@/components/features/users";
import { useAutosave } from "@/lib/hooks/useAutosave";
import { useMediaAsset } from "@/lib/hooks/useMedia";
import {
  useCheckPortfolioSlugAvailability,
  useCreatePortfolioCategory,
  usePortfolioCategories,
  usePortfolioGallery,
  usePortfolioItemLifecycle,
  useSetPortfolioBeforeAfterPairs,
  useSetPortfolioGallery,
  useUpdatePortfolioItem,
} from "@/lib/hooks/usePortfolio";
import { useTags } from "@/lib/hooks/useBlog";

export interface PortfolioEditorProps {
  item: PortfolioItem;
}

/**
 * PortfolioEditor — the advanced reference composition (Sprint 6).
 * Structurally identical to BlogEditor (Sprint 4/5) for every field they
 * share; adds gallery, before/after pairs, and case-study fields as
 * their own tab rather than overloading the Content tab, since Blog's
 * single-tab sidebar was already near capacity with fewer fields.
 */
export function PortfolioEditor({ item }: PortfolioEditorProps) {
  const { showToast } = useToast();

  const [title, setTitle] = React.useState(item.title);
  const [slug, setSlug] = React.useState(item.slug);
  const [shortDescription, setShortDescription] = React.useState(item.short_description ?? "");
  const [fullCaseStudy, setFullCaseStudy] = React.useState(item.full_case_study);
  const [categoryId, setCategoryId] = React.useState<string | null>(item.category_id);
  const [tagNames, setTagNames] = React.useState<string[]>(item.tags.map((t) => t.name));
  const [featuredImage, setFeaturedImage] = React.useState<MediaAsset | null>(null);
  const [galleryAssets, setGalleryAssets] = React.useState<MediaAsset[]>([]);
  const [beforeAfterPairs, setBeforeAfterPairs] = React.useState<BeforeAfterPairDraft[]>(
    item.before_after_pairs.map((p) => ({
      before_media_id: p.before_media_id,
      after_media_id: p.after_media_id,
      caption: p.caption ?? undefined,
    }))
  );
  const [clientName, setClientName] = React.useState(item.client_name ?? "");
  const [industry, setIndustry] = React.useState(item.industry ?? "");
  const [servicesUsed, setServicesUsed] = React.useState<string[]>(item.services_used);
  const [technologies, setTechnologies] = React.useState<string[]>(item.technologies);
  const [isCaseStudy, setIsCaseStudy] = React.useState(item.is_case_study);
  const [challenge, setChallenge] = React.useState(item.challenge ?? "");
  const [solution, setSolution] = React.useState(item.solution ?? "");
  const [results, setResults] = React.useState(item.results ?? "");
  const [ctaText, setCtaText] = React.useState(item.cta_text ?? "");
  const [ctaLink, setCtaLink] = React.useState(item.cta_link ?? "");
  const [seo, setSeo] = React.useState<SeoPanelValues>(emptySeoPanelValues);
  const [ogImage, setOgImage] = React.useState<MediaAsset | null>(null);
  const [authorId, setAuthorId] = React.useState<string>(item.author_id);

  const { data: hydratedFeaturedImage } = useMediaAsset(item.featured_image_id);
  React.useEffect(() => {
    if (hydratedFeaturedImage) setFeaturedImage(hydratedFeaturedImage);
  }, [hydratedFeaturedImage]);

  const { data: hydratedGallery } = usePortfolioGallery(item.id);
  React.useEffect(() => {
    if (hydratedGallery) setGalleryAssets(hydratedGallery);
  }, [hydratedGallery]);

  const { data: categories = [] } = usePortfolioCategories();
  const { data: allTags = [] } = useTags();
  const createCategory = useCreatePortfolioCategory();
  const updateItem = useUpdatePortfolioItem(item.id);
  const lifecycle = usePortfolioItemLifecycle(item.id);
  const checkSlugAvailability = useCheckPortfolioSlugAvailability(item.id);
  const setGallery = useSetPortfolioGallery(item.id);
  const setPairs = useSetPortfolioBeforeAfterPairs(item.id);

  const autosavePayload = React.useMemo(
    () => ({
      title, slug, short_description: shortDescription, full_case_study: fullCaseStudy,
      category_id: categoryId, tag_names: tagNames, author_id: authorId,
      client_name: clientName || null, industry: industry || null,
      services_used: servicesUsed, technologies, is_case_study: isCaseStudy,
      challenge: challenge || null, solution: solution || null, results: results || null,
      cta_text: ctaText || null, cta_link: ctaLink || null,
    }),
    [title, slug, shortDescription, fullCaseStudy, categoryId, tagNames, authorId, clientName,
     industry, servicesUsed, technologies, isCaseStudy, challenge, solution, results, ctaText, ctaLink]
  );

  const { status: autosaveStatus, lastSavedAt } = useAutosave({
    data: autosavePayload,
    onSave: async (data) => {
      try {
        await updateItem.mutateAsync(data);
      } catch {
        showToast("Couldn't save your changes", "error");
        throw new Error("autosave failed");
      }
    },
  });

  async function handleSaveDraft() {
    try {
      await updateItem.mutateAsync(autosavePayload);
      showToast("Draft saved");
    } catch {
      showToast("Couldn't save the draft", "error");
    }
  }

  async function runLifecycleAction(action: () => Promise<unknown>, successMessage: string) {
    try {
      await action();
      showToast(successMessage);
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Something went wrong", "error");
    }
  }

  function handleGalleryChange(assets: MediaAsset[]) {
    setGalleryAssets(assets);
    setGallery.mutate(assets.map((a) => a.id));
  }

  function handlePairsChange(pairs: BeforeAfterPairDraft[]) {
    setBeforeAfterPairs(pairs);
    const complete = pairs.filter((p) => p.before_media_id && p.after_media_id);
    setPairs.mutate(complete.map(({ before_media_id, after_media_id, caption }) => ({ before_media_id, after_media_id, caption })));
  }

  return (
    <ContentEditorShell
      title={item.title || "New project"}
      saveBar={<AutosaveIndicator status={autosaveStatus} lastSavedAt={lastSavedAt} />}
      mainPanel={
        <div className="flex flex-col gap-6">
          <TitleSlugFields
            title={title}
            onTitleChange={setTitle}
            slug={slug}
            onSlugChange={setSlug}
            urlPrefix="/portfolio"
            initialSlug={item.slug}
            checkSlugAvailability={checkSlugAvailability}
          />
          <ExcerptField value={shortDescription} onChange={setShortDescription} />
          <RichTextField value={fullCaseStudy} onChange={setFullCaseStudy} label="Full case study" />

          <div>
            <Label className="mb-2 flex items-center gap-2">
              <input
                type="checkbox"
                checked={isCaseStudy}
                onChange={(e) => setIsCaseStudy(e.target.checked)}
                className="h-4 w-4 rounded-sm border-neutral-300 text-accent-500"
              />
              This is a structured case study
            </Label>

            {isCaseStudy && (
              <div className="flex flex-col gap-3 rounded-md border border-neutral-200 p-4 dark:border-surface-dark-border">
                <div>
                  <Label htmlFor="challenge">Challenge</Label>
                  <Textarea id="challenge" rows={3} value={challenge} onChange={(e) => setChallenge(e.target.value)} />
                </div>
                <div>
                  <Label htmlFor="solution">Solution</Label>
                  <Textarea id="solution" rows={3} value={solution} onChange={(e) => setSolution(e.target.value)} />
                </div>
                <div>
                  <Label htmlFor="results">Results</Label>
                  <Textarea id="results" rows={3} value={results} onChange={(e) => setResults(e.target.value)} />
                </div>
              </div>
            )}
          </div>

          <BeforeAfterPairsField value={beforeAfterPairs} onChange={handlePairsChange} />
          <GalleryField value={galleryAssets} onChange={handleGalleryChange} />
        </div>
      }
      sidebarPanel={
        <Tabs defaultTab="content">
          <TabsList>
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="seo">SEO</TabsTrigger>
          </TabsList>

          <TabsContent value="content">
            <div className="flex flex-col gap-4">
              <PublishPanel
                status={item.status}
                scheduledAt={item.scheduled_at}
                isSaving={updateItem.isPending}
                onSaveDraft={handleSaveDraft}
                onPublish={() => runLifecycleAction(() => lifecycle.publish.mutateAsync(), "Project published")}
                onUnpublish={() => runLifecycleAction(() => lifecycle.unpublish.mutateAsync(), "Project unpublished")}
                onSchedule={(iso) => runLifecycleAction(() => lifecycle.schedule.mutateAsync(iso), "Project scheduled")}
                onArchive={() => runLifecycleAction(() => lifecycle.archive.mutateAsync(), "Project archived")}
                onRestore={() => runLifecycleAction(() => lifecycle.restore.mutateAsync(), "Project restored to draft")}
              />

              {item.featured_image_id && !featuredImage ? (
                <Skeleton className="aspect-video w-full" />
              ) : (
                <FeaturedImageField value={featuredImage} onChange={setFeaturedImage} />
              )}

              <AuthorSelect value={authorId} onChange={(id) => id && setAuthorId(id)} mode="assign" />

              <CategorySelectField
                categories={categories}
                value={categoryId}
                onChange={setCategoryId}
                onCreateCategory={(name) => createCategory.mutateAsync({ name })}
                isCreating={createCategory.isPending}
              />

              <TagInput label="Tags" value={tagNames} onChange={setTagNames} suggestions={allTags.map((t) => t.name)} />
            </div>
          </TabsContent>

          <TabsContent value="details">
            <div className="flex flex-col gap-4">
              <div>
                <Label htmlFor="client-name">Client name</Label>
                <Input id="client-name" value={clientName} onChange={(e) => setClientName(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="industry">Industry</Label>
                <Input id="industry" value={industry} onChange={(e) => setIndustry(e.target.value)} />
              </div>
              <TagInput label="Services used" value={servicesUsed} onChange={setServicesUsed} />
              <TagInput label="Technologies" value={technologies} onChange={setTechnologies} />
              <div>
                <Label htmlFor="cta-text">CTA text</Label>
                <Input id="cta-text" value={ctaText} onChange={(e) => setCtaText(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="cta-link">CTA link</Label>
                <Input id="cta-link" value={ctaLink} onChange={(e) => setCtaLink(e.target.value)} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="seo">
            <SeoPanel
              values={seo}
              onChange={setSeo}
              ogImage={ogImage}
              onOgImageChange={setOgImage}
              fallbackTitle={title}
              fallbackDescription={shortDescription}
            />
          </TabsContent>
        </Tabs>
      }
    />
  );
}
