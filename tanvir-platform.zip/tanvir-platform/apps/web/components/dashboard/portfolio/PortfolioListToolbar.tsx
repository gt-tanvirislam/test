"use client";

import type { ContentStatus, PortfolioItemListFilters } from "@tanvir-platform/types";
import { ActionBar, Input, Select } from "@tanvir-platform/ui";

import { AuthorSelect } from "@/components/features/users";
import { usePortfolioCategories } from "@/lib/hooks/usePortfolio";

export interface PortfolioListToolbarProps {
  filters: PortfolioItemListFilters;
  onChange: (filters: PortfolioItemListFilters) => void;
}

const STATUS_OPTIONS: { value: ContentStatus | ""; label: string }[] = [
  { value: "", label: "All statuses" },
  { value: "draft", label: "Draft" },
  { value: "scheduled", label: "Scheduled" },
  { value: "published", label: "Published" },
  { value: "archived", label: "Archived" },
];

/** Mirrors BlogListToolbar's shape exactly (Sprint 4/5), adding the
 * Featured filter this sprint's brief specifically calls out. */
export function PortfolioListToolbar({ filters, onChange }: PortfolioListToolbarProps) {
  const { data: categories = [] } = usePortfolioCategories();

  function set<K extends keyof PortfolioItemListFilters>(key: K, value: PortfolioItemListFilters[K]) {
    onChange({ ...filters, [key]: value, page: 1 });
  }

  return (
    <ActionBar>
      <div className="flex flex-1 flex-wrap items-center gap-2">
        <Input
          placeholder="Search projects…"
          value={filters.search ?? ""}
          onChange={(e) => set("search", e.target.value || undefined)}
          className="max-w-xs"
        />

        <Select
          value={filters.status ?? ""}
          onChange={(e) => set("status", (e.target.value || undefined) as ContentStatus | undefined)}
          className="w-auto"
        >
          {STATUS_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </Select>

        <Select
          value={filters.category_id ?? ""}
          onChange={(e) => set("category_id", e.target.value || undefined)}
          className="w-auto"
        >
          <option value="">All categories</option>
          {categories.map((category) => (
            <option key={category.id} value={category.id}>
              {category.name}
            </option>
          ))}
        </Select>

        <Select
          value={filters.featured === undefined ? "" : String(filters.featured)}
          onChange={(e) => set("featured", e.target.value === "" ? undefined : e.target.value === "true")}
          className="w-auto"
        >
          <option value="">All projects</option>
          <option value="true">Featured only</option>
          <option value="false">Not featured</option>
        </Select>

        <div className="w-48">
          <AuthorSelect
            value={filters.author_id ?? null}
            onChange={(authorId) => set("author_id", authorId ?? undefined)}
            mode="filter"
            label=""
          />
        </div>
      </div>
    </ActionBar>
  );
}
