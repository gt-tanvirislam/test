"use client";

import type { SiteSettings, UpdateSiteSettingsInput } from "@tanvir-platform/types";
import {
  Button,
  Card,
  FormField,
  Input,
  Skeleton,
  Textarea,
  useToast,
} from "@tanvir-platform/ui";
import { Plus, Trash2 } from "lucide-react";
import * as React from "react";

import { ApiError } from "@/lib/api/client";
import { useSiteSettings, useUpdateSiteSettings } from "@/lib/hooks/useSettings";

interface SocialRow {
  platform: string;
  url: string;
}

/** Local, editable mirror of the server record. Nullable text fields become
 * "" for the controlled inputs and are converted back to null on save. */
interface FormState {
  site_name: string;
  tagline: string;
  contact_email: string;
  default_meta_description: string;
  social_links: SocialRow[];
}

function toFormState(settings: SiteSettings): FormState {
  return {
    site_name: settings.site_name,
    tagline: settings.tagline ?? "",
    contact_email: settings.contact_email ?? "",
    default_meta_description: settings.default_meta_description ?? "",
    social_links: settings.social_links.map((l) => ({ platform: l.platform, url: l.url })),
  };
}

/** Empty text → null so an intentionally-cleared field is stored as null,
 * not an empty string. Social rows that are entirely blank are dropped. */
function toPayload(form: FormState): UpdateSiteSettingsInput {
  const nullIfBlank = (v: string) => {
    const trimmed = v.trim();
    return trimmed === "" ? null : trimmed;
  };
  return {
    site_name: form.site_name.trim(),
    tagline: nullIfBlank(form.tagline),
    contact_email: nullIfBlank(form.contact_email),
    default_meta_description: nullIfBlank(form.default_meta_description),
    social_links: form.social_links
      .map((l) => ({ platform: l.platform.trim(), url: l.url.trim() }))
      .filter((l) => l.platform !== "" || l.url !== ""),
  };
}

export function SettingsForm() {
  const { data: settings, isLoading, isError } = useSiteSettings();
  const update = useUpdateSiteSettings();
  const { showToast } = useToast();

  const [form, setForm] = React.useState<FormState | null>(null);
  const [fieldErrors, setFieldErrors] = React.useState<Record<string, string>>({});

  // Seed the editable form once the settings load. Keyed re-seeding on the
  // fetched object identity keeps the form in sync if the query refetches
  // while the user hasn't started editing.
  React.useEffect(() => {
    if (settings && form === null) setForm(toFormState(settings));
  }, [settings, form]);

  if (isLoading || (form === null && !isError)) {
    return (
      <Card className="space-y-4">
        <Skeleton className="h-11 w-full" />
        <Skeleton className="h-11 w-full" />
        <Skeleton className="h-24 w-full" />
      </Card>
    );
  }

  if (isError || form === null) {
    return (
      <Card>
        <p className="text-body-sm text-error-500">
          We couldn&apos;t load the site settings. Please refresh and try again.
        </p>
      </Card>
    );
  }

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((prev) => (prev ? { ...prev, [key]: value } : prev));

  const setSocial = (index: number, key: keyof SocialRow, value: string) =>
    setForm((prev) =>
      prev
        ? {
            ...prev,
            social_links: prev.social_links.map((row, i) =>
              i === index ? { ...row, [key]: value } : row
            ),
          }
        : prev
    );

  const addSocial = () =>
    setForm((prev) =>
      prev ? { ...prev, social_links: [...prev.social_links, { platform: "", url: "" }] } : prev
    );

  const removeSocial = (index: number) =>
    setForm((prev) =>
      prev ? { ...prev, social_links: prev.social_links.filter((_, i) => i !== index) } : prev
    );

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setFieldErrors({});

    if (form.site_name.trim() === "") {
      setFieldErrors({ site_name: "Site name is required." });
      return;
    }

    try {
      await update.mutateAsync(toPayload(form));
      showToast("Settings saved");
    } catch (err) {
      if (err instanceof ApiError && err.fields) {
        setFieldErrors(err.fields);
        showToast("Please fix the highlighted fields.", "error");
      } else {
        showToast("Couldn't save settings. Check your connection and try again.", "error");
      }
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="space-y-5">
        <FormField label="Site name" htmlFor="site_name" error={fieldErrors.site_name}>
          <Input
            id="site_name"
            value={form.site_name}
            onChange={(e) => set("site_name", e.target.value)}
            hasError={!!fieldErrors.site_name}
            maxLength={120}
            required
          />
        </FormField>

        <FormField label="Tagline" htmlFor="tagline" error={fieldErrors.tagline}>
          <Input
            id="tagline"
            value={form.tagline}
            onChange={(e) => set("tagline", e.target.value)}
            hasError={!!fieldErrors.tagline}
            maxLength={200}
            placeholder="A short line shown alongside the site name"
          />
        </FormField>

        <FormField label="Public contact email" htmlFor="contact_email" error={fieldErrors.contact_email}>
          <Input
            id="contact_email"
            type="email"
            value={form.contact_email}
            onChange={(e) => set("contact_email", e.target.value)}
            hasError={!!fieldErrors.contact_email}
            maxLength={254}
            placeholder="hello@example.com"
          />
        </FormField>

        <FormField
          label="Default meta description"
          htmlFor="default_meta_description"
          error={fieldErrors.default_meta_description}
        >
          <Textarea
            id="default_meta_description"
            value={form.default_meta_description}
            onChange={(e) => set("default_meta_description", e.target.value)}
            hasError={!!fieldErrors.default_meta_description}
            maxLength={320}
            placeholder="Used as the fallback SEO description for pages without their own."
          />
        </FormField>
      </Card>

      <Card className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-card-title font-semibold text-neutral-800 dark:text-text-dark-primary">
              Social links
            </h3>
            <p className="mt-1 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
              Shown in the site footer. Leave empty until real profiles are confirmed.
            </p>
          </div>
          <Button type="button" variant="secondary" size="sm" onClick={addSocial}>
            <Plus size={16} /> Add link
          </Button>
        </div>

        {form.social_links.length === 0 ? (
          <p className="text-body-sm text-neutral-400">No social links added yet.</p>
        ) : (
          <ul className="space-y-3">
            {form.social_links.map((row, index) => (
              <li key={index} className="flex items-start gap-3">
                <div className="w-40 shrink-0">
                  <Input
                    aria-label={`Social link ${index + 1} platform`}
                    value={row.platform}
                    onChange={(e) => setSocial(index, "platform", e.target.value)}
                    placeholder="instagram"
                    maxLength={50}
                  />
                </div>
                <div className="flex-1">
                  <Input
                    aria-label={`Social link ${index + 1} URL`}
                    value={row.url}
                    onChange={(e) => setSocial(index, "url", e.target.value)}
                    placeholder="https://instagram.com/username"
                    maxLength={500}
                  />
                </div>
                <Button
                  type="button"
                  variant="tertiary"
                  size="sm"
                  onClick={() => removeSocial(index)}
                  aria-label={`Remove social link ${index + 1}`}
                >
                  <Trash2 size={16} />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <div className="flex justify-end">
        <Button type="submit" loading={update.isPending}>
          Save changes
        </Button>
      </div>
    </form>
  );
}
