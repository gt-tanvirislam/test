"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { NAV_ITEMS } from "@/lib/constants/nav";
import { useVisibleNavItems } from "@/lib/hooks/useCurrentUser";
import { cn, Skeleton } from "@tanvir-platform/ui";

/**
 * Dashboard sidebar. Navigation items are filtered to those the current
 * user's permissions allow (`useVisibleNavItems`) so an editor never sees
 * the Users or Settings links, etc. Hiding is UX only — the backend still
 * enforces every endpoint's permission independently. While the user is
 * resolving, skeleton rows stand in so the nav doesn't flash the full list
 * and then collapse.
 */
export function DashboardSidebar() {
  const pathname = usePathname();
  const { items, isLoading } = useVisibleNavItems(NAV_ITEMS);

  return (
    <aside className="hidden w-60 shrink-0 border-r border-neutral-200 bg-neutral-50 p-4 dark:border-surface-dark-border dark:bg-surface-dark-1 md:block">
      <div className="px-2 py-1 text-h4 font-semibold text-neutral-800 dark:text-text-dark-primary">
        Tamvir Islam
      </div>
      <nav className="mt-6 flex flex-col gap-1" aria-label="Dashboard navigation">
        {isLoading
          ? Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} variant="block" className="h-9 w-full" />
            ))
          : items.map((item) => {
              const isActive =
                item.href === "/dashboard"
                  ? pathname === item.href
                  : pathname.startsWith(item.href);
              const Icon = item.icon;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-current={isActive ? "page" : undefined}
                  className={cn(
                    "flex items-center gap-3 rounded-md px-2 py-2 text-body-sm transition-colors",
                    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/40",
                    isActive
                      ? "bg-accent-50 font-medium text-accent-600 dark:bg-surface-dark-2 dark:text-accent-400"
                      : "text-neutral-500 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-2"
                  )}
                >
                  <Icon size={18} aria-hidden />
                  {item.label}
                </Link>
              );
            })}
      </nav>
    </aside>
  );
}
