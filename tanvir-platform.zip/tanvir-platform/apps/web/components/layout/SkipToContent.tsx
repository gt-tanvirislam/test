/**
 * Skip-to-content link (Sprint 7). Visually hidden until focused via
 * keyboard, then jumps straight to `#main-content` — the standard
 * pattern for letting keyboard users bypass repeated navigation. Placed
 * in the root layout (not just the public layout) so it also benefits
 * the dashboard, which never got one either.
 */
export function SkipToContent() {
  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-tooltip focus:rounded-md focus:bg-accent-500 focus:px-4 focus:py-2 focus:text-button focus:text-white"
    >
      Skip to content
    </a>
  );
}
