import Link from "next/link";

import { Container } from "./Container";
import type { NavItem } from "./NavBar";

export interface FooterColumn {
  title: string;
  items: NavItem[];
}

export interface FooterProps {
  siteName: string;
  columns: FooterColumn[];
  /** Empty array is valid and expected until Settings/Social exists —
   * the section simply doesn't render, per the graceful-empty-content
   * pattern established in Phase 2.6 §11. */
  socialLinks: { platform: string; url: string }[];
  /** Same empty-until-real-data pattern as socialLinks (Sprint 7). */
  contactEmail?: string | null;
}

/**
 * Public Footer (Sprint 5 §5, extended Sprint 7 with contact info and
 * the shared Container). Structure only — every prop is data-driven,
 * with no default marketing content baked in.
 */
export function Footer({ siteName, columns, socialLinks, contactEmail }: FooterProps) {
  return (
    <footer className="border-t border-neutral-200 bg-neutral-50 dark:border-surface-dark-border dark:bg-surface-dark-1">
      <Container className="py-12">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4">
          <div>
            <p className="text-h4 font-semibold text-neutral-800 dark:text-text-dark-primary">{siteName}</p>
            {contactEmail && (
              <a
                href={`mailto:${contactEmail}`}
                className="mt-2 inline-block text-body-sm text-neutral-500 hover:text-neutral-800 dark:text-text-dark-secondary dark:hover:text-text-dark-primary"
              >
                {contactEmail}
              </a>
            )}
          </div>

          {columns.map((column) => (
            <div key={column.title}>
              <p className="text-label uppercase tracking-wide text-neutral-400">{column.title}</p>
              <ul className="mt-3 flex flex-col gap-2">
                {column.items.map((item) => (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className="text-body-sm text-neutral-600 hover:text-neutral-900 dark:text-text-dark-secondary dark:hover:text-text-dark-primary"
                    >
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {socialLinks.length > 0 && (
          <div className="mt-8 flex gap-4 border-t border-neutral-200 pt-6 dark:border-surface-dark-border">
            {socialLinks.map((social) => (
              <a
                key={social.platform}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-body-sm text-neutral-500 hover:text-neutral-800 dark:text-text-dark-secondary dark:hover:text-text-dark-primary"
              >
                {social.platform}
              </a>
            ))}
          </div>
        )}

        <div className="mt-8 border-t border-neutral-200 pt-6 text-caption text-neutral-400 dark:border-surface-dark-border">
          © {new Date().getFullYear()} {siteName}. All rights reserved.
        </div>
      </Container>
    </footer>
  );
}
