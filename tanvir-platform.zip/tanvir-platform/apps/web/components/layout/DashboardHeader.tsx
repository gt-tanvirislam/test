"use client";

import { Bell } from "lucide-react";

import { Breadcrumb } from "@/components/dashboard/Breadcrumb";
import { MobileNav } from "@/components/dashboard/MobileNav";
import { ThemeSwitch } from "@/components/dashboard/ThemeSwitch";
import { UserMenu } from "@/components/dashboard/UserMenu";

/**
 * Dashboard top bar — Sprint 1 completes Sprint 0's skeleton with the
 * real controls this sprint scopes: breadcrumb, mobile nav trigger,
 * theme switch, user menu, and a notification placeholder (real data
 * wired once the Notifications backend module exists, per this sprint's
 * explicit "placeholder only" instruction).
 */
export function DashboardHeader() {
  return (
    <header className="flex h-16 items-center justify-between border-b border-neutral-200 bg-neutral-0 px-4 dark:border-surface-dark-border dark:bg-surface-dark-base md:px-6">
      <div className="flex items-center gap-3">
        <MobileNav />
        <div className="hidden md:block">
          <Breadcrumb />
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          type="button"
          aria-label="Notifications (coming soon)"
          disabled
          className="flex h-9 w-9 items-center justify-center rounded-sm text-neutral-400 opacity-60"
        >
          <Bell size={18} />
        </button>
        <ThemeSwitch />
        <UserMenu />
      </div>
    </header>
  );
}
