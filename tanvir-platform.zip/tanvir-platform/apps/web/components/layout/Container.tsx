import * as React from "react";
import { cn } from "@tanvir-platform/ui";

export interface ContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  as?: React.ElementType;
}

/**
 * Container (Sprint 7). Extracted from NavBar/Footer's inline
 * `mx-auto max-w-[1440px] px-6` (Sprint 5) the moment a third consumer
 * (this sprint's page scaffolds) would otherwise have copy-pasted it
 * again. Every future public page (Homepage, About, Services, Portfolio,
 * Blog, Contact) wraps its content in this rather than reimplementing
 * the max-width/padding pattern.
 *
 * Max-width matches Phase 2.5 §5's `2xl` breakpoint container cap
 * ("content max-width capped... so ultra-wide monitors don't produce
 * absurdly wide text lines").
 */
export function Container({ as: Component = "div", className, ...props }: ContainerProps) {
  return <Component className={cn("mx-auto w-full max-w-[1440px] px-6", className)} {...props} />;
}
