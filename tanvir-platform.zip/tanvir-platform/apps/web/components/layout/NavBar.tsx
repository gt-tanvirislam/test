"use client";

import { Drawer } from "@tanvir-platform/ui";
import { Menu, Moon, Sun } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import * as React from "react";

import { useTheme } from "@/lib/theme/ThemeProvider";

import { Container } from "./Container";

export interface NavItem {
  label: string;
  href: string;
}

export interface NavBarProps {
  siteName: string;
  items: NavItem[];
}

/**
 * Public NavBar (Sprint 5 §5, extended Sprint 7 with active-route
 * highlighting and the shared Container). `items` remains a prop, not
 * hardcoded marketing navigation — sourced from `getSiteConfig()`
 * (Sprint 7) so a future Settings/Navigation backend module swaps in
 * without touching this component.
 */
export function NavBar({ siteName, items }: NavBarProps) {
  const [scrolled, setScrolled] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const { theme, toggleTheme } = useTheme();
  const pathname = usePathname();

  React.useEffect(() => {
    function handleScroll() {
      setScrolled(window.scrollY > 24);
    }
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  function isActive(href: string) {
    return href === "/" ? pathname === "/" : pathname.startsWith(href);
  }

  return (
    <header
      className={`sticky top-0 z-sticky transition-colors duration-base ${
        scrolled
          ? "border-b border-neutral-200/60 bg-neutral-0/72 backdrop-blur-md dark:border-surface-dark-border/60 dark:bg-surface-dark-base/72"
          : "bg-transparent"
      }`}
    >
      <Container className="flex items-center justify-between py-4">
        <Link href="/" className="text-h4 font-semibold text-neutral-800 dark:text-text-dark-primary">
          {siteName}
        </Link>

        <nav className="hidden items-center gap-6 md:flex" aria-label="Primary navigation">
          {items.map((item) => {
            const active = isActive(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={`text-nav transition-colors ${
                  active
                    ? "text-neutral-900 dark:text-text-dark-primary"
                    : "text-neutral-600 hover:text-neutral-900 dark:text-text-dark-secondary dark:hover:text-text-dark-primary"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggleTheme}
            aria-label={theme === "light" ? "Switch to dark theme" : "Switch to light theme"}
            className="flex h-9 w-9 items-center justify-center rounded-full text-neutral-500 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-2"
          >
            {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
            className="flex h-9 w-9 items-center justify-center rounded-full text-neutral-500 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-2 md:hidden"
          >
            <Menu size={18} />
          </button>
        </div>
      </Container>

      <Drawer open={mobileOpen} onClose={() => setMobileOpen(false)} title={siteName} side="right">
        <nav className="mt-4 flex flex-col gap-1" aria-label="Mobile navigation">
          {items.map((item) => {
            const active = isActive(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                aria-current={active ? "page" : undefined}
                className={`rounded-md px-2 py-2.5 text-body ${
                  active
                    ? "bg-accent-50 font-medium text-accent-600 dark:bg-surface-dark-2 dark:text-accent-400"
                    : "text-neutral-700 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-1"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </Drawer>
    </header>
  );
}
