import { Container } from "./Container";

export interface PageScaffoldProps {
  label: string;
  note: string;
}

/**
 * Shared scaffold for public routes whose real content is a future
 * sprint's responsibility (Homepage, About, Services, Portfolio, Blog
 * index, Contact — Sprint 7 builds only the route + layout + SEO
 * plumbing per its explicit scope). Extracted as one component rather
 * than five copies of the same placeholder markup, matching this
 * sprint's own "never duplicate components" rule applied to itself.
 */
export function PageScaffold({ label, note }: PageScaffoldProps) {
  return (
    <Container className="flex flex-1 items-center justify-center py-24 text-center">
      <div className="max-w-md">
        <p className="text-label uppercase tracking-wide text-neutral-400">Public Foundation</p>
        <h1 className="mt-3 text-h2 text-neutral-800 dark:text-text-dark-primary">{label}</h1>
        <p className="mt-3 text-body text-neutral-500 dark:text-text-dark-secondary">{note}</p>
      </div>
    </Container>
  );
}
