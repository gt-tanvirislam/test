import type { BlogPostListItem } from "@tanvir-platform/types";
import { SectionHeader } from "@tanvir-platform/ui";
import Link from "next/link";

import { Container } from "@/components/layout/Container";
import { BlogCard } from "@/components/features/content-display";

export interface LatestBlogPostsProps {
  posts: BlogPostListItem[];
}

/** Latest Blog Posts section (Sprint 9). Same fetched-as-prop, graceful-
 * empty pattern as the other two content preview sections. */
export function LatestBlogPosts({ posts }: LatestBlogPostsProps) {
  if (posts.length === 0) return null;

  return (
    <section className="py-20">
      <Container>
        <div className="flex items-end justify-between">
          <SectionHeader eyebrow="From the blog" title="Latest Articles" />
          <Link
            href="/blog"
            className="hidden text-body-sm text-neutral-500 hover:text-neutral-800 dark:text-text-dark-secondary dark:hover:text-text-dark-primary sm:block"
          >
            View all posts →
          </Link>
        </div>
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
          {posts.map((post) => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
      </Container>
    </section>
  );
}
