import { SectionHeader } from "@tanvir-platform/ui";

import { Container } from "@/components/layout/Container";
import type { HomepageContent } from "@/lib/config/site";

export interface ProcessStepsProps {
  content: HomepageContent["process"];
}

/**
 * Process / How We Work section (Sprint 9). Horizontal steps on desktop,
 * stacked on mobile (Phase 2.6 §2's "Work Process" spec) — a numbered
 * connector line rather than icons, keeping it text-forward and simple
 * per this sprint's "avoid clutter" direction.
 */
export function ProcessSteps({ content }: ProcessStepsProps) {
  return (
    <section className="py-20">
      <Container>
        <SectionHeader eyebrow={content.eyebrow} title={content.headline} className="text-center" />
        <ol className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-3">
          {content.steps.map((step, index) => (
            <li key={step.title} className="relative">
              <span className="text-h1 font-semibold text-accent-50 dark:text-surface-dark-2" aria-hidden>
                {String(index + 1).padStart(2, "0")}
              </span>
              <p className="-mt-6 text-card-title text-neutral-800 dark:text-text-dark-primary">
                {step.title}
              </p>
              <p className="mt-2 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
                {step.description}
              </p>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  );
}
