import { Card, SectionHeader } from "@tanvir-platform/ui";

import { Container } from "@/components/layout/Container";
import type { HomepageContent } from "@/lib/config/site";

export interface WhyChooseUsProps {
  content: HomepageContent["whyChooseUs"];
}

/**
 * Why Choose Us section (Sprint 9). Reuses `SectionHeader` — built in
 * Sprint 3 as part of the Universal Content Editor's shared component
 * set but never actually consumed by a public page until now. Content
 * is entirely prop-driven from `getHomepageContent()`, so this section
 * becomes CMS-driven later without a rewrite, per this sprint's
 * explicit requirement.
 */
export function WhyChooseUs({ content }: WhyChooseUsProps) {
  return (
    <section className="py-20">
      <Container>
        <SectionHeader eyebrow={content.eyebrow} title={content.headline} className="text-center" />
        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-3">
          {content.items.map((item) => (
            <Card key={item.title}>
              <p className="text-card-title text-neutral-800 dark:text-text-dark-primary">{item.title}</p>
              <p className="mt-2 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
                {item.description}
              </p>
            </Card>
          ))}
        </div>
      </Container>
    </section>
  );
}
