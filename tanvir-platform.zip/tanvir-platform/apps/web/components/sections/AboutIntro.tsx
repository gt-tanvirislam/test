import { buttonVariants, cn } from "@tanvir-platform/ui";
import Link from "next/link";

import { Container } from "@/components/layout/Container";
import type { HomepageContent } from "@/lib/config/site";

export interface AboutIntroProps {
  content: HomepageContent["aboutIntro"];
}

/**
 * About/Introduction section (Sprint 9). Per this sprint's explicit
 * instruction: no new CMS table for this — content flows through
 * `getHomepageContent()` (the same site-configuration seam Sprint 7
 * established), which is the "future-ready" path this sprint calls for.
 * A real About-page-backed CMS module can be introduced later without
 * this component changing — only its data source would.
 */
export function AboutIntro({ content }: AboutIntroProps) {
  return (
    <section className="py-20">
      <Container className="grid grid-cols-1 items-center gap-10 md:grid-cols-2">
        <div>
          <p className="text-label uppercase tracking-wide text-accent-500">{content.eyebrow}</p>
          <h2 className="mt-3 text-h2 text-neutral-800 dark:text-text-dark-primary">{content.headline}</h2>
        </div>
        <div>
          <p className="text-body text-neutral-600 dark:text-text-dark-secondary">{content.body}</p>
          <Link
            href={content.ctaHref}
            className={cn(buttonVariants({ variant: "tertiary", size: "md" }), "mt-4 px-0")}
          >
            {content.ctaLabel} →
          </Link>
        </div>
      </Container>
    </section>
  );
}
