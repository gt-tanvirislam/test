"use client";

import { buttonVariants, cn } from "@tanvir-platform/ui";
import { motion } from "framer-motion";
import Link from "next/link";

import { Container } from "@/components/layout/Container";
import type { HomepageContent } from "@/lib/config/site";
import { useReducedMotion } from "@/lib/hooks/useReducedMotion";

export interface HeroProps {
  content: HomepageContent["hero"];
}

/**
 * Hero section (Sprint 9). The single most important section on the
 * page — content comes entirely from `getHomepageContent()`, this
 * component owns only layout/motion. A single Framer Motion fade-up on
 * mount (Phase 2.5 §6's "biggest, slowest animation... most important
 * moment"), respecting reduced-motion via the existing hook rather than
 * a new check.
 */
export function Hero({ content }: HeroProps) {
  const reducedMotion = useReducedMotion();

  return (
    <section className="relative overflow-hidden py-24 md:py-32">
      {/* Subtle gradient — restrained, not a busy background image, per
       * this sprint's "avoid unnecessary glassmorphism/clutter" rule. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-gradient-to-b from-accent-50/40 to-transparent dark:from-surface-dark-1/60"
      />

      <Container className="relative flex flex-col items-center text-center">
        <motion.div
          initial={reducedMotion ? undefined : { opacity: 0, y: 16 }}
          animate={reducedMotion ? undefined : { opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0, 0, 0.2, 1] }}
        >
          <p className="text-label uppercase tracking-wide text-accent-500">{content.eyebrow}</p>
          <h1 className="mt-4 max-w-3xl text-display font-[var(--font-display)] text-neutral-900 dark:text-text-dark-primary">
            {content.headline}
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-subtitle text-neutral-500 dark:text-text-dark-secondary">
            {content.subheadline}
          </p>

          <div className="mt-10 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
            <Link
              href={content.primaryCta.href}
              className={buttonVariants({ variant: "primary", size: "lg" })}
            >
              {content.primaryCta.label}
            </Link>
            {content.secondaryCta && (
              <Link
                href={content.secondaryCta.href}
                className={cn(buttonVariants({ variant: "secondary", size: "lg" }))}
              >
                {content.secondaryCta.label}
              </Link>
            )}
          </div>
        </motion.div>
      </Container>
    </section>
  );
}
