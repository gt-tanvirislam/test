import { SectionHeader } from "@tanvir-platform/ui";
import Link from "next/link";

import { Container } from "@/components/layout/Container";
import { ServiceCard } from "@/components/features/content-display";
import type { PublicServiceListItem } from "@/lib/api/public";

export interface ServicesPreviewProps {
  services: PublicServiceListItem[];
}

/**
 * Services Preview section (Sprint 9). Receives already-fetched data as
 * a prop (fetched server-side in page.tsx via `getFeaturedServices()`,
 * Sprint 8) — this component has no data-fetching of its own, keeping
 * it a pure presentational Server Component.
 *
 * Empty state (Phase 2.6 §11's graceful-empty-content pattern): the
 * section simply doesn't render rather than showing an empty grid — a
 * fresh site with zero published services shouldn't show a broken-
 * looking section.
 */
export function ServicesPreview({ services }: ServicesPreviewProps) {
  if (services.length === 0) return null;

  return (
    <section className="py-20">
      <Container>
        <div className="flex items-end justify-between">
          <SectionHeader eyebrow="What I offer" title="Services" />
          <Link
            href="/services"
            className="hidden text-body-sm text-neutral-500 hover:text-neutral-800 dark:text-text-dark-secondary dark:hover:text-text-dark-primary sm:block"
          >
            View all services →
          </Link>
        </div>
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
          {services.map((service) => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>
      </Container>
    </section>
  );
}
