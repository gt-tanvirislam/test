import { buttonVariants, cn } from "@tanvir-platform/ui";
import Link from "next/link";

import { Container } from "@/components/layout/Container";

export interface CTASectionProps {
  headline: string;
  subheadline?: string;
  ctaLabel: string;
  ctaHref: string;
}

/**
 * Reusable CTA section (Sprint 9 — this sprint's explicit requirement:
 * "Reusable CTA component... Future-ready for CMS configuration").
 * Every field is a prop; content comes from `getHomepageContent()` for
 * the Homepage's Final CTA, and any future page (a Service detail page's
 * closing CTA, per Phase 2.6 §4.2) reuses this exact component with its
 * own content rather than a new one-off section.
 */
export function CTASection({ headline, subheadline, ctaLabel, ctaHref }: CTASectionProps) {
  return (
    <section className="border-t border-neutral-200 bg-neutral-50 py-20 dark:border-surface-dark-border dark:bg-surface-dark-1">
      <Container className="flex flex-col items-center text-center">
        <h2 className="max-w-xl text-h2 text-neutral-800 dark:text-text-dark-primary">{headline}</h2>
        {subheadline && (
          <p className="mt-4 max-w-md text-body text-neutral-500 dark:text-text-dark-secondary">
            {subheadline}
          </p>
        )}
        <Link
          href={ctaHref}
          className={cn(buttonVariants({ variant: "primary", size: "lg" }), "mt-8")}
        >
          {ctaLabel}
        </Link>
      </Container>
    </section>
  );
}
