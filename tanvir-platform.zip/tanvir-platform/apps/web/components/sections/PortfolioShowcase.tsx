import type { PortfolioItemListItem } from "@tanvir-platform/types";
import { SectionHeader } from "@tanvir-platform/ui";
import Link from "next/link";

import { Container } from "@/components/layout/Container";
import { PortfolioCard } from "@/components/features/content-display";

export interface PortfolioShowcaseProps {
  items: PortfolioItemListItem[];
}

/** Portfolio Showcase section (Sprint 9). Same fetched-as-prop pattern
 * as ServicesPreview — data comes from `getFeaturedPortfolioItems()`
 * (Sprint 7/9), which already falls back to recent work when nothing is
 * marked featured, so this component only needs to handle the
 * genuinely-empty (zero published items) case. */
export function PortfolioShowcase({ items }: PortfolioShowcaseProps) {
  if (items.length === 0) return null;

  return (
    <section className="bg-neutral-50 py-20 dark:bg-surface-dark-1">
      <Container>
        <div className="flex items-end justify-between">
          <SectionHeader eyebrow="Recent work" title="Featured Projects" />
          <Link
            href="/portfolio"
            className="hidden text-body-sm text-neutral-500 hover:text-neutral-800 dark:text-text-dark-secondary dark:hover:text-text-dark-primary sm:block"
          >
            View full portfolio →
          </Link>
        </div>
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <PortfolioCard key={item.id} item={item} />
          ))}
        </div>
      </Container>
    </section>
  );
}
