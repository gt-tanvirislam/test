"use client";

import { Input } from "@tanvir-platform/ui";
import { Search } from "lucide-react";
import * as React from "react";

import { useUsers } from "@/lib/hooks/useUsers";

export interface AuthorSelectProps {
  value: string | null;
  onChange: (authorId: string | null) => void;
  /** "filter" shows an "All authors" option (toolbar use); "assign"
   * doesn't (editor use, a post always has exactly one author). */
  mode?: "filter" | "assign";
  label?: string;
}

/**
 * Reusable author select with search (this sprint's §2 — "Author
 * selector", "Author search"). Generic over any content module that
 * needs author filtering/attribution — Portfolio reuses this directly,
 * per the same reuse principle established for CategorySelectField in
 * Sprint 4.
 *
 * Search is debounced server-side via useUsers(search); the dropdown
 * itself is a simple listbox rather than a full combobox library, since
 * the realistic author list size (a handful of admins/editors) doesn't
 * justify heavier UI at this stage.
 */
export function AuthorSelect({ value, onChange, mode = "filter", label = "Author" }: AuthorSelectProps) {
  const [query, setQuery] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const containerRef = React.useRef<HTMLDivElement>(null);

  const { data: users = [] } = useUsers(query || undefined);
  const selected = users.find((u) => u.id === value);

  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative">
      {label && (
        <label className="mb-1.5 block text-label text-neutral-700 dark:text-text-dark-secondary">
          {label}
        </label>
      )}
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        className="flex h-11 w-full items-center justify-between rounded-sm border border-neutral-300 px-3 text-body text-neutral-800 dark:border-surface-dark-border dark:bg-surface-dark-1 dark:text-text-dark-primary"
      >
        <span>{selected?.full_name ?? (mode === "filter" ? "All authors" : "Select author")}</span>
        <Search size={14} className="text-neutral-400" />
      </button>

      {open && (
        <div className="absolute z-dropdown mt-1 w-full rounded-sm border border-neutral-200 bg-neutral-0 shadow-md dark:border-surface-dark-border dark:bg-surface-dark-2">
          <div className="p-2">
            <Input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name or email…"
            />
          </div>
          <ul className="max-h-56 overflow-y-auto py-1">
            {mode === "filter" && (
              <li>
                <button
                  type="button"
                  onClick={() => {
                    onChange(null);
                    setOpen(false);
                  }}
                  className="w-full px-3 py-1.5 text-left text-body-sm text-neutral-600 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-1"
                >
                  All authors
                </button>
              </li>
            )}
            {users.map((user) => (
              <li key={user.id}>
                <button
                  type="button"
                  onClick={() => {
                    onChange(user.id);
                    setOpen(false);
                  }}
                  className="w-full px-3 py-1.5 text-left text-body-sm text-neutral-700 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-1"
                >
                  {user.full_name}
                  <span className="ml-1 text-caption text-neutral-400">{user.email}</span>
                </button>
              </li>
            ))}
            {users.length === 0 && (
              <li className="px-3 py-2 text-caption text-neutral-400">No matching users</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
}
