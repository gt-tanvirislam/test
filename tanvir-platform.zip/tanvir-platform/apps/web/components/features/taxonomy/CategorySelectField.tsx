"use client";

import { Button, Label, Modal, Select } from "@tanvir-platform/ui";
import { Plus } from "lucide-react";
import * as React from "react";

export interface CategoryOption {
  id: string;
  name: string;
}

export interface CategorySelectFieldProps {
  label?: string;
  categories: CategoryOption[];
  value: string | null;
  onChange: (categoryId: string | null) => void;
  onCreateCategory: (name: string) => Promise<void>;
  isCreating?: boolean;
}

/**
 * Generic category select (this sprint's requirement: "reusable category
 * management... future modules must be able to reuse it").
 *
 * Deliberately takes `categories`/`onCreateCategory` as props rather than
 * calling Blog's API directly — this is what makes it genuinely reusable:
 * a future PortfolioEditor renders the exact same component, passing
 * `useCategories`-equivalent Portfolio hooks instead of Blog's. Per
 * Phase 2.2's design, each content type still gets its own categories
 * table — this component is the reusable UI/interaction layer on top of
 * that, not a claim that the data itself is shared (unlike Tags, which
 * genuinely are shared — see TagInput's `suggestions` prop).
 */
export function CategorySelectField({
  label = "Category",
  categories,
  value,
  onChange,
  onCreateCategory,
  isCreating,
}: CategorySelectFieldProps) {
  const [modalOpen, setModalOpen] = React.useState(false);
  const [newCategoryName, setNewCategoryName] = React.useState("");

  async function handleCreate() {
    if (!newCategoryName.trim()) return;
    await onCreateCategory(newCategoryName.trim());
    setNewCategoryName("");
    setModalOpen(false);
  }

  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <Label htmlFor="category-select" className="mb-0">
          {label}
        </Label>
        <button
          type="button"
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-1 text-caption text-accent-500 hover:text-accent-600"
        >
          <Plus size={12} />
          New
        </button>
      </div>

      <Select
        id="category-select"
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value || null)}
      >
        <option value="">No category</option>
        {categories.map((category) => (
          <option key={category.id} value={category.id}>
            {category.name}
          </option>
        ))}
      </Select>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={`New ${label.toLowerCase()}`}>
        <div className="flex flex-col gap-3">
          <input
            autoFocus
            value={newCategoryName}
            onChange={(e) => setNewCategoryName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            placeholder="Category name"
            className="h-11 w-full rounded-sm border border-neutral-300 px-3 text-body dark:border-surface-dark-border dark:bg-surface-dark-1"
          />
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreate} loading={isCreating} disabled={isCreating}>
              Create
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
