"use client";

import type { MediaAsset } from "@tanvir-platform/types";
import { FormField, Input, Select, Textarea } from "@tanvir-platform/ui";
import * as React from "react";

import { FeaturedImageField } from "./FeaturedImageField";

export interface SeoPanelValues {
  meta_title: string;
  meta_description: string;
  canonical_override: string;
  noindex: boolean;
  twitter_card_type: string;
  robots_directive: string;
  json_ld_override: string;
}

export interface SeoPanelProps {
  values: SeoPanelValues;
  onChange: (values: SeoPanelValues) => void;
  ogImage: MediaAsset | null;
  onOgImageChange: (asset: MediaAsset | null) => void;
  /** Falls back to the content title/excerpt when the override fields
   * are empty — mirrors the backend's buildMetadata() fallback chain
   * (Phase 2.7 §10) so the preview is representative of what actually
   * ships. */
  fallbackTitle?: string;
  fallbackDescription?: string;
}

/**
 * SEO panel (this sprint's §6). Every future content module's editor
 * sidebar includes this exact panel (Phase 2.4 §7's SEO tab) — meta
 * title/description limits match the backend's Pydantic constraints
 * exactly (modules/seo/schemas.py) so client-side and server-side
 * validation never disagree.
 */
export function SeoPanel({
  values,
  onChange,
  ogImage,
  onOgImageChange,
  fallbackTitle = "",
  fallbackDescription = "",
}: SeoPanelProps) {
  function set<K extends keyof SeoPanelValues>(key: K, value: SeoPanelValues[K]) {
    onChange({ ...values, [key]: value });
  }

  const previewTitle = values.meta_title || fallbackTitle;
  const previewDescription = values.meta_description || fallbackDescription;

  return (
    <div className="flex flex-col gap-4">
      {/* Google-style search result preview — helps a non-technical
       * author judge the real-world effect of these fields, per Phase
       * 2.4 §7's "live Google-style preview snippet". */}
      <div className="rounded-md border border-neutral-200 p-3 dark:border-surface-dark-border">
        <p className="truncate text-body-sm text-info-500">{previewTitle || "Page title"}</p>
        <p className="truncate text-caption text-success-500">yoursite.com</p>
        <p className="line-clamp-2 text-caption text-neutral-500 dark:text-text-dark-secondary">
          {previewDescription || "A meta description will appear here."}
        </p>
      </div>

      <FormField label="Meta title" htmlFor="seo-title">
        <Input
          id="seo-title"
          value={values.meta_title}
          onChange={(e) => set("meta_title", e.target.value)}
          maxLength={70}
          placeholder={fallbackTitle}
        />
        <p className="mt-1 text-right text-caption text-neutral-400">{values.meta_title.length} / 70</p>
      </FormField>

      <FormField label="Meta description" htmlFor="seo-description">
        <Textarea
          id="seo-description"
          value={values.meta_description}
          onChange={(e) => set("meta_description", e.target.value)}
          maxLength={160}
          rows={3}
          placeholder={fallbackDescription}
        />
        <p className="mt-1 text-right text-caption text-neutral-400">
          {values.meta_description.length} / 160
        </p>
      </FormField>

      <FeaturedImageField value={ogImage} onChange={onOgImageChange} />

      <FormField label="Canonical URL override" htmlFor="seo-canonical">
        <Input
          id="seo-canonical"
          value={values.canonical_override}
          onChange={(e) => set("canonical_override", e.target.value)}
          placeholder="Leave blank to use the default URL"
        />
      </FormField>

      <FormField label="Twitter card type" htmlFor="seo-twitter">
        <Select
          id="seo-twitter"
          value={values.twitter_card_type}
          onChange={(e) => set("twitter_card_type", e.target.value)}
        >
          <option value="summary_large_image">Summary with large image</option>
          <option value="summary">Summary</option>
        </Select>
      </FormField>

      <label className="flex items-center gap-2 text-body-sm text-neutral-700 dark:text-text-dark-secondary">
        <input
          type="checkbox"
          checked={values.noindex}
          onChange={(e) => set("noindex", e.target.checked)}
          className="h-4 w-4 rounded-sm border-neutral-300 text-accent-500 focus-visible:ring-2 focus-visible:ring-accent-500/40"
        />
        Hide from search engines (noindex)
      </label>

      <FormField label="Structured data override (JSON-LD)" htmlFor="seo-jsonld">
        <Textarea
          id="seo-jsonld"
          value={values.json_ld_override}
          onChange={(e) => set("json_ld_override", e.target.value)}
          rows={4}
          className="font-mono text-caption"
          placeholder="Advanced — leave blank to use automatic structured data"
        />
      </FormField>
    </div>
  );
}

export const emptySeoPanelValues: SeoPanelValues = {
  meta_title: "",
  meta_description: "",
  canonical_override: "",
  noindex: false,
  twitter_card_type: "summary_large_image",
  robots_directive: "",
  json_ld_override: "",
};
