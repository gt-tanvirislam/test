/**
 * Universal Content Editor — barrel export (Sprint 3 / Phase 3.3).
 *
 * Future modules (Blog, Portfolio, Services) import everything they need
 * for a content editor from this single path:
 *
 *   import {
 *     ContentEditorShell, TitleSlugFields, ExcerptField, RichTextField,
 *     FeaturedImageField, GalleryField, TagInput, SeoPanel, PublishPanel,
 *     AutosaveIndicator,
 *   } from "@/components/features/content-editor";
 *
 * See docs reference: Phase 2.4 §4 (editor shell shape), Phase 2.4 §7
 * (field list), Phase 2.3 §18 (publish state machine these components
 * present), Phase 2.10 §2 (reuse-first rule this whole module exists to
 * satisfy).
 */
export { ContentEditorShell } from "./ContentEditorShell";
export { TitleSlugFields } from "./TitleSlugFields";
export { ExcerptField } from "./ExcerptField";
export { RichTextField } from "./RichTextField";
export { FeaturedImageField } from "./FeaturedImageField";
export { GalleryField } from "./GalleryField";
export { BeforeAfterPairsField } from "./BeforeAfterPairsField";
export type { BeforeAfterPairDraft } from "./BeforeAfterPairsField";
export { ServiceListItemsField } from "./ServiceListItemsField";
export { MediaPickerModal } from "./MediaPickerModal";
export { TagInput } from "./TagInput";
export { SeoPanel, emptySeoPanelValues } from "./SeoPanel";
export type { SeoPanelValues } from "./SeoPanel";
export { PublishPanel } from "./PublishPanel";
export type { ContentStatus } from "./PublishPanel";
export { AutosaveIndicator } from "./AutosaveIndicator";
