"use client";

import type { MediaAsset } from "@tanvir-platform/types";
import { EmptyState, Modal, Skeleton } from "@tanvir-platform/ui";
import { ImageOff } from "lucide-react";

import { MediaGrid } from "@/components/dashboard/media/MediaGrid";
import { useMediaAssets } from "@/lib/hooks/useMedia";

export interface MediaPickerModalProps {
  open: boolean;
  onClose: () => void;
  onSelect: (asset: MediaAsset) => void;
}

/**
 * Media picker (reuses Sprint 2's MediaGrid and useMediaAssets rather
 * than building a new asset browser — per this sprint's explicit
 * "check whether an existing reusable component already satisfies the
 * requirement" rule). Used by both FeaturedImageField and GalleryField
 * below, so there's exactly one media-browsing UI in the whole CMS.
 */
export function MediaPickerModal({ open, onClose, onSelect }: MediaPickerModalProps) {
  const { data, isLoading } = useMediaAssets();
  const assets = data?.data ?? [];

  return (
    <Modal open={open} onClose={onClose} title="Select media" className="max-w-3xl">
      {isLoading ? (
        <div className="grid grid-cols-4 gap-4 sm:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="aspect-square" ><Skeleton className="h-full w-full" /></div>
          ))}
        </div>
      ) : assets.length === 0 ? (
        <EmptyState
          icon={<ImageOff size={28} />}
          title="No media yet"
          description="Upload files from the Media Library first."
        />
      ) : (
        <MediaGrid
          assets={assets}
          onSelect={(asset) => {
            onSelect(asset);
            onClose();
          }}
        />
      )}
    </Modal>
  );
}
