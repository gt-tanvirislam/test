"use client";

import type { MediaAsset } from "@tanvir-platform/types";
import { Button, Label } from "@tanvir-platform/ui";
import { ImagePlus, X } from "lucide-react";
import * as React from "react";

import { MediaPickerModal } from "./MediaPickerModal";

export interface FeaturedImageFieldProps {
  value: MediaAsset | null;
  onChange: (asset: MediaAsset | null) => void;
}

/** Featured Image field (this sprint's §2). Single-select over
 * MediaPickerModal — every future content module (Blog, Portfolio,
 * Services) uses this exact component for its featured image. */
export function FeaturedImageField({ value, onChange }: FeaturedImageFieldProps) {
  const [pickerOpen, setPickerOpen] = React.useState(false);

  return (
    <div>
      <Label>Featured image</Label>
      {value ? (
        <div className="relative overflow-hidden rounded-md border border-neutral-200 dark:border-surface-dark-border">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={value.public_url} alt={value.alt_text ?? ""} className="aspect-video w-full object-cover" />
          <button
            type="button"
            onClick={() => onChange(null)}
            aria-label="Remove featured image"
            className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-neutral-900/60 text-white hover:bg-neutral-900/80"
          >
            <X size={14} />
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setPickerOpen(true)}
          className="flex aspect-video w-full flex-col items-center justify-center gap-2 rounded-md border border-dashed border-neutral-300 text-neutral-400 hover:border-accent-500 hover:text-accent-500 dark:border-surface-dark-border"
        >
          <ImagePlus size={24} />
          <span className="text-body-sm">Choose an image</span>
        </button>
      )}

      {value && (
        <Button variant="tertiary" size="sm" className="mt-2" onClick={() => setPickerOpen(true)}>
          Change image
        </Button>
      )}

      <MediaPickerModal open={pickerOpen} onClose={() => setPickerOpen(false)} onSelect={onChange} />
    </div>
  );
}
