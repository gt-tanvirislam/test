"use client";

import type { MediaAsset } from "@tanvir-platform/types";
import { Button, Label } from "@tanvir-platform/ui";
import { GripVertical, ImagePlus, X } from "lucide-react";
import * as React from "react";

import { MediaPickerModal } from "./MediaPickerModal";

export interface GalleryFieldProps {
  value: MediaAsset[];
  onChange: (assets: MediaAsset[]) => void;
}

/**
 * Gallery field (this sprint's §2). Multi-select over MediaPickerModal,
 * with simple up/down reordering.
 *
 * Scope note: drag-and-drop reordering (Phase 2.4 §6's stated pattern)
 * is NOT implemented here — up/down buttons give the same end result
 * (a fully reorderable list) without adding a drag library dependency
 * to this foundation sprint. Swapping the reorder controls for real
 * drag-and-drop later only touches this one component.
 */
export function GalleryField({ value, onChange }: GalleryFieldProps) {
  const [pickerOpen, setPickerOpen] = React.useState(false);

  function addAsset(asset: MediaAsset) {
    if (value.some((a) => a.id === asset.id)) return; // no duplicates
    onChange([...value, asset]);
  }

  function removeAsset(assetId: string) {
    onChange(value.filter((a) => a.id !== assetId));
  }

  function moveAsset(index: number, direction: -1 | 1) {
    const newIndex = index + direction;
    if (newIndex < 0 || newIndex >= value.length) return;
    const next = [...value];
    [next[index], next[newIndex]] = [next[newIndex], next[index]];
    onChange(next);
  }

  return (
    <div>
      <Label>Gallery</Label>

      {value.length > 0 && (
        <ul className="mb-3 flex flex-col gap-2">
          {value.map((asset, index) => (
            <li
              key={asset.id}
              className="flex items-center gap-3 rounded-sm border border-neutral-200 p-2 dark:border-surface-dark-border"
            >
              <GripVertical size={16} className="shrink-0 text-neutral-300" aria-hidden />
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={asset.public_url}
                alt={asset.alt_text ?? ""}
                className="h-10 w-10 shrink-0 rounded-sm object-cover"
              />
              <span className="min-w-0 flex-1 truncate text-body-sm text-neutral-700 dark:text-text-dark-secondary">
                {asset.file_name}
              </span>
              <div className="flex shrink-0 items-center gap-1">
                <button
                  type="button"
                  onClick={() => moveAsset(index, -1)}
                  disabled={index === 0}
                  aria-label="Move up"
                  className="rounded-sm px-1.5 py-1 text-neutral-400 hover:text-neutral-700 disabled:opacity-30"
                >
                  ↑
                </button>
                <button
                  type="button"
                  onClick={() => moveAsset(index, 1)}
                  disabled={index === value.length - 1}
                  aria-label="Move down"
                  className="rounded-sm px-1.5 py-1 text-neutral-400 hover:text-neutral-700 disabled:opacity-30"
                >
                  ↓
                </button>
                <button
                  type="button"
                  onClick={() => removeAsset(asset.id)}
                  aria-label={`Remove ${asset.file_name}`}
                  className="rounded-sm px-1.5 py-1 text-neutral-400 hover:text-error-500"
                >
                  <X size={14} />
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <Button variant="secondary" size="sm" onClick={() => setPickerOpen(true)}>
        <ImagePlus size={14} />
        Add images
      </Button>

      <MediaPickerModal open={pickerOpen} onClose={() => setPickerOpen(false)} onSelect={addAsset} />
    </div>
  );
}
