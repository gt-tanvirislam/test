"use client";

import type { ServiceListItemInput } from "@tanvir-platform/types";
import { Button, Input, Label } from "@tanvir-platform/ui";
import { GripVertical, Plus, X } from "lucide-react";

export interface ServiceListItemsFieldProps {
  label: string;
  value: ServiceListItemInput[];
  onChange: (items: ServiceListItemInput[]) => void;
  placeholder?: string;
}

/**
 * Reusable ordered title+description list editor (Sprint 8). Used three
 * times within one ServiceEditor (Features/Benefits/Process) — the
 * backend already unified these into one `service_list_items` table
 * with a type discriminator (per this sprint's pre-review); this
 * component is the matching single frontend implementation, mounted
 * three times with different labels/state rather than three separate
 * hand-built editors.
 */
export function ServiceListItemsField({ label, value, onChange, placeholder }: ServiceListItemsFieldProps) {
  function addItem() {
    onChange([...value, { title: "", description: "" }]);
  }

  function removeItem(index: number) {
    onChange(value.filter((_, i) => i !== index));
  }

  function updateItem(index: number, field: "title" | "description", fieldValue: string) {
    onChange(value.map((item, i) => (i === index ? { ...item, [field]: fieldValue } : item)));
  }

  function moveItem(index: number, direction: -1 | 1) {
    const newIndex = index + direction;
    if (newIndex < 0 || newIndex >= value.length) return;
    const next = [...value];
    [next[index], next[newIndex]] = [next[newIndex], next[index]];
    onChange(next);
  }

  return (
    <div>
      <Label>{label}</Label>

      {value.length > 0 && (
        <ul className="mb-3 flex flex-col gap-2">
          {value.map((item, index) => (
            <li
              key={index}
              className="flex items-start gap-2 rounded-sm border border-neutral-200 p-2 dark:border-surface-dark-border"
            >
              <GripVertical size={16} className="mt-2.5 shrink-0 text-neutral-300" aria-hidden />
              <div className="flex-1 space-y-1.5">
                <Input
                  value={item.title}
                  onChange={(e) => updateItem(index, "title", e.target.value)}
                  placeholder={placeholder ?? "Title"}
                />
                <Input
                  value={item.description ?? ""}
                  onChange={(e) => updateItem(index, "description", e.target.value)}
                  placeholder="Description (optional)"
                />
              </div>
              <div className="flex shrink-0 flex-col items-center gap-1 pt-1">
                <button
                  type="button"
                  onClick={() => moveItem(index, -1)}
                  disabled={index === 0}
                  aria-label="Move up"
                  className="text-neutral-400 hover:text-neutral-700 disabled:opacity-30"
                >
                  ↑
                </button>
                <button
                  type="button"
                  onClick={() => moveItem(index, 1)}
                  disabled={index === value.length - 1}
                  aria-label="Move down"
                  className="text-neutral-400 hover:text-neutral-700 disabled:opacity-30"
                >
                  ↓
                </button>
                <button
                  type="button"
                  onClick={() => removeItem(index)}
                  aria-label={`Remove item ${index + 1}`}
                  className="text-neutral-400 hover:text-error-500"
                >
                  <X size={14} />
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <Button variant="secondary" size="sm" onClick={addItem}>
        <Plus size={14} />
        Add item
      </Button>
    </div>
  );
}
