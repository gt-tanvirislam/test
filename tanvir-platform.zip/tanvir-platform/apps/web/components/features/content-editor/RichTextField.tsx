"use client";

import { FormField, Textarea } from "@tanvir-platform/ui";

export interface RichTextFieldProps {
  value: string;
  onChange: (value: string) => void;
  error?: string;
  label?: string;
}

/**
 * Rich Text field — FOUNDATION ONLY (this sprint's explicit scope
 * boundary, stated at sprint start). This is a clean, accessible,
 * MDX-compatible plain-text editing surface with the correct props
 * contract (`value`/`onChange`/`error`) that every future content module
 * can rely on.
 *
 * What this is NOT: the full rich toolbar (headings, bold/italic, image
 * drag-drop insertion, embedded TOC generation) specified in Phase 2.4
 * §7. That's substantial, MDX-editor-specific work best built directly
 * against the Blog module's real requirements in the Blog sprint, rather
 * than guessed at generically here. Swapping this component's internals
 * for a real MDX editor later is a one-file change — every consumer's
 * `value`/`onChange` contract stays the same.
 */
export function RichTextField({ value, onChange, error, label = "Content" }: RichTextFieldProps) {
  return (
    <FormField label={label} htmlFor="content-body" error={error}>
      <Textarea
        id="content-body"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        hasError={!!error}
        rows={16}
        className="font-mono text-body-sm"
        placeholder="Write in Markdown/MDX…"
      />
    </FormField>
  );
}
