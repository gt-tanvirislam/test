import * as React from "react";

export interface ContentEditorShellProps {
  title: string;
  saveBar: React.ReactNode;
  mainPanel: React.ReactNode;
  sidebarPanel: React.ReactNode;
}

/**
 * Content Editor Shell (Phase 2.4 §4): two-column layout (wide main
 * content area + fixed-width metadata sidebar), sticky save bar at top.
 * Every future content editor (BlogEditor, PortfolioEditor,
 * ServiceEditor) composes this shell rather than building its own page
 * layout — this is the single reusable pattern that makes the CMS
 * "learnable once, predictable everywhere" per Phase 2.4 §4.
 */
export function ContentEditorShell({ title, saveBar, mainPanel, sidebarPanel }: ContentEditorShellProps) {
  return (
    <div>
      <div className="sticky top-0 z-sticky -mx-6 mb-6 border-b border-neutral-200 bg-neutral-0/95 px-6 py-4 backdrop-blur-sm dark:border-surface-dark-border dark:bg-surface-dark-base/95">
        <div className="flex items-center justify-between gap-4">
          <h1 className="truncate text-h4 font-semibold text-neutral-800 dark:text-text-dark-primary">
            {title}
          </h1>
          <div className="flex shrink-0 items-center gap-3">{saveBar}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_320px]">
        <div className="min-w-0">{mainPanel}</div>
        <div className="flex flex-col gap-4">{sidebarPanel}</div>
      </div>
    </div>
  );
}
