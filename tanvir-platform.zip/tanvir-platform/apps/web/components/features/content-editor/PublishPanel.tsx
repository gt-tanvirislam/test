"use client";

import { Badge, Button, Card, FormField, Input } from "@tanvir-platform/ui";
import type { BadgeProps } from "@tanvir-platform/ui";
import * as React from "react";

export type ContentStatus = "draft" | "scheduled" | "published" | "archived";

const STATUS_TONE: Record<ContentStatus, NonNullable<BadgeProps["tone"]>> = {
  draft: "neutral",
  scheduled: "warning",
  published: "success",
  archived: "error",
};

const STATUS_LABEL: Record<ContentStatus, string> = {
  draft: "Draft",
  scheduled: "Scheduled",
  published: "Published",
  archived: "Archived",
};

export interface PublishPanelProps {
  status: ContentStatus;
  scheduledAt: string | null;
  onSaveDraft: () => void;
  onPublish: () => void;
  onUnpublish: () => void;
  onSchedule: (isoDateTime: string) => void;
  onArchive: () => void;
  onRestore: () => void;
  isSaving?: boolean;
}

/**
 * Publish panel (this sprint's §4 — draft/published/scheduled/archived,
 * matching Phase 2.3 §18's state machine exactly, and the
 * ContentLifecycleService built on the backend this sprint). Every
 * future content module's editor sidebar includes this — the state
 * transitions themselves are owned by the concrete module's API calls,
 * this component only presents the current state and the valid actions
 * from it.
 */
export function PublishPanel({
  status,
  scheduledAt,
  onSaveDraft,
  onPublish,
  onUnpublish,
  onSchedule,
  onArchive,
  onRestore,
  isSaving,
}: PublishPanelProps) {
  const [showScheduler, setShowScheduler] = React.useState(false);
  const [scheduleValue, setScheduleValue] = React.useState(scheduledAt ?? "");

  return (
    <Card>
      <div className="mb-4 flex items-center justify-between">
        <span className="text-label uppercase tracking-wide text-neutral-400">Status</span>
        <Badge tone={STATUS_TONE[status]}>{STATUS_LABEL[status]}</Badge>
      </div>

      {status === "scheduled" && scheduledAt && (
        <p className="mb-3 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
          Publishing {new Date(scheduledAt).toLocaleString()}
        </p>
      )}

      <div className="flex flex-col gap-2">
        {(status === "draft" || status === "archived") && (
          <Button size="sm" onClick={onSaveDraft} disabled={isSaving} loading={isSaving}>
            Save draft
          </Button>
        )}

        {status === "draft" && (
          <>
            <Button size="sm" variant="secondary" onClick={onPublish}>
              Publish now
            </Button>
            {!showScheduler ? (
              <Button size="sm" variant="tertiary" onClick={() => setShowScheduler(true)}>
                Schedule for later
              </Button>
            ) : (
              <FormField label="Publish date & time" htmlFor="schedule-datetime">
                <div className="flex gap-2">
                  <Input
                    id="schedule-datetime"
                    type="datetime-local"
                    value={scheduleValue}
                    onChange={(e) => setScheduleValue(e.target.value)}
                  />
                  <Button
                    size="sm"
                    onClick={() => scheduleValue && onSchedule(new Date(scheduleValue).toISOString())}
                    disabled={!scheduleValue}
                  >
                    Set
                  </Button>
                </div>
              </FormField>
            )}
          </>
        )}

        {status === "scheduled" && (
          <Button size="sm" variant="secondary" onClick={onPublish}>
            Publish now instead
          </Button>
        )}

        {status === "published" && (
          <Button size="sm" variant="secondary" onClick={onUnpublish}>
            Unpublish
          </Button>
        )}

        {status === "archived" ? (
          <Button size="sm" variant="tertiary" onClick={onRestore}>
            Restore to draft
          </Button>
        ) : (
          <Button size="sm" variant="destructive" onClick={onArchive}>
            Archive
          </Button>
        )}
      </div>
    </Card>
  );
}
