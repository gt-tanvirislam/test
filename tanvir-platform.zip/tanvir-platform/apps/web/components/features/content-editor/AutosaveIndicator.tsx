"use client";

import { Check, Loader2, AlertTriangle } from "lucide-react";

import type { AutosaveStatus } from "@/lib/hooks/useAutosave";

export interface AutosaveIndicatorProps {
  status: AutosaveStatus;
  lastSavedAt: Date | null;
}

/** Autosave indicator (this sprint's §5, Phase 2.4 §7's "Saved 12s ago"
 * sticky save-bar element). Purely presentational — reads the state
 * useAutosave already computed. */
export function AutosaveIndicator({ status, lastSavedAt }: AutosaveIndicatorProps) {
  if (status === "idle") return null;

  return (
    <div className="flex items-center gap-1.5 text-caption text-neutral-400">
      {status === "saving" && (
        <>
          <Loader2 size={12} className="animate-spin" />
          Saving…
        </>
      )}
      {status === "saved" && lastSavedAt && (
        <>
          <Check size={12} className="text-success-500" />
          Saved {formatRelativeTime(lastSavedAt)}
        </>
      )}
      {status === "error" && (
        <>
          <AlertTriangle size={12} className="text-error-500" />
          Couldn&apos;t save — check your connection
        </>
      )}
    </div>
  );
}

function formatRelativeTime(date: Date): string {
  const seconds = Math.round((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.round(seconds / 60);
  return `${minutes}m ago`;
}
