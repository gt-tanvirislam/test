"use client";

import { Badge, Label } from "@tanvir-platform/ui";
import { X } from "lucide-react";
import * as React from "react";

export interface TagInputProps {
  label: string;
  value: string[];
  onChange: (tags: string[]) => void;
  placeholder?: string;
  /** Real tag names to autocomplete against (this sprint's addition —
   * Blog is the first module with a genuine shared `tags` table to
   * suggest from, per Phase 2.2 §4.3). Omitted entirely, this component
   * still works exactly as it did in Sprint 3 as a free-text input. */
  suggestions?: string[];
}

/**
 * Generic tag input (Sprint 3's §2 — Categories/Tags), EXTENDED this
 * sprint with optional autocomplete rather than duplicated into a new
 * component, per this sprint's explicit reuse rule.
 */
export function TagInput({ label, value, onChange, placeholder, suggestions = [] }: TagInputProps) {
  const [draft, setDraft] = React.useState("");
  const [showSuggestions, setShowSuggestions] = React.useState(false);

  const matches = React.useMemo(() => {
    if (!draft.trim()) return [];
    const lower = draft.toLowerCase();
    return suggestions.filter((s) => s.toLowerCase().includes(lower) && !value.includes(s)).slice(0, 6);
  }, [draft, suggestions, value]);

  function addTag(raw: string) {
    const tag = raw.trim();
    if (!tag || value.includes(tag)) return;
    onChange([...value, tag]);
    setDraft("");
    setShowSuggestions(false);
  }

  function removeTag(tag: string) {
    onChange(value.filter((t) => t !== tag));
  }

  function handleKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Enter" || event.key === ",") {
      event.preventDefault();
      addTag(draft);
    } else if (event.key === "Backspace" && !draft && value.length > 0) {
      removeTag(value[value.length - 1]);
    } else if (event.key === "Escape") {
      setShowSuggestions(false);
    }
  }

  return (
    <div className="relative">
      <Label htmlFor={`tag-input-${label}`}>{label}</Label>
      <div className="flex flex-wrap items-center gap-1.5 rounded-sm border border-neutral-300 p-2 focus-within:ring-2 focus-within:ring-accent-500/40 dark:border-surface-dark-border">
        {value.map((tag) => (
          <Badge key={tag} tone="accent" className="gap-1 pr-1">
            {tag}
            <button
              type="button"
              onClick={() => removeTag(tag)}
              aria-label={`Remove ${tag}`}
              className="rounded-full p-0.5 hover:bg-accent-500/20"
            >
              <X size={10} />
            </button>
          </Badge>
        ))}
        <input
          id={`tag-input-${label}`}
          value={draft}
          onChange={(e) => {
            setDraft(e.target.value);
            setShowSuggestions(true);
          }}
          onKeyDown={handleKeyDown}
          onBlur={() => {
            addTag(draft);
            // Delay so a suggestion click registers before the list unmounts.
            setTimeout(() => setShowSuggestions(false), 150);
          }}
          placeholder={value.length === 0 ? placeholder : undefined}
          className="min-w-[120px] flex-1 border-none bg-transparent text-body-sm text-neutral-800 outline-none dark:text-text-dark-primary"
        />
      </div>

      {showSuggestions && matches.length > 0 && (
        <ul className="absolute z-dropdown mt-1 w-full rounded-sm border border-neutral-200 bg-neutral-0 py-1 shadow-md dark:border-surface-dark-border dark:bg-surface-dark-2">
          {matches.map((match) => (
            <li key={match}>
              <button
                type="button"
                onClick={() => addTag(match)}
                className="w-full px-3 py-1.5 text-left text-body-sm text-neutral-700 hover:bg-neutral-100 dark:text-text-dark-secondary dark:hover:bg-surface-dark-1"
              >
                {match}
              </button>
            </li>
          ))}
        </ul>
      )}

      <p className="mt-1 text-caption text-neutral-400">Press Enter or comma to add</p>
    </div>
  );
}
