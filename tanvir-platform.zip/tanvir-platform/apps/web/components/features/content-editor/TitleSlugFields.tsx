"use client";

import { FormField, Input } from "@tanvir-platform/ui";
import { Pencil } from "lucide-react";
import * as React from "react";

import { useSlugField } from "@/lib/hooks/useSlugField";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export interface TitleSlugFieldsProps {
  title: string;
  onTitleChange: (title: string) => void;
  slug: string;
  onSlugChange: (slug: string) => void;
  /** e.g. "/blog" or "/portfolio" — the URL preview prefix, since each
   * content type lives under a different route (Phase 2.7 §2). */
  urlPrefix: string;
  initialSlug?: string;
  checkSlugAvailability?: (slug: string) => Promise<boolean>;
  titleError?: string;
  slugError?: string;
}

/**
 * Title + Slug fields (this sprint's §2/§3 requirements). Composes
 * useSlugField for auto-generation/manual-lock/availability-checking,
 * and shows a live URL preview (Phase 2.4 §7's "live slug preview in
 * content editors").
 */
export function TitleSlugFields({
  title,
  onTitleChange,
  onSlugChange,
  urlPrefix,
  initialSlug,
  checkSlugAvailability,
  titleError,
  slugError,
}: TitleSlugFieldsProps) {
  const { slug, isManuallyEdited, availability, onManualChange, resetToAutoGenerate } = useSlugField({
    title,
    initialSlug,
    checkAvailability: checkSlugAvailability,
  });

  // Propagate slug changes to the parent form (react-hook-form or
  // whatever state the concrete editor uses) without this component
  // owning form state itself.
  React.useEffect(() => {
    onSlugChange(slug);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug]);

  return (
    <div className="flex flex-col gap-3">
      <FormField label="Title" htmlFor="content-title" error={titleError}>
        <Input
          id="content-title"
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          hasError={!!titleError}
          placeholder="Give this a clear, specific title"
        />
      </FormField>

      <div>
        <FormField label="URL slug" htmlFor="content-slug" error={slugError}>
          <div className="flex items-center gap-2">
            <span className="shrink-0 text-body-sm text-neutral-400">
              {SITE_URL}
              {urlPrefix}/
            </span>
            <Input
              id="content-slug"
              value={slug}
              onChange={(e) => onManualChange(e.target.value)}
              hasError={!!slugError || availability === "taken"}
            />
          </div>
        </FormField>

        <div className="mt-1 flex items-center justify-between text-caption">
          {availability === "checking" && <span className="text-neutral-400">Checking availability…</span>}
          {availability === "taken" && (
            <span className="text-error-500">This URL is already in use</span>
          )}
          {availability === "available" && <span className="text-success-500">Available</span>}
          {isManuallyEdited && (
            <button
              type="button"
              onClick={resetToAutoGenerate}
              className="ml-auto flex items-center gap-1 text-neutral-500 hover:text-neutral-700 dark:text-text-dark-secondary"
            >
              <Pencil size={12} />
              Reset to auto-generated
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
