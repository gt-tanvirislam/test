"use client";

import { FormField, Textarea } from "@tanvir-platform/ui";

export interface ExcerptFieldProps {
  value: string;
  onChange: (value: string) => void;
  error?: string;
  maxLength?: number;
}

/** Excerpt field (this sprint's §2). Thin composition over Textarea +
 * FormField with a character counter — kept as its own component (rather
 * than inlined per editor) so every future module's excerpt field looks
 * and behaves identically. */
export function ExcerptField({ value, onChange, error, maxLength = 300 }: ExcerptFieldProps) {
  return (
    <FormField label="Excerpt" htmlFor="content-excerpt" error={error}>
      <Textarea
        id="content-excerpt"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        hasError={!!error}
        maxLength={maxLength}
        rows={3}
        placeholder="A short summary shown in listings and search results"
      />
      <p className="mt-1 text-right text-caption text-neutral-400">
        {value.length} / {maxLength}
      </p>
    </FormField>
  );
}
