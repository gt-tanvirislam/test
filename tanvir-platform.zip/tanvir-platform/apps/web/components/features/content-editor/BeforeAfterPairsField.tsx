"use client";

import type { BeforeAfterPairInput, MediaAsset } from "@tanvir-platform/types";
import { Button, Input, Label } from "@tanvir-platform/ui";
import { Plus, X } from "lucide-react";
import * as React from "react";

import { MediaPickerModal } from "./MediaPickerModal";

export interface BeforeAfterPairDraft extends BeforeAfterPairInput {
  /** Present only client-side for rendering thumbnails before save —
   * the backend only ever receives the two media IDs + caption. */
  beforeAsset?: MediaAsset;
  afterAsset?: MediaAsset;
}

export interface BeforeAfterPairsFieldProps {
  value: BeforeAfterPairDraft[];
  onChange: (pairs: BeforeAfterPairDraft[]) => void;
}

/**
 * Before/After pairs field (Sprint 6's one genuinely new component —
 * nothing in Sprint 3's editor suite covers paired-image editing).
 * Reuses MediaPickerModal for both the "before" and "after" picks rather
 * than building a second media browser, per this sprint's reuse mandate.
 *
 * Supports multiple pairs per item (Phase 2.2 §4.3), matching the
 * `before_after_pairs` table this sprint built on the backend rather
 * than the flat single-pair fields the brief literally described.
 */
export function BeforeAfterPairsField({ value, onChange }: BeforeAfterPairsFieldProps) {
  const [pickerTarget, setPickerTarget] = React.useState<{ index: number; side: "before" | "after" } | null>(
    null
  );

  function addPair() {
    onChange([...value, { before_media_id: "", after_media_id: "" }]);
  }

  function removePair(index: number) {
    onChange(value.filter((_, i) => i !== index));
  }

  function updateCaption(index: number, caption: string) {
    onChange(value.map((pair, i) => (i === index ? { ...pair, caption } : pair)));
  }

  function handlePick(asset: MediaAsset) {
    if (!pickerTarget) return;
    const { index, side } = pickerTarget;
    onChange(
      value.map((pair, i) =>
        i === index
          ? side === "before"
            ? { ...pair, before_media_id: asset.id, beforeAsset: asset }
            : { ...pair, after_media_id: asset.id, afterAsset: asset }
          : pair
      )
    );
    setPickerTarget(null);
  }

  return (
    <div>
      <Label>Before / After comparisons</Label>

      <div className="flex flex-col gap-4">
        {value.map((pair, index) => (
          <div key={index} className="rounded-md border border-neutral-200 p-3 dark:border-surface-dark-border">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-caption text-neutral-400">Pair {index + 1}</span>
              <button
                type="button"
                onClick={() => removePair(index)}
                aria-label={`Remove pair ${index + 1}`}
                className="text-neutral-400 hover:text-error-500"
              >
                <X size={14} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <ImageSlot
                label="Before"
                asset={pair.beforeAsset}
                onClick={() => setPickerTarget({ index, side: "before" })}
              />
              <ImageSlot
                label="After"
                asset={pair.afterAsset}
                onClick={() => setPickerTarget({ index, side: "after" })}
              />
            </div>

            <Input
              className="mt-2"
              placeholder="Caption (optional)"
              value={pair.caption ?? ""}
              onChange={(e) => updateCaption(index, e.target.value)}
            />
          </div>
        ))}
      </div>

      <Button variant="secondary" size="sm" className="mt-3" onClick={addPair}>
        <Plus size={14} />
        Add comparison
      </Button>

      <MediaPickerModal open={!!pickerTarget} onClose={() => setPickerTarget(null)} onSelect={handlePick} />
    </div>
  );
}

function ImageSlot({
  label,
  asset,
  onClick,
}: {
  label: string;
  asset: MediaAsset | undefined;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex aspect-video flex-col items-center justify-center gap-1 overflow-hidden rounded-sm border border-dashed border-neutral-300 text-neutral-400 hover:border-accent-500 hover:text-accent-500 dark:border-surface-dark-border"
    >
      {asset ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={asset.public_url} alt={asset.alt_text ?? ""} className="h-full w-full object-cover" />
      ) : (
        <span className="text-caption">{label}</span>
      )}
    </button>
  );
}
