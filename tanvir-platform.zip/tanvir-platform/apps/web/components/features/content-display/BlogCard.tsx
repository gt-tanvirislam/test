import type { BlogPostListItem } from "@tanvir-platform/types";
import { Card } from "@tanvir-platform/ui";
import Link from "next/link";

export interface BlogCardProps {
  post: BlogPostListItem;
}

/**
 * Blog card (Sprint 9). Text-forward by design, not by omission — Blog's
 * public list schema doesn't expose a featured image yet (unlike
 * Portfolio's, fixed this sprint), and extending it was out of this
 * sprint's scope (flagged in the completion report). A category badge +
 * title + date is a legitimate premium pattern on its own (Stripe/Linear
 * blog cards use this shape), not a degraded placeholder.
 */
export function BlogCard({ post }: BlogCardProps) {
  return (
    <Link href={`/blog/${post.slug}`} className="group block">
      <Card className="h-full transition-shadow hover:shadow-md">
        {post.category && (
          <p className="text-caption uppercase tracking-wide text-accent-500">{post.category.name}</p>
        )}
        <p className="mt-2 text-card-title text-neutral-800 group-hover:text-accent-500 dark:text-text-dark-primary">
          {post.title}
        </p>
        {post.published_at && (
          <p className="mt-2 text-caption text-neutral-400">
            {new Date(post.published_at).toLocaleDateString(undefined, {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        )}
      </Card>
    </Link>
  );
}
