"use client";

import type { PublicServiceListItem } from "@/lib/api/public";
import { Card } from "@tanvir-platform/ui";
import * as LucideIcons from "lucide-react";
import { Sparkles } from "lucide-react";
import Link from "next/link";

export interface ServiceCardProps {
  service: PublicServiceListItem;
}

/**
 * Service card (Sprint 9). Icon-forward using `icon_key` (a Lucide icon
 * name, per Phase 2.5 §2's "official SVG icon set" rule — never an
 * emoji, never a free-text glyph). Falls back to a generic sparkle icon
 * if `icon_key` is unset or doesn't match a real Lucide export, so a
 * typo'd icon name degrades gracefully instead of crashing the card.
 */
export function ServiceCard({ service }: ServiceCardProps) {
  const IconComponent =
    (service.icon_key && (LucideIcons as unknown as Record<string, React.ComponentType<{ size?: number }>>)[service.icon_key]) ||
    Sparkles;

  return (
    <Link href={`/services/${service.slug}`} className="group block">
      <Card className="h-full transition-shadow hover:shadow-md">
        <div className="flex h-11 w-11 items-center justify-center rounded-md bg-accent-50 text-accent-600 dark:bg-surface-dark-2 dark:text-accent-400">
          <IconComponent size={22} />
        </div>
        <p className="mt-4 text-card-title text-neutral-800 group-hover:text-accent-500 dark:text-text-dark-primary">
          {service.title}
        </p>
        {service.short_description && (
          <p className="mt-2 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
            {service.short_description}
          </p>
        )}
      </Card>
    </Link>
  );
}
