import type { PortfolioItemListItem } from "@tanvir-platform/types";
import { Card } from "@tanvir-platform/ui";
import { ImageIcon } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export interface PortfolioCardProps {
  item: PortfolioItemListItem;
}

/**
 * Portfolio showcase card (Sprint 9). Image-forward per Phase 1.3
 * ("portfolio images should remain the visual focus") — uses the real
 * `featured_image_url` resolved by this sprint's backend fix, with a
 * graceful icon placeholder when an item has no featured image yet
 * (never a broken image tag).
 */
export function PortfolioCard({ item }: PortfolioCardProps) {
  return (
    <Link href={`/portfolio/${item.slug}`} className="group block">
      <Card className="overflow-hidden p-0 transition-shadow hover:shadow-md">
        <div className="relative aspect-[4/3] w-full overflow-hidden bg-neutral-100 dark:bg-surface-dark-2">
          {item.featured_image_url ? (
            <Image
              src={item.featured_image_url}
              alt={item.title}
              fill
              sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
              className="object-cover transition-transform duration-slow group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-neutral-300 dark:text-surface-dark-border">
              <ImageIcon size={32} aria-hidden />
            </div>
          )}
        </div>
        <div className="p-4">
          {item.category && (
            <p className="text-caption uppercase tracking-wide text-accent-500">{item.category.name}</p>
          )}
          <p className="mt-1 text-card-title text-neutral-800 dark:text-text-dark-primary">{item.title}</p>
        </div>
      </Card>
    </Link>
  );
}
