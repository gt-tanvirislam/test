/**
 * Runs synchronously before paint (injected via <script> in app/layout.tsx)
 * so the correct theme is set on <html> before React hydrates — prevents a
 * flash of the wrong theme on load. Kept tiny and dependency-free since it
 * runs outside the React tree entirely.
 */
export const themeInitScript = `
(function () {
  try {
    var stored = window.localStorage.getItem('tanvir-platform-theme');
    var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    var theme = stored || (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
  } catch (e) {
    document.documentElement.setAttribute('data-theme', 'light');
  }
})();
`;
