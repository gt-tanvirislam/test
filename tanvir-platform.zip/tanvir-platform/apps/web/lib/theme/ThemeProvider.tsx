"use client";

import * as React from "react";

type Theme = "light" | "dark";

interface ThemeContextValue {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
}

const ThemeContext = React.createContext<ThemeContextValue | undefined>(undefined);

const STORAGE_KEY = "tanvir-platform-theme";

/**
 * Theme provider — Phase 2.7 §7.
 *
 * Default: light (Phase 1.3's explicit mandate). Respects system preference
 * on first visit if no stored override exists, then persists the user's
 * explicit choice. Flips a single `data-theme` attribute on <html>, which
 * every CSS custom property in globals.css keys off of — no theme value is
 * ever threaded through the component tree as a prop.
 */
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  // Initial value is read from the DOM attribute set synchronously by the
  // blocking inline script in app/layout.tsx (ThemeInitScript) — this
  // avoids a flash-of-wrong-theme without needing to delay rendering here.
  const [theme, setThemeState] = React.useState<Theme>("light");

  React.useEffect(() => {
    const current = document.documentElement.getAttribute("data-theme") as Theme | null;
    if (current) setThemeState(current);
  }, []);

  const setTheme = React.useCallback((next: Theme) => {
    setThemeState(next);
    document.documentElement.setAttribute("data-theme", next);
    window.localStorage.setItem(STORAGE_KEY, next);
  }, []);

  const toggleTheme = React.useCallback(() => {
    setTheme(theme === "light" ? "dark" : "light");
  }, [theme, setTheme]);

  const value = React.useMemo(
    () => ({ theme, setTheme, toggleTheme }),
    [theme, setTheme, toggleTheme]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const ctx = React.useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within a ThemeProvider");
  return ctx;
}
