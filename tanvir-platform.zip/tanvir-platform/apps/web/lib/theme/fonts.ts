import { Inter, Fraunces } from "next/font/google";

/**
 * Font loading (Phase 2.7 §9 — self-hosted, subset automatically by
 * next/font, zero layout shift via size-adjust). Body/UI face is a highly
 * legible variable sans-serif (Phase 2.5 §1.4); the display face is
 * reserved for the hero headline only, never for UI chrome.
 *
 * Specific families are a starting recommendation consistent with Phase
 * 2.5 §1.4's brief ("highly legible variable sans... one optional display
 * serif") — swappable in this one file if Tamvir prefers a different pair
 * once real brand/logo direction is finalized.
 */
export const bodyFont = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

export const displayFont = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
  weight: ["500", "600"],
});
