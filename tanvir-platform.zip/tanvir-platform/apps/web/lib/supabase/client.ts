import { createBrowserClient } from "@supabase/ssr";

/**
 * Browser-side Supabase client. Used for auth (sign in/out, session
 * listening) directly from Client Components. Never used to query business
 * tables directly from the frontend — all content data flows through the
 * FastAPI backend (Phase 2.8), keeping authorization logic centralized
 * server-side rather than duplicated in RLS-only enforcement.
 */
export function createSupabaseBrowserClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
