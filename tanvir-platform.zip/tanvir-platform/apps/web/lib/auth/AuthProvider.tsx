"use client";

import type { Session } from "@supabase/supabase-js";
import * as React from "react";

import { createSupabaseBrowserClient } from "../supabase/client";

interface AuthContextValue {
  session: Session | null;
  loading: boolean;
}

const AuthContext = React.createContext<AuthContextValue>({
  session: null,
  loading: true,
});

/**
 * Auth context foundation (Phase 2.7 §5's "Authentication state" decision:
 * Supabase session as source of truth, exposed via a thin Context wrapper).
 *
 * This sprint only wires up session presence/loading. Permission-checking
 * (`useCurrentUser()` resolving roles/permissions from the backend) and the
 * dashboard route guard's redirect behavior are implemented once the Users
 * & Auth backend module exists (Sprint 2, per Phase 2.8 §19).
 */
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = React.useState<Session | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const supabase = createSupabaseBrowserClient();

    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
    });

    return () => subscription.unsubscribe();
  }, []);

  const value = React.useMemo(() => ({ session, loading }), [session, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return React.useContext(AuthContext);
}
