import type {
  ApiSuccessResponse,
  CreateTestimonialInput,
  PublicTestimonial,
  Testimonial,
  UpdateTestimonialInput,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

/**
 * Testimonials API. The public list (`GET /testimonials`) is unauthenticated
 * and returns published rows only — it can be called from a Server Component
 * with no token. The `/manage` calls are gated by `testimonials.view` /
 * `testimonials.manage`.
 */

export async function getPublicTestimonials(
  options: { featured?: boolean } = {}
): Promise<PublicTestimonial[]> {
  const qs = options.featured ? "?featured=true" : "";
  const response = await apiFetch<ApiSuccessResponse<PublicTestimonial[]>>(
    `/testimonials${qs}`
  );
  return response.data;
}

export async function listTestimonials(accessToken: string): Promise<Testimonial[]> {
  const response = await apiFetch<ApiSuccessResponse<Testimonial[]>>("/testimonials/manage", {
    accessToken,
  });
  return response.data;
}

export async function getTestimonial(accessToken: string, id: string): Promise<Testimonial> {
  const response = await apiFetch<ApiSuccessResponse<Testimonial>>(
    `/testimonials/manage/${id}`,
    { accessToken }
  );
  return response.data;
}

export async function createTestimonial(
  accessToken: string,
  input: CreateTestimonialInput
): Promise<Testimonial> {
  const response = await apiFetch<ApiSuccessResponse<Testimonial>>("/testimonials/manage", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function updateTestimonial(
  accessToken: string,
  id: string,
  input: UpdateTestimonialInput
): Promise<Testimonial> {
  const response = await apiFetch<ApiSuccessResponse<Testimonial>>(
    `/testimonials/manage/${id}`,
    { method: "PATCH", body: JSON.stringify(input), accessToken }
  );
  return response.data;
}

export async function deleteTestimonial(accessToken: string, id: string): Promise<void> {
  await apiFetch<void>(`/testimonials/manage/${id}`, { method: "DELETE", accessToken });
}
