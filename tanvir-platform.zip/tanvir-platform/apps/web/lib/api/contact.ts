import type {
  ApiListResponse,
  ApiSuccessResponse,
  ContactInquiry,
  CreateInquiryInput,
  InquiryListItem,
  InquiryReceipt,
  InquiryStatus,
  UpdateInquiryStatusInput,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

/**
 * Contact / inquiry API.
 *
 * `submitInquiry` is public (the Contact form) — no token, hits
 * `POST /contact`. The management calls are gated server-side by
 * `inquiries.view` (reads) / `inquiries.manage` (mutations), so they take an
 * access token.
 */

export async function submitInquiry(input: CreateInquiryInput): Promise<InquiryReceipt> {
  const response = await apiFetch<ApiSuccessResponse<InquiryReceipt>>("/contact", {
    method: "POST",
    body: JSON.stringify(input),
  });
  return response.data;
}

export async function listInquiries(
  accessToken: string,
  params: { page?: number; per_page?: number; status?: InquiryStatus; search?: string } = {}
): Promise<ApiListResponse<InquiryListItem>> {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== "") search.set(key, String(value));
  });
  const qs = search.toString();
  return apiFetch<ApiListResponse<InquiryListItem>>(
    `/contact/inquiries${qs ? `?${qs}` : ""}`,
    { accessToken }
  );
}

export async function getInquiry(accessToken: string, id: string): Promise<ContactInquiry> {
  const response = await apiFetch<ApiSuccessResponse<ContactInquiry>>(
    `/contact/inquiries/${id}`,
    { accessToken }
  );
  return response.data;
}

export async function updateInquiryStatus(
  accessToken: string,
  id: string,
  input: UpdateInquiryStatusInput
): Promise<ContactInquiry> {
  const response = await apiFetch<ApiSuccessResponse<ContactInquiry>>(
    `/contact/inquiries/${id}/status`,
    { method: "PATCH", body: JSON.stringify(input), accessToken }
  );
  return response.data;
}

export async function deleteInquiry(accessToken: string, id: string): Promise<void> {
  await apiFetch<void>(`/contact/inquiries/${id}`, { method: "DELETE", accessToken });
}
