import type {
  ApiSuccessResponse,
  Navigation,
  ReplaceNavigationInput,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

/**
 * Navigation API (Phase 2.2 §4.7). `GET /navigation` is public — the header
 * and footer render on every public page — so `getNavigation()` needs no
 * token. `PUT /navigation` is gated by `navigation.manage` on the backend
 * and replaces the entire tree, so `replaceNavigation()` requires a token.
 */

export async function getNavigation(): Promise<Navigation> {
  const response = await apiFetch<ApiSuccessResponse<Navigation>>("/navigation");
  return response.data;
}

export async function replaceNavigation(
  accessToken: string,
  input: ReplaceNavigationInput
): Promise<Navigation> {
  const response = await apiFetch<ApiSuccessResponse<Navigation>>("/navigation", {
    method: "PUT",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}
