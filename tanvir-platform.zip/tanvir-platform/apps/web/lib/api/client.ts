import type { ApiErrorResponse } from "@tanvir-platform/types";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export class ApiError extends Error {
  code: string;
  fields?: Record<string, string>;
  status: number;

  constructor(status: number, body: ApiErrorResponse) {
    super(body.error.message);
    this.name = "ApiError";
    this.status = status;
    this.code = body.error.code;
    this.fields = body.error.fields;
  }
}

interface RequestOptions extends RequestInit {
  accessToken?: string;
}

/**
 * Base typed fetch wrapper (Phase 2.7 §1, Layer 6 — the API layer). Every
 * module-specific API function (created module-by-module in future
 * sprints, e.g. lib/api/blog.ts) calls through this rather than using
 * `fetch` directly, so the base URL, auth header, and error envelope
 * parsing live in exactly one place.
 */
export async function apiFetch<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { accessToken, headers, ...rest } = options;

  const response = await fetch(`${API_BASE_URL}/api/v1${path}`, {
    ...rest,
    headers: {
      "Content-Type": "application/json",
      ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      ...headers,
    },
  });

  if (!response.ok) {
    const body = (await response.json().catch(() => null)) as ApiErrorResponse | null;
    if (body?.error) throw new ApiError(response.status, body);
    throw new Error(`Request to ${path} failed with status ${response.status}`);
  }

  // 204 No Content has no body to parse.
  if (response.status === 204) return undefined as T;

  return response.json() as Promise<T>;
}
