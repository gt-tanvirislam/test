import type {
  ApiListResponse,
  ApiSuccessResponse,
  BlogPost,
  BlogPostListItem,
  PortfolioItem,
  PortfolioItemListItem,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

/**
 * Public content API (Sprint 7). Plain async functions, not React Query
 * hooks — public pages are Server Components (Phase 2.7 §6), which
 * fetch server-to-server and can't use client-only hooks. Reuses
 * `apiFetch` (Sprint 0) and the same `BlogPostListItem`/`PortfolioItem`
 * types the dashboard already uses (Sprint 4/6) — no duplicate types, no
 * duplicate fetch logic, no `accessToken` needed since these hit the
 * unauthenticated `/public/*` endpoints built in Sprint 4–6.
 */

export interface PublicSeoOverride {
  meta_title: string | null;
  meta_description: string | null;
  og_image_id: string | null;
  canonical_override: string | null;
  noindex: boolean;
}

export async function getLatestBlogPosts(limit = 3): Promise<BlogPostListItem[]> {
  const response = await apiFetch<ApiListResponse<BlogPostListItem>>(
    `/blog/public/posts?per_page=${limit}`
  );
  return response.data;
}

export async function getPublicBlogPosts(params: {
  page?: number;
  per_page?: number;
  category?: string;
  tag?: string;
  search?: string;
}): Promise<ApiListResponse<BlogPostListItem>> {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== "") search.set(key, String(value));
  });
  return apiFetch<ApiListResponse<BlogPostListItem>>(`/blog/public/posts?${search.toString()}`);
}

export async function getPublicBlogPostBySlug(
  slug: string
): Promise<(BlogPost & { seo: PublicSeoOverride | null }) | null> {
  try {
    const response = await apiFetch<ApiSuccessResponse<BlogPost & { seo: PublicSeoOverride | null }>>(
      `/blog/public/posts/${slug}`
    );
    return response.data;
  } catch {
    return null; // 404 — caller uses Next.js notFound()
  }
}

export async function getFeaturedPortfolioItems(limit = 6): Promise<PortfolioItemListItem[]> {
  const response = await apiFetch<ApiListResponse<PortfolioItemListItem>>(
    `/portfolio/public/items?per_page=${limit}&featured=true`
  );
  // Falls back to the most recent published items if nothing is marked
  // featured yet (Phase 2.6 §11's graceful-empty-content pattern) —
  // an empty "Featured Work" section on a fresh site is worse than
  // showing recent work instead.
  if (response.data.length > 0) return response.data;
  const fallback = await apiFetch<ApiListResponse<PortfolioItemListItem>>(
    `/portfolio/public/items?per_page=${limit}`
  );
  return fallback.data;
}

export async function getPublicPortfolioItems(params: {
  page?: number;
  per_page?: number;
  category?: string;
  tag?: string;
  search?: string;
}): Promise<ApiListResponse<PortfolioItemListItem>> {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== "") search.set(key, String(value));
  });
  return apiFetch<ApiListResponse<PortfolioItemListItem>>(`/portfolio/public/items?${search.toString()}`);
}

export async function getPublicPortfolioItemBySlug(
  slug: string
): Promise<(PortfolioItem & { seo: PublicSeoOverride | null }) | null> {
  try {
    const response = await apiFetch<ApiSuccessResponse<PortfolioItem & { seo: PublicSeoOverride | null }>>(
      `/portfolio/public/items/${slug}`
    );
    return response.data;
  } catch {
    return null;
  }
}

export interface PublicServiceListItem {
  id: string;
  title: string;
  slug: string;
  short_description: string | null;
  icon_key: string | null;
  category: { id: string; name: string; slug: string } | null;
}

export async function getPublicServices(params: {
  page?: number;
  per_page?: number;
  category?: string;
  tag?: string;
  search?: string;
} = {}): Promise<ApiListResponse<PublicServiceListItem>> {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== "") search.set(key, String(value));
  });
  return apiFetch<ApiListResponse<PublicServiceListItem>>(`/services/public/items?${search.toString()}`);
}

export async function getPublicServiceBySlug(slug: string) {
  try {
    const response = await apiFetch<ApiSuccessResponse<Record<string, unknown> & { seo: PublicSeoOverride | null }>>(
      `/services/public/items/${slug}`
    );
    return response.data;
  } catch {
    return null;
  }
}

/**
 * Featured Services (Sprint 7's "future-ready" stub, completed this
 * sprint now that the Services backend module — and this sprint's own
 * `sort_order`-based ordering — actually exist). Signature unchanged
 * from the stub, so nothing that called it needs to change.
 */
export async function getFeaturedServices(limit = 6): Promise<PublicServiceListItem[]> {
  const response = await getPublicServices({ per_page: limit });
  return response.data;
}
