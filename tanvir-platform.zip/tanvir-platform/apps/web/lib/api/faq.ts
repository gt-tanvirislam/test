import type {
  ApiSuccessResponse,
  CreateFAQItemInput,
  FAQItem,
  PublicFAQItem,
  UpdateFAQItemInput,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

/**
 * FAQ API. Public list (`GET /faq`) is unauthenticated and returns published
 * items only. The `/manage` calls are gated by `faq.view` / `faq.manage`.
 */

export async function getPublicFAQ(): Promise<PublicFAQItem[]> {
  const response = await apiFetch<ApiSuccessResponse<PublicFAQItem[]>>("/faq");
  return response.data;
}

export async function listFAQItems(accessToken: string): Promise<FAQItem[]> {
  const response = await apiFetch<ApiSuccessResponse<FAQItem[]>>("/faq/manage", {
    accessToken,
  });
  return response.data;
}

export async function getFAQItem(accessToken: string, id: string): Promise<FAQItem> {
  const response = await apiFetch<ApiSuccessResponse<FAQItem>>(`/faq/manage/${id}`, {
    accessToken,
  });
  return response.data;
}

export async function createFAQItem(
  accessToken: string,
  input: CreateFAQItemInput
): Promise<FAQItem> {
  const response = await apiFetch<ApiSuccessResponse<FAQItem>>("/faq/manage", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function updateFAQItem(
  accessToken: string,
  id: string,
  input: UpdateFAQItemInput
): Promise<FAQItem> {
  const response = await apiFetch<ApiSuccessResponse<FAQItem>>(`/faq/manage/${id}`, {
    method: "PATCH",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function deleteFAQItem(accessToken: string, id: string): Promise<void> {
  await apiFetch<void>(`/faq/manage/${id}`, { method: "DELETE", accessToken });
}
