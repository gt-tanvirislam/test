import type {
  ApiListResponse,
  ApiSuccessResponse,
  MediaAsset,
  MediaFolder,
  MediaUsage,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

interface RequestUploadUrlResponse {
  upload_url: string;
  storage_path: string;
  pending_asset_id: string;
}

export async function requestUploadUrl(
  accessToken: string,
  input: { file_name: string; mime_type: string; folder_id?: string }
): Promise<RequestUploadUrlResponse> {
  const response = await apiFetch<ApiSuccessResponse<RequestUploadUrlResponse>>("/media/upload-url", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function confirmUpload(
  accessToken: string,
  input: { pending_asset_id: string; file_size_bytes: number; alt_text?: string }
): Promise<MediaAsset> {
  const response = await apiFetch<ApiSuccessResponse<MediaAsset>>("/media/confirm", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function listMediaAssets(
  accessToken: string,
  params: { page?: number; per_page?: number; folder_id?: string } = {}
): Promise<ApiListResponse<MediaAsset>> {
  const search = new URLSearchParams();
  if (params.page) search.set("page", String(params.page));
  if (params.per_page) search.set("per_page", String(params.per_page));
  if (params.folder_id) search.set("folder_id", params.folder_id);

  return apiFetch<ApiListResponse<MediaAsset>>(`/media/assets?${search.toString()}`, { accessToken });
}

export async function getMediaAsset(accessToken: string, assetId: string): Promise<MediaAsset> {
  const response = await apiFetch<ApiSuccessResponse<MediaAsset>>(`/media/assets/${assetId}`, {
    accessToken,
  });
  return response.data;
}

export async function updateMediaAsset(
  accessToken: string,
  assetId: string,
  input: { alt_text?: string; folder_id?: string }
): Promise<MediaAsset> {
  const response = await apiFetch<ApiSuccessResponse<MediaAsset>>(`/media/assets/${assetId}`, {
    method: "PATCH",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function deleteMediaAsset(accessToken: string, assetId: string): Promise<void> {
  await apiFetch<void>(`/media/assets/${assetId}`, { method: "DELETE", accessToken });
}

export async function getMediaAssetUsage(
  accessToken: string,
  assetId: string
): Promise<MediaUsage[]> {
  const response = await apiFetch<ApiSuccessResponse<MediaUsage[]>>(`/media/assets/${assetId}/usage`, {
    accessToken,
  });
  return response.data;
}

export async function listMediaFolders(accessToken: string): Promise<MediaFolder[]> {
  const response = await apiFetch<ApiSuccessResponse<MediaFolder[]>>("/media/folders", { accessToken });
  return response.data;
}

/**
 * Uploads a File directly to the signed Storage URL (Phase 2.8 §8 — the
 * backend never proxies the file bytes). PUT with the raw file body and
 * its content type, matching Supabase Storage's signed-upload contract.
 */
export async function uploadFileToSignedUrl(uploadUrl: string, file: File): Promise<void> {
  const response = await fetch(uploadUrl, {
    method: "PUT",
    headers: { "Content-Type": file.type },
    body: file,
  });
  if (!response.ok) {
    throw new Error(`Upload failed with status ${response.status}`);
  }
}
