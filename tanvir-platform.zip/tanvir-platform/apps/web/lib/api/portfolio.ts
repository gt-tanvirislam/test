import type {
  ApiListResponse,
  ApiSuccessResponse,
  BeforeAfterPair,
  BeforeAfterPairInput,
  CreatePortfolioItemInput,
  MediaAsset,
  PortfolioCategory,
  PortfolioItem,
  PortfolioItemListFilters,
  PortfolioItemListItem,
  UpdatePortfolioItemInput,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

export async function listPortfolioItems(
  accessToken: string,
  filters: PortfolioItemListFilters = {}
): Promise<ApiListResponse<PortfolioItemListItem>> {
  const search = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== "") search.set(key, String(value));
  });
  return apiFetch<ApiListResponse<PortfolioItemListItem>>(`/portfolio/items?${search.toString()}`, {
    accessToken,
  });
}

export async function getPortfolioItem(accessToken: string, id: string): Promise<PortfolioItem> {
  const response = await apiFetch<ApiSuccessResponse<PortfolioItem>>(`/portfolio/items/${id}`, {
    accessToken,
  });
  return response.data;
}

export async function createPortfolioItem(
  accessToken: string,
  input: CreatePortfolioItemInput
): Promise<PortfolioItem> {
  const response = await apiFetch<ApiSuccessResponse<PortfolioItem>>("/portfolio/items", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function updatePortfolioItem(
  accessToken: string,
  id: string,
  input: UpdatePortfolioItemInput
): Promise<PortfolioItem> {
  const response = await apiFetch<ApiSuccessResponse<PortfolioItem>>(`/portfolio/items/${id}`, {
    method: "PATCH",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function deletePortfolioItem(accessToken: string, id: string): Promise<void> {
  await apiFetch<void>(`/portfolio/items/${id}`, { method: "DELETE", accessToken });
}

async function postAction(accessToken: string, id: string, action: string, body?: object): Promise<PortfolioItem> {
  const response = await apiFetch<ApiSuccessResponse<PortfolioItem>>(`/portfolio/items/${id}/${action}`, {
    method: "POST",
    body: body ? JSON.stringify(body) : undefined,
    accessToken,
  });
  return response.data;
}

export const publishPortfolioItem = (accessToken: string, id: string) => postAction(accessToken, id, "publish");
export const unpublishPortfolioItem = (accessToken: string, id: string) => postAction(accessToken, id, "unpublish");
export const archivePortfolioItem = (accessToken: string, id: string) => postAction(accessToken, id, "archive");
export const restorePortfolioItemFromArchive = (accessToken: string, id: string) =>
  postAction(accessToken, id, "restore-from-archive");
export const schedulePortfolioItem = (accessToken: string, id: string, scheduledAt: string) =>
  postAction(accessToken, id, "schedule", { scheduled_at: scheduledAt });

export async function checkPortfolioSlugAvailability(
  accessToken: string,
  slug: string,
  excludeId?: string
): Promise<boolean> {
  const params = new URLSearchParams({ slug });
  if (excludeId) params.set("exclude_id", excludeId);
  const response = await apiFetch<ApiSuccessResponse<{ available: boolean }>>(
    `/portfolio/items/check-slug?${params.toString()}`,
    { accessToken }
  );
  return response.data.available;
}

export async function setPortfolioGallery(
  accessToken: string,
  itemId: string,
  mediaAssetIds: string[]
): Promise<void> {
  await apiFetch(`/portfolio/items/${itemId}/gallery`, {
    method: "PUT",
    body: JSON.stringify({ media_asset_ids: mediaAssetIds }),
    accessToken,
  });
}

export async function getPortfolioGallery(accessToken: string, itemId: string): Promise<MediaAsset[]> {
  const response = await apiFetch<ApiSuccessResponse<MediaAsset[]>>(`/portfolio/items/${itemId}/gallery`, {
    accessToken,
  });
  return response.data;
}

export async function setPortfolioBeforeAfterPairs(
  accessToken: string,
  itemId: string,
  pairs: BeforeAfterPairInput[]
): Promise<BeforeAfterPair[]> {
  const response = await apiFetch<ApiSuccessResponse<BeforeAfterPair[]>>(
    `/portfolio/items/${itemId}/before-after`,
    { method: "PUT", body: JSON.stringify({ pairs }), accessToken }
  );
  return response.data;
}

export async function listPortfolioCategories(): Promise<PortfolioCategory[]> {
  const response = await apiFetch<ApiSuccessResponse<PortfolioCategory[]>>("/portfolio/categories");
  return response.data;
}

export async function createPortfolioCategory(
  accessToken: string,
  input: { name: string; description?: string }
): Promise<PortfolioCategory> {
  const response = await apiFetch<ApiSuccessResponse<PortfolioCategory>>("/portfolio/categories", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}
