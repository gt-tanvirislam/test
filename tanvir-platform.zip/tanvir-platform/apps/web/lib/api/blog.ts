import type {
  ApiListResponse,
  ApiSuccessResponse,
  BlogCategory,
  BlogPost,
  BlogPostListFilters,
  BlogPostListItem,
  CreateBlogPostInput,
  UpdateBlogPostInput,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

export async function listBlogPosts(
  accessToken: string,
  filters: BlogPostListFilters = {}
): Promise<ApiListResponse<BlogPostListItem>> {
  const search = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== "") search.set(key, String(value));
  });

  return apiFetch<ApiListResponse<BlogPostListItem>>(`/blog/posts?${search.toString()}`, {
    accessToken,
  });
}

export async function getBlogPost(accessToken: string, id: string): Promise<BlogPost> {
  const response = await apiFetch<ApiSuccessResponse<BlogPost>>(`/blog/posts/${id}`, { accessToken });
  return response.data;
}

export async function createBlogPost(
  accessToken: string,
  input: CreateBlogPostInput
): Promise<BlogPost> {
  const response = await apiFetch<ApiSuccessResponse<BlogPost>>("/blog/posts", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function updateBlogPost(
  accessToken: string,
  id: string,
  input: UpdateBlogPostInput
): Promise<BlogPost> {
  const response = await apiFetch<ApiSuccessResponse<BlogPost>>(`/blog/posts/${id}`, {
    method: "PATCH",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function deleteBlogPost(accessToken: string, id: string): Promise<void> {
  await apiFetch<void>(`/blog/posts/${id}`, { method: "DELETE", accessToken });
}

async function postAction(accessToken: string, id: string, action: string, body?: object): Promise<BlogPost> {
  const response = await apiFetch<ApiSuccessResponse<BlogPost>>(`/blog/posts/${id}/${action}`, {
    method: "POST",
    body: body ? JSON.stringify(body) : undefined,
    accessToken,
  });
  return response.data;
}

export const publishBlogPost = (accessToken: string, id: string) => postAction(accessToken, id, "publish");
export const unpublishBlogPost = (accessToken: string, id: string) => postAction(accessToken, id, "unpublish");
export const archiveBlogPost = (accessToken: string, id: string) => postAction(accessToken, id, "archive");
export const restoreBlogPostFromArchive = (accessToken: string, id: string) =>
  postAction(accessToken, id, "restore-from-archive");
export const scheduleBlogPost = (accessToken: string, id: string, scheduledAt: string) =>
  postAction(accessToken, id, "schedule", { scheduled_at: scheduledAt });

export async function checkBlogSlugAvailability(
  accessToken: string,
  slug: string,
  excludeId?: string
): Promise<boolean> {
  const params = new URLSearchParams({ slug });
  if (excludeId) params.set("exclude_id", excludeId);
  const response = await apiFetch<ApiSuccessResponse<{ available: boolean }>>(
    `/blog/posts/check-slug?${params.toString()}`,
    { accessToken }
  );
  return response.data.available;
}

export async function listBlogCategories(): Promise<BlogCategory[]> {
  const response = await apiFetch<ApiSuccessResponse<BlogCategory[]>>("/blog/categories");
  return response.data;
}

export async function createBlogCategory(
  accessToken: string,
  input: { name: string; description?: string }
): Promise<BlogCategory> {
  const response = await apiFetch<ApiSuccessResponse<BlogCategory>>("/blog/categories", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}
