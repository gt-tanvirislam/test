import type { ApiSuccessResponse } from "@tanvir-platform/types";

import { apiFetch } from "./client";

export interface UserSummary {
  id: string;
  email: string;
  full_name: string;
  status: string;
  roles: string[];
}

/** Backs the author filter/selector (Sprint 5 §2) — a lightweight list,
 * distinct from full user management (not built yet). */
export async function listUsers(accessToken: string, search?: string): Promise<UserSummary[]> {
  const params = search ? `?search=${encodeURIComponent(search)}` : "";
  const response = await apiFetch<ApiSuccessResponse<UserSummary[]>>(`/users${params}`, {
    accessToken,
  });
  return response.data;
}
