import type {
  ApiListResponse,
  ApiSuccessResponse,
  CreateServiceInput,
  MediaAsset,
  Service,
  ServiceCategory,
  ServiceListFilters,
  ServiceListItem,
  ServiceListItemInput,
  ServiceListItemSlim,
  UpdateServiceInput,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

export async function listServices(
  accessToken: string,
  filters: ServiceListFilters = {}
): Promise<ApiListResponse<ServiceListItemSlim>> {
  const search = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== "") search.set(key, String(value));
  });
  return apiFetch<ApiListResponse<ServiceListItemSlim>>(`/services/items?${search.toString()}`, {
    accessToken,
  });
}

export async function getService(accessToken: string, id: string): Promise<Service> {
  const response = await apiFetch<ApiSuccessResponse<Service>>(`/services/items/${id}`, { accessToken });
  return response.data;
}

export async function createService(accessToken: string, input: CreateServiceInput): Promise<Service> {
  const response = await apiFetch<ApiSuccessResponse<Service>>("/services/items", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function updateService(
  accessToken: string,
  id: string,
  input: UpdateServiceInput
): Promise<Service> {
  const response = await apiFetch<ApiSuccessResponse<Service>>(`/services/items/${id}`, {
    method: "PATCH",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}

export async function deleteService(accessToken: string, id: string): Promise<void> {
  await apiFetch<void>(`/services/items/${id}`, { method: "DELETE", accessToken });
}

async function postAction(accessToken: string, id: string, action: string, body?: object): Promise<Service> {
  const response = await apiFetch<ApiSuccessResponse<Service>>(`/services/items/${id}/${action}`, {
    method: "POST",
    body: body ? JSON.stringify(body) : undefined,
    accessToken,
  });
  return response.data;
}

export const publishService = (accessToken: string, id: string) => postAction(accessToken, id, "publish");
export const unpublishService = (accessToken: string, id: string) => postAction(accessToken, id, "unpublish");
export const archiveService = (accessToken: string, id: string) => postAction(accessToken, id, "archive");
export const restoreServiceFromArchive = (accessToken: string, id: string) =>
  postAction(accessToken, id, "restore-from-archive");
export const scheduleService = (accessToken: string, id: string, scheduledAt: string) =>
  postAction(accessToken, id, "schedule", { scheduled_at: scheduledAt });

export async function checkServiceSlugAvailability(
  accessToken: string,
  slug: string,
  excludeId?: string
): Promise<boolean> {
  const params = new URLSearchParams({ slug });
  if (excludeId) params.set("exclude_id", excludeId);
  const response = await apiFetch<ApiSuccessResponse<{ available: boolean }>>(
    `/services/items/check-slug?${params.toString()}`,
    { accessToken }
  );
  return response.data.available;
}

async function setListItems(
  accessToken: string,
  serviceId: string,
  kind: "features" | "benefits" | "process",
  items: ServiceListItemInput[]
): Promise<ServiceListItem[]> {
  const response = await apiFetch<ApiSuccessResponse<ServiceListItem[]>>(
    `/services/items/${serviceId}/${kind}`,
    { method: "PUT", body: JSON.stringify({ items }), accessToken }
  );
  return response.data;
}

export const setServiceFeatures = (accessToken: string, id: string, items: ServiceListItemInput[]) =>
  setListItems(accessToken, id, "features", items);
export const setServiceBenefits = (accessToken: string, id: string, items: ServiceListItemInput[]) =>
  setListItems(accessToken, id, "benefits", items);
export const setServiceProcessSteps = (accessToken: string, id: string, items: ServiceListItemInput[]) =>
  setListItems(accessToken, id, "process", items);

export async function setServiceGallery(
  accessToken: string,
  serviceId: string,
  mediaAssetIds: string[]
): Promise<void> {
  await apiFetch(`/services/items/${serviceId}/gallery`, {
    method: "PUT",
    body: JSON.stringify({ media_asset_ids: mediaAssetIds }),
    accessToken,
  });
}

export async function getServiceGallery(accessToken: string, serviceId: string): Promise<MediaAsset[]> {
  const response = await apiFetch<ApiSuccessResponse<MediaAsset[]>>(`/services/items/${serviceId}/gallery`, {
    accessToken,
  });
  return response.data;
}

export async function listServiceCategories(): Promise<ServiceCategory[]> {
  const response = await apiFetch<ApiSuccessResponse<ServiceCategory[]>>("/services/categories");
  return response.data;
}

export async function createServiceCategory(
  accessToken: string,
  input: { name: string; description?: string }
): Promise<ServiceCategory> {
  const response = await apiFetch<ApiSuccessResponse<ServiceCategory>>("/services/categories", {
    method: "POST",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}
