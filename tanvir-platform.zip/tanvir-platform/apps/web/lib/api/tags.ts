import type { ApiSuccessResponse, Tag } from "@tanvir-platform/types";

import { apiFetch } from "./client";

export async function listTags(): Promise<Tag[]> {
  const response = await apiFetch<ApiSuccessResponse<Tag[]>>("/tags");
  return response.data;
}

export async function createTag(accessToken: string, name: string): Promise<Tag> {
  const response = await apiFetch<ApiSuccessResponse<Tag>>("/tags", {
    method: "POST",
    body: JSON.stringify({ name }),
    accessToken,
  });
  return response.data;
}
