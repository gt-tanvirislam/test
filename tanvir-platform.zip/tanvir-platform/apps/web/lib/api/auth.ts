import type { ApiSuccessResponse, CurrentUser } from "@tanvir-platform/types";

import { apiFetch } from "./client";

/**
 * Module-specific API functions live in one file per module (Phase 2.7
 * §1 Layer 6) — this is the first one, establishing the pattern every
 * future module (lib/api/blog.ts, lib/api/portfolio.ts, ...) follows.
 * Unwraps the {data, meta} envelope (Phase 2.3 §1) so hook consumers work
 * with the plain entity shape.
 */
export async function fetchCurrentUser(accessToken: string): Promise<CurrentUser> {
  const response = await apiFetch<ApiSuccessResponse<CurrentUser>>("/auth/me", { accessToken });
  return response.data;
}
