import type {
  ApiSuccessResponse,
  SiteSettings,
  UpdateSiteSettingsInput,
} from "@tanvir-platform/types";

import { apiFetch } from "./client";

/**
 * Site settings API (Phase 2.2 §4.7). `GET /settings` is public — the
 * public footer/nav read it with no auth — so `getSiteSettings()` takes no
 * token. `PATCH /settings` is gated by `settings.manage` on the backend, so
 * `updateSiteSettings()` requires an access token.
 */

export async function getSiteSettings(): Promise<SiteSettings> {
  const response = await apiFetch<ApiSuccessResponse<SiteSettings>>("/settings");
  return response.data;
}

export async function updateSiteSettings(
  accessToken: string,
  input: UpdateSiteSettingsInput
): Promise<SiteSettings> {
  const response = await apiFetch<ApiSuccessResponse<SiteSettings>>("/settings", {
    method: "PATCH",
    body: JSON.stringify(input),
    accessToken,
  });
  return response.data;
}
