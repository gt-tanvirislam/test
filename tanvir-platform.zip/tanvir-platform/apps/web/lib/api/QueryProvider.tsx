"use client";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import * as React from "react";

/**
 * React Query provider — the server-state layer (Phase 2.7 §5). One
 * QueryClient instance per browser session, created lazily so it isn't
 * shared across requests on the server (Next.js SSR safety).
 */
export function QueryProvider({ children }: { children: React.ReactNode }) {
  const [client] = React.useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30_000,
            retry: 2, // exponential backoff handled by React Query's default
            refetchOnWindowFocus: true, // matters most for dashboard usage,
            // per Phase 2.7 §6 — public pages are largely Server Components
            // and don't rely on this.
          },
        },
      })
  );

  return <QueryClientProvider client={client}>{children}</QueryClientProvider>;
}
