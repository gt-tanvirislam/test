import type { Metadata } from "next";

const SITE_NAME = "Tamvir Islam";
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
const DEFAULT_DESCRIPTION =
  "Professional video editing, graphic design, motion graphics, and photo editing — built to an international standard.";

interface BuildMetadataInput {
  title: string;
  description?: string;
  path?: string;
  ogImage?: string;
  noindex?: boolean;
}

/**
 * Shared metadata builder (Phase 2.7 §10) — every route's
 * `generateMetadata()` calls through this rather than constructing the
 * Next.js Metadata object by hand, so title templating, OG/Twitter
 * defaults, and canonical logic stay consistent everywhere.
 *
 * Per-entity overrides (from the `seo_metadata` table, Phase 2.2 §4.7) are
 * passed in as `title`/`description`/`ogImage` once content modules exist
 * to fetch them from (future sprint) — this function itself has no
 * database dependency, keeping it usable from any route immediately.
 */
export function buildMetadata({
  title,
  description = DEFAULT_DESCRIPTION,
  path = "/",
  ogImage,
  noindex = false,
}: BuildMetadataInput): Metadata {
  const url = `${SITE_URL}${path}`;
  const resolvedOgImage = ogImage ?? `${SITE_URL}/og-default.png`;

  return {
    title: {
      absolute: title === SITE_NAME ? title : `${title} — ${SITE_NAME}`,
    },
    description,
    metadataBase: new URL(SITE_URL),
    alternates: {
      canonical: url,
      // hreflang scaffolding reserved for future multilingual content
      // (Phase 2.2 §8) — only `en` emitted until Bangla content exists.
      languages: { en: url },
    },
    robots: noindex ? { index: false, follow: false } : { index: true, follow: true },
    openGraph: {
      title,
      description,
      url,
      siteName: SITE_NAME,
      images: [{ url: resolvedOgImage, width: 1200, height: 630 }],
      locale: "en_US",
      type: "website",
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [resolvedOgImage],
    },
  };
}
