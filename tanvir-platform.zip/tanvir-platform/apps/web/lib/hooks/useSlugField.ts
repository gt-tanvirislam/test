"use client";

import { generateSlug } from "@tanvir-platform/utils";
import * as React from "react";

interface UseSlugFieldOptions {
  title: string;
  initialSlug?: string;
  /** Called (debounced by the caller if needed) to check whether a
   * candidate slug collides — the actual uniqueness check is a backend
   * concern (app/shared/slug.py); this hook only orchestrates when to
   * ask and how to reflect the result. */
  checkAvailability?: (slug: string) => Promise<boolean>;
}

/**
 * Slug field hook (this sprint's §3 requirement: auto-generation, manual
 * editing, duplicate prevention, URL preview).
 *
 * Behavior: the slug tracks the title automatically until the person
 * manually edits the slug field directly — at that point it "locks" and
 * stops following title changes, matching how every mainstream CMS
 * (WordPress, Ghost, Webflow) handles this exact interaction.
 */
export function useSlugField({ title, initialSlug = "", checkAvailability }: UseSlugFieldOptions) {
  const [slug, setSlug] = React.useState(initialSlug);
  const [isManuallyEdited, setIsManuallyEdited] = React.useState(!!initialSlug);
  const [availability, setAvailability] = React.useState<"idle" | "checking" | "available" | "taken">(
    "idle"
  );

  // Auto-follow the title until the user manually edits the slug.
  React.useEffect(() => {
    if (!isManuallyEdited) {
      setSlug(generateSlug(title));
    }
  }, [title, isManuallyEdited]);

  const handleManualChange = React.useCallback((value: string) => {
    setIsManuallyEdited(true);
    setSlug(generateSlug(value));
  }, []);

  const resetToAutoGenerate = React.useCallback(() => {
    setIsManuallyEdited(false);
    setSlug(generateSlug(title));
  }, [title]);

  // Debounced availability check — never fires on every keystroke.
  React.useEffect(() => {
    if (!slug || !checkAvailability) return;
    setAvailability("checking");
    const timeout = setTimeout(async () => {
      const isAvailable = await checkAvailability(slug);
      setAvailability(isAvailable ? "available" : "taken");
    }, 400);
    return () => clearTimeout(timeout);
  }, [slug, checkAvailability]);

  return {
    slug,
    isManuallyEdited,
    availability,
    onManualChange: handleManualChange,
    resetToAutoGenerate,
  };
}
