"use client";

import type { UpdateSiteSettingsInput } from "@tanvir-platform/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { getSiteSettings, updateSiteSettings } from "@/lib/api/settings";
import { useAuth } from "@/lib/auth/AuthProvider";

const SETTINGS_KEY = "site-settings";

/**
 * Site settings hooks (Phase 2.2 §4.7). The read is public so it needs no
 * session; the update requires one and is additionally gated server-side by
 * `settings.manage`. On a successful update we seed the cache with the
 * server's response and invalidate, so the form reflects exactly what was
 * persisted.
 */
export function useSiteSettings() {
  return useQuery({
    queryKey: [SETTINGS_KEY],
    queryFn: getSiteSettings,
    staleTime: 60_000,
  });
}

export function useUpdateSiteSettings() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: UpdateSiteSettingsInput) => updateSiteSettings(session!.access_token, input),
    onSuccess: (data) => {
      queryClient.setQueryData([SETTINGS_KEY], data);
      queryClient.invalidateQueries({ queryKey: [SETTINGS_KEY] });
    },
  });
}
