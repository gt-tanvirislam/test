"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { useAuth } from "@/lib/auth/AuthProvider";
import {
  confirmUpload,
  deleteMediaAsset,
  getMediaAsset,
  listMediaAssets,
  listMediaFolders,
  requestUploadUrl,
  updateMediaAsset,
  uploadFileToSignedUrl,
} from "@/lib/api/media";

const MEDIA_ASSETS_KEY = "media-assets";
const MEDIA_ASSET_KEY = "media-asset";
const MEDIA_FOLDERS_KEY = "media-folders";

export function useMediaAssets(folderId?: string) {
  const { session } = useAuth();

  return useQuery({
    queryKey: [MEDIA_ASSETS_KEY, folderId ?? "all"],
    queryFn: () => listMediaAssets(session!.access_token, { folder_id: folderId, per_page: 50 }),
    enabled: !!session?.access_token,
  });
}

/**
 * Fetches a single media asset by ID (Sprint 5 — fixes the Blog editor's
 * featured-image preview bug, which had only the asset ID on hand, not
 * the full record with `public_url`). Generic over any future module
 * that stores a bare media ID and needs to hydrate it for display —
 * Portfolio's featured image will use this exact hook.
 */
export function useMediaAsset(assetId: string | null | undefined) {
  const { session } = useAuth();

  return useQuery({
    queryKey: [MEDIA_ASSET_KEY, assetId],
    queryFn: () => getMediaAsset(session!.access_token, assetId!),
    enabled: !!session?.access_token && !!assetId,
  });
}

export function useMediaFolders() {
  const { session } = useAuth();

  return useQuery({
    queryKey: [MEDIA_FOLDERS_KEY],
    queryFn: () => listMediaFolders(session!.access_token),
    enabled: !!session?.access_token,
    staleTime: 5 * 60_000, // folders rarely change
  });
}

/**
 * Full upload flow as a single mutation (Phase 2.8 §8's pipeline,
 * client-side half): request signed URL → PUT the file → confirm.
 * Alt text is collected up front here rather than deferred, since this
 * sprint's UI asks for it at upload time for simplicity — Phase 2.4 §8
 * allows adding it later during editing too, which the separate
 * useUpdateMediaAsset hook below supports.
 */
export function useUploadMedia() {
  const { session } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      file,
      folderId,
      altText,
    }: {
      file: File;
      folderId?: string;
      altText?: string;
    }) => {
      const token = session!.access_token;
      const { upload_url, pending_asset_id } = await requestUploadUrl(token, {
        file_name: file.name,
        mime_type: file.type,
        folder_id: folderId,
      });
      await uploadFileToSignedUrl(upload_url, file);
      return confirmUpload(token, {
        pending_asset_id,
        file_size_bytes: file.size,
        alt_text: altText,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [MEDIA_ASSETS_KEY] });
    },
  });
}

export function useUpdateMediaAsset() {
  const { session } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ assetId, altText }: { assetId: string; altText: string }) =>
      updateMediaAsset(session!.access_token, assetId, { alt_text: altText }),
    onSuccess: (updated) => {
      queryClient.invalidateQueries({ queryKey: [MEDIA_ASSETS_KEY] });
      queryClient.invalidateQueries({ queryKey: [MEDIA_ASSET_KEY, updated.id] });
    },
  });
}
export function useDeleteMediaAsset() {
  const { session } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (assetId: string) => deleteMediaAsset(session!.access_token, assetId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [MEDIA_ASSETS_KEY] }),
  });
}
