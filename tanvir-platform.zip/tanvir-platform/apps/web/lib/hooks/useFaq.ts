"use client";

import type { CreateFAQItemInput, UpdateFAQItemInput } from "@tanvir-platform/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import {
  createFAQItem,
  deleteFAQItem,
  getFAQItem,
  listFAQItems,
  updateFAQItem,
} from "@/lib/api/faq";
import { useAuth } from "@/lib/auth/AuthProvider";

const LIST_KEY = "faq";
const ITEM_KEY = "faq-item";

export function useFAQItems() {
  const { session } = useAuth();
  return useQuery({
    queryKey: [LIST_KEY],
    queryFn: () => listFAQItems(session!.access_token),
    enabled: !!session?.access_token,
  });
}

export function useFAQItem(id: string | undefined) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [ITEM_KEY, id],
    queryFn: () => getFAQItem(session!.access_token, id!),
    enabled: !!session?.access_token && !!id,
  });
}

function useInvalidateFAQ() {
  const queryClient = useQueryClient();
  return (id?: string) => {
    queryClient.invalidateQueries({ queryKey: [LIST_KEY] });
    if (id) queryClient.invalidateQueries({ queryKey: [ITEM_KEY, id] });
  };
}

export function useCreateFAQItem() {
  const { session } = useAuth();
  const invalidate = useInvalidateFAQ();
  return useMutation({
    mutationFn: (input: CreateFAQItemInput) => createFAQItem(session!.access_token, input),
    onSuccess: () => invalidate(),
  });
}

export function useUpdateFAQItem() {
  const { session } = useAuth();
  const invalidate = useInvalidateFAQ();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: UpdateFAQItemInput }) =>
      updateFAQItem(session!.access_token, id, input),
    onSuccess: (data) => invalidate(data.id),
  });
}

export function useDeleteFAQItem() {
  const { session } = useAuth();
  const invalidate = useInvalidateFAQ();
  return useMutation({
    mutationFn: (id: string) => deleteFAQItem(session!.access_token, id),
    onSuccess: () => invalidate(),
  });
}
