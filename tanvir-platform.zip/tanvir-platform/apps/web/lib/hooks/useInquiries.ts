"use client";

import type {
  InquiryStatus,
  UpdateInquiryStatusInput,
} from "@tanvir-platform/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import {
  deleteInquiry,
  getInquiry,
  listInquiries,
  updateInquiryStatus,
} from "@/lib/api/contact";
import { useAuth } from "@/lib/auth/AuthProvider";

const LIST_KEY = "inquiries";
const ITEM_KEY = "inquiry";

/**
 * Contact-inquiry dashboard hooks. The public submit is NOT here — the
 * Contact form calls `submitInquiry` directly (no session, no cache), since
 * a one-shot anonymous POST has nothing to cache or invalidate.
 */

export function useInquiries(params: { status?: InquiryStatus; search?: string; page?: number } = {}) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [LIST_KEY, params],
    queryFn: () => listInquiries(session!.access_token, params),
    enabled: !!session?.access_token,
  });
}

export function useInquiry(id: string | undefined) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [ITEM_KEY, id],
    queryFn: () => getInquiry(session!.access_token, id!),
    enabled: !!session?.access_token && !!id,
  });
}

export function useUpdateInquiryStatus() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: UpdateInquiryStatusInput }) =>
      updateInquiryStatus(session!.access_token, id, input),
    onSuccess: (data) => {
      queryClient.setQueryData([ITEM_KEY, data.id], data);
      queryClient.invalidateQueries({ queryKey: [LIST_KEY] });
    },
  });
}

export function useDeleteInquiry() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => deleteInquiry(session!.access_token, id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [LIST_KEY] });
    },
  });
}
