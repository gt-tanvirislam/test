"use client";

import type { ReplaceNavigationInput } from "@tanvir-platform/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { getNavigation, replaceNavigation } from "@/lib/api/navigation";
import { useAuth } from "@/lib/auth/AuthProvider";

const NAVIGATION_KEY = "navigation";

/**
 * Navigation hooks (Phase 2.2 §4.7). The read is public so it needs no
 * session; the replace requires one and is additionally gated server-side by
 * `navigation.manage`. On success we seed the cache with the server's
 * resolved tree and invalidate, so the editor reflects exactly what was
 * persisted.
 */
export function useNavigation() {
  return useQuery({
    queryKey: [NAVIGATION_KEY],
    queryFn: getNavigation,
    staleTime: 60_000,
  });
}

export function useReplaceNavigation() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: ReplaceNavigationInput) => replaceNavigation(session!.access_token, input),
    onSuccess: (data) => {
      queryClient.setQueryData([NAVIGATION_KEY], data);
      queryClient.invalidateQueries({ queryKey: [NAVIGATION_KEY] });
    },
  });
}
