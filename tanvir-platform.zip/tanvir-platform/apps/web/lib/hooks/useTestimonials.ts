"use client";

import type {
  CreateTestimonialInput,
  UpdateTestimonialInput,
} from "@tanvir-platform/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import {
  createTestimonial,
  deleteTestimonial,
  getTestimonial,
  listTestimonials,
  updateTestimonial,
} from "@/lib/api/testimonials";
import { useAuth } from "@/lib/auth/AuthProvider";

const LIST_KEY = "testimonials";
const ITEM_KEY = "testimonial";

export function useTestimonials() {
  const { session } = useAuth();
  return useQuery({
    queryKey: [LIST_KEY],
    queryFn: () => listTestimonials(session!.access_token),
    enabled: !!session?.access_token,
  });
}

export function useTestimonial(id: string | undefined) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [ITEM_KEY, id],
    queryFn: () => getTestimonial(session!.access_token, id!),
    enabled: !!session?.access_token && !!id,
  });
}

function useInvalidateTestimonials() {
  const queryClient = useQueryClient();
  return (id?: string) => {
    queryClient.invalidateQueries({ queryKey: [LIST_KEY] });
    if (id) queryClient.invalidateQueries({ queryKey: [ITEM_KEY, id] });
  };
}

export function useCreateTestimonial() {
  const { session } = useAuth();
  const invalidate = useInvalidateTestimonials();
  return useMutation({
    mutationFn: (input: CreateTestimonialInput) =>
      createTestimonial(session!.access_token, input),
    onSuccess: () => invalidate(),
  });
}

export function useUpdateTestimonial() {
  const { session } = useAuth();
  const invalidate = useInvalidateTestimonials();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: UpdateTestimonialInput }) =>
      updateTestimonial(session!.access_token, id, input),
    onSuccess: (data) => invalidate(data.id),
  });
}

export function useDeleteTestimonial() {
  const { session } = useAuth();
  const invalidate = useInvalidateTestimonials();
  return useMutation({
    mutationFn: (id: string) => deleteTestimonial(session!.access_token, id),
    onSuccess: () => invalidate(),
  });
}
