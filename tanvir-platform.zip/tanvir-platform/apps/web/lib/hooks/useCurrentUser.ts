"use client";

import { useQuery } from "@tanstack/react-query";

import { useAuth } from "@/lib/auth/AuthProvider";
import { fetchCurrentUser } from "@/lib/api/auth";
import { filterNavByPermissions } from "@/lib/constants/nav";

/**
 * Resolves the full CurrentUser (roles + permissions) once a Supabase
 * session exists. This is the piece Sprint 0's AuthProvider deliberately
 * deferred (session-presence only) — now that the backend's /auth/me
 * exists, the dashboard can check real permissions, not just "is logged
 * in at all."
 */
export function useCurrentUser() {
  const { session, loading: sessionLoading } = useAuth();

  const query = useQuery({
    queryKey: ["current-user", session?.access_token],
    queryFn: () => fetchCurrentUser(session!.access_token),
    enabled: !!session?.access_token,
    staleTime: 60_000,
  });

  return {
    user: query.data,
    isLoading: sessionLoading || (!!session && query.isLoading),
    isError: query.isError,
    error: query.error,
  };
}

/** Convenience helper for permission-gated UI (Phase 2.3 §2's matrix). */
export function useHasPermission(permissionKey: string): boolean {
  const { user } = useCurrentUser();
  return !!user?.permissions.includes(permissionKey);
}

/**
 * Filters a list of nav items down to those the current user may see.
 * Items with `permission: null` are always kept; the rest require the
 * matching permission key. While the user is still loading we return an
 * empty list rather than flashing links the user may not have — the
 * sidebar renders skeleton rows during that window instead.
 *
 * This is presentation only: hiding a link is a UX nicety, not a security
 * boundary. Every backend endpoint independently enforces its own
 * `require_permission`, so a hidden or hand-typed route is still rejected
 * server-side.
 */
export function useVisibleNavItems<T extends { permission: string | null }>(
  items: readonly T[]
): { items: T[]; isLoading: boolean } {
  const { user, isLoading } = useCurrentUser();

  if (isLoading || !user) {
    return { items: [], isLoading };
  }

  return {
    items: filterNavByPermissions(items, user.permissions),
    isLoading: false,
  };
}
