"use client";

import type {
  CreateServiceInput,
  ServiceListFilters,
  ServiceListItemInput,
  UpdateServiceInput,
} from "@tanvir-platform/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as React from "react";

import { useAuth } from "@/lib/auth/AuthProvider";
import {
  archiveService,
  checkServiceSlugAvailability,
  createService,
  createServiceCategory,
  deleteService,
  getService,
  getServiceGallery,
  listServiceCategories,
  listServices,
  publishService,
  restoreServiceFromArchive,
  scheduleService,
  setServiceBenefits,
  setServiceFeatures,
  setServiceGallery,
  setServiceProcessSteps,
  unpublishService,
  updateService,
} from "@/lib/api/services";

const ITEMS_KEY = "services";
const ITEM_KEY = "service";
const CATEGORIES_KEY = "service-categories";

export function useServices(filters: ServiceListFilters) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [ITEMS_KEY, filters],
    queryFn: () => listServices(session!.access_token, filters),
    enabled: !!session?.access_token,
  });
}

export function useService(id: string | undefined) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [ITEM_KEY, id],
    queryFn: () => getService(session!.access_token, id!),
    enabled: !!session?.access_token && !!id,
  });
}

function useInvalidateServices() {
  const queryClient = useQueryClient();
  return (id?: string) => {
    queryClient.invalidateQueries({ queryKey: [ITEMS_KEY] });
    if (id) queryClient.invalidateQueries({ queryKey: [ITEM_KEY, id] });
  };
}

export function useCreateService() {
  const { session } = useAuth();
  const invalidate = useInvalidateServices();
  return useMutation({
    mutationFn: (input: CreateServiceInput) => createService(session!.access_token, input),
    onSuccess: () => invalidate(),
  });
}

export function useUpdateService(id: string) {
  const { session } = useAuth();
  const invalidate = useInvalidateServices();
  return useMutation({
    mutationFn: (input: UpdateServiceInput) => updateService(session!.access_token, id, input),
    onSuccess: () => invalidate(id),
  });
}

/** Optimistic delete — same pattern as useDeleteBlogPost/useDeletePortfolioItem. */
export function useDeleteService() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  const invalidate = useInvalidateServices();
  return useMutation({
    mutationFn: (id: string) => deleteService(session!.access_token, id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: [ITEMS_KEY] });
      const previous = queryClient.getQueriesData({ queryKey: [ITEMS_KEY] });
      queryClient.setQueriesData({ queryKey: [ITEMS_KEY] }, (old: any) => {
        if (!old?.data) return old;
        return { ...old, data: old.data.filter((i: { id: string }) => i.id !== id) };
      });
      return { previous };
    },
    onError: (_err, _id, context) => {
      context?.previous?.forEach(([key, value]: [readonly unknown[], unknown]) => {
        queryClient.setQueryData(key, value);
      });
    },
    onSettled: () => invalidate(),
  });
}

/** Optimistic lifecycle transitions — same pattern as
 * useBlogPostLifecycle/usePortfolioItemLifecycle. */
export function useServiceLifecycle(id: string) {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  const invalidate = useInvalidateServices();
  const token = () => session!.access_token;

  function optimisticStatus(nextStatus: string) {
    return {
      onMutate: async () => {
        await queryClient.cancelQueries({ queryKey: [ITEM_KEY, id] });
        const previous = queryClient.getQueryData([ITEM_KEY, id]);
        queryClient.setQueryData([ITEM_KEY, id], (old: any) => (old ? { ...old, status: nextStatus } : old));
        return { previous };
      },
      onError: (_err: unknown, _vars: unknown, context: { previous?: unknown }) => {
        if (context?.previous) queryClient.setQueryData([ITEM_KEY, id], context.previous);
      },
      onSettled: () => invalidate(id),
    };
  }

  const publish = useMutation({ mutationFn: () => publishService(token(), id), ...optimisticStatus("published") });
  const unpublish = useMutation({ mutationFn: () => unpublishService(token(), id), ...optimisticStatus("draft") });
  const archive = useMutation({ mutationFn: () => archiveService(token(), id), ...optimisticStatus("archived") });
  const restore = useMutation({ mutationFn: () => restoreServiceFromArchive(token(), id), ...optimisticStatus("draft") });
  const schedule = useMutation({
    mutationFn: (scheduledAt: string) => scheduleService(token(), id, scheduledAt),
    onSuccess: () => invalidate(id),
  });

  return { publish, unpublish, archive, restore, schedule };
}

function useSetListItems(id: string, mutationFn: (token: string, id: string, items: ServiceListItemInput[]) => Promise<unknown>) {
  const { session } = useAuth();
  const invalidate = useInvalidateServices();
  return useMutation({
    mutationFn: (items: ServiceListItemInput[]) => mutationFn(session!.access_token, id, items),
    onSuccess: () => invalidate(id),
  });
}

export const useSetServiceFeatures = (id: string) => useSetListItems(id, setServiceFeatures);
export const useSetServiceBenefits = (id: string) => useSetListItems(id, setServiceBenefits);
export const useSetServiceProcessSteps = (id: string) => useSetListItems(id, setServiceProcessSteps);

export function useSetServiceGallery(id: string) {
  const { session } = useAuth();
  const invalidate = useInvalidateServices();
  return useMutation({
    mutationFn: (mediaAssetIds: string[]) => setServiceGallery(session!.access_token, id, mediaAssetIds),
    onSuccess: () => invalidate(id),
  });
}

export function useServiceGallery(id: string | undefined) {
  const { session } = useAuth();
  return useQuery({
    queryKey: ["service-gallery", id],
    queryFn: () => getServiceGallery(session!.access_token, id!),
    enabled: !!session?.access_token && !!id,
  });
}

export function useServiceCategories() {
  return useQuery({ queryKey: [CATEGORIES_KEY], queryFn: listServiceCategories, staleTime: 5 * 60_000 });
}

export function useCreateServiceCategory() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: { name: string; description?: string }) =>
      createServiceCategory(session!.access_token, input),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [CATEGORIES_KEY] }),
  });
}

export function useCheckServiceSlugAvailability(excludeId?: string) {
  const { session } = useAuth();
  return React.useCallback(
    (slug: string) => checkServiceSlugAvailability(session!.access_token, slug, excludeId),
    [session, excludeId]
  );
}
