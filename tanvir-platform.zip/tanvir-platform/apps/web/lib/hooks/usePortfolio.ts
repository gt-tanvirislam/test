"use client";

import type {
  BeforeAfterPairInput,
  CreatePortfolioItemInput,
  PortfolioItemListFilters,
  UpdatePortfolioItemInput,
} from "@tanvir-platform/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as React from "react";

import { useAuth } from "@/lib/auth/AuthProvider";
import {
  archivePortfolioItem,
  checkPortfolioSlugAvailability,
  createPortfolioCategory,
  createPortfolioItem,
  deletePortfolioItem,
  getPortfolioGallery,
  getPortfolioItem,
  listPortfolioCategories,
  listPortfolioItems,
  publishPortfolioItem,
  restorePortfolioItemFromArchive,
  schedulePortfolioItem,
  setPortfolioBeforeAfterPairs,
  setPortfolioGallery,
  unpublishPortfolioItem,
  updatePortfolioItem,
} from "@/lib/api/portfolio";

const ITEMS_KEY = "portfolio-items";
const ITEM_KEY = "portfolio-item";
const CATEGORIES_KEY = "portfolio-categories";

export function usePortfolioItems(filters: PortfolioItemListFilters) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [ITEMS_KEY, filters],
    queryFn: () => listPortfolioItems(session!.access_token, filters),
    enabled: !!session?.access_token,
  });
}

export function usePortfolioItem(id: string | undefined) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [ITEM_KEY, id],
    queryFn: () => getPortfolioItem(session!.access_token, id!),
    enabled: !!session?.access_token && !!id,
  });
}

function useInvalidateItems() {
  const queryClient = useQueryClient();
  return (id?: string) => {
    queryClient.invalidateQueries({ queryKey: [ITEMS_KEY] });
    if (id) queryClient.invalidateQueries({ queryKey: [ITEM_KEY, id] });
  };
}

export function useCreatePortfolioItem() {
  const { session } = useAuth();
  const invalidate = useInvalidateItems();
  return useMutation({
    mutationFn: (input: CreatePortfolioItemInput) => createPortfolioItem(session!.access_token, input),
    onSuccess: () => invalidate(),
  });
}

export function useUpdatePortfolioItem(id: string) {
  const { session } = useAuth();
  const invalidate = useInvalidateItems();
  return useMutation({
    mutationFn: (input: UpdatePortfolioItemInput) => updatePortfolioItem(session!.access_token, id, input),
    onSuccess: () => invalidate(id),
  });
}

/** Optimistic delete (Sprint 5's pattern, reused verbatim). */
export function useDeletePortfolioItem() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  const invalidate = useInvalidateItems();
  return useMutation({
    mutationFn: (id: string) => deletePortfolioItem(session!.access_token, id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: [ITEMS_KEY] });
      const previous = queryClient.getQueriesData({ queryKey: [ITEMS_KEY] });
      queryClient.setQueriesData({ queryKey: [ITEMS_KEY] }, (old: any) => {
        if (!old?.data) return old;
        return { ...old, data: old.data.filter((i: { id: string }) => i.id !== id) };
      });
      return { previous };
    },
    onError: (_err, _id, context) => {
      context?.previous?.forEach(([key, value]: [readonly unknown[], unknown]) => {
        queryClient.setQueryData(key, value);
      });
    },
    onSettled: () => invalidate(),
  });
}

/** Optimistic lifecycle transitions (Sprint 5's pattern, reused
 * verbatim — same shape as useBlogPostLifecycle). */
export function usePortfolioItemLifecycle(id: string) {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  const invalidate = useInvalidateItems();
  const token = () => session!.access_token;

  function optimisticStatus(nextStatus: string) {
    return {
      onMutate: async () => {
        await queryClient.cancelQueries({ queryKey: [ITEM_KEY, id] });
        const previous = queryClient.getQueryData([ITEM_KEY, id]);
        queryClient.setQueryData([ITEM_KEY, id], (old: any) => (old ? { ...old, status: nextStatus } : old));
        return { previous };
      },
      onError: (_err: unknown, _vars: unknown, context: { previous?: unknown }) => {
        if (context?.previous) queryClient.setQueryData([ITEM_KEY, id], context.previous);
      },
      onSettled: () => invalidate(id),
    };
  }

  const publish = useMutation({ mutationFn: () => publishPortfolioItem(token(), id), ...optimisticStatus("published") });
  const unpublish = useMutation({ mutationFn: () => unpublishPortfolioItem(token(), id), ...optimisticStatus("draft") });
  const archive = useMutation({ mutationFn: () => archivePortfolioItem(token(), id), ...optimisticStatus("archived") });
  const restore = useMutation({ mutationFn: () => restorePortfolioItemFromArchive(token(), id), ...optimisticStatus("draft") });
  const schedule = useMutation({
    mutationFn: (scheduledAt: string) => schedulePortfolioItem(token(), id, scheduledAt),
    onSuccess: () => invalidate(id),
  });

  return { publish, unpublish, archive, restore, schedule };
}

export function useSetPortfolioGallery(id: string) {
  const { session } = useAuth();
  const invalidate = useInvalidateItems();
  return useMutation({
    mutationFn: (mediaAssetIds: string[]) => setPortfolioGallery(session!.access_token, id, mediaAssetIds),
    onSuccess: () => invalidate(id),
  });
}

/** Hydrates the gallery on editor load (Sprint 6 — fixes the same
 * reload gap Sprint 5's useMediaAsset fixed for featured images). */
export function usePortfolioGallery(id: string | undefined) {
  const { session } = useAuth();
  return useQuery({
    queryKey: ["portfolio-gallery", id],
    queryFn: () => getPortfolioGallery(session!.access_token, id!),
    enabled: !!session?.access_token && !!id,
  });
}

export function useSetPortfolioBeforeAfterPairs(id: string) {
  const { session } = useAuth();
  const invalidate = useInvalidateItems();
  return useMutation({
    mutationFn: (pairs: BeforeAfterPairInput[]) =>
      setPortfolioBeforeAfterPairs(session!.access_token, id, pairs),
    onSuccess: () => invalidate(id),
  });
}

export function usePortfolioCategories() {
  return useQuery({ queryKey: [CATEGORIES_KEY], queryFn: listPortfolioCategories, staleTime: 5 * 60_000 });
}

export function useCreatePortfolioCategory() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: { name: string; description?: string }) =>
      createPortfolioCategory(session!.access_token, input),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [CATEGORIES_KEY] }),
  });
}

export function useCheckPortfolioSlugAvailability(excludeId?: string) {
  const { session } = useAuth();
  return React.useCallback(
    (slug: string) => checkPortfolioSlugAvailability(session!.access_token, slug, excludeId),
    [session, excludeId]
  );
}
