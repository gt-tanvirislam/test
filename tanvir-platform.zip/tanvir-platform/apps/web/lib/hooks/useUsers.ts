"use client";

import { useQuery } from "@tanstack/react-query";

import { useAuth } from "@/lib/auth/AuthProvider";
import { listUsers } from "@/lib/api/users";

/** List of active users for author filter/selector UI (Sprint 5 §2).
 * Client-side search filtering is applied by the consuming component for
 * small lists (see AuthorSelect) — `search` here still hits the real
 * backend query for correctness at any list size. */
export function useUsers(search?: string) {
  const { session } = useAuth();

  return useQuery({
    queryKey: ["users", search ?? ""],
    queryFn: () => listUsers(session!.access_token, search),
    enabled: !!session?.access_token,
    staleTime: 60_000,
  });
}
