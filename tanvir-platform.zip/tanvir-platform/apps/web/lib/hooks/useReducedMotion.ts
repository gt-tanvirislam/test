"use client";

import * as React from "react";

/**
 * The single global reduced-motion check (Phase 2.10 §9 — "no component
 * implements its own prefers-reduced-motion check independently"). Every
 * Framer Motion and GSAP-driven component consumes this rather than
 * querying the media feature itself.
 */
export function useReducedMotion(): boolean {
  const [reduced, setReduced] = React.useState(false);

  React.useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(query.matches);

    const listener = (event: MediaQueryListEvent) => setReduced(event.matches);
    query.addEventListener("change", listener);
    return () => query.removeEventListener("change", listener);
  }, []);

  return reduced;
}
