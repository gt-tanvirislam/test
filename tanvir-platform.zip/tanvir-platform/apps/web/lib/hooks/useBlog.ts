"use client";

import type { BlogPostListFilters, CreateBlogPostInput, UpdateBlogPostInput } from "@tanvir-platform/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as React from "react";

import { useAuth } from "@/lib/auth/AuthProvider";
import {
  archiveBlogPost,
  checkBlogSlugAvailability,
  createBlogCategory,
  createBlogPost,
  deleteBlogPost,
  getBlogPost,
  listBlogCategories,
  listBlogPosts,
  publishBlogPost,
  restoreBlogPostFromArchive,
  scheduleBlogPost,
  unpublishBlogPost,
  updateBlogPost,
} from "@/lib/api/blog";
import { createTag, listTags } from "@/lib/api/tags";

const POSTS_KEY = "blog-posts";
const POST_KEY = "blog-post";
const CATEGORIES_KEY = "blog-categories";
const TAGS_KEY = "tags";

export function useBlogPosts(filters: BlogPostListFilters) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [POSTS_KEY, filters],
    queryFn: () => listBlogPosts(session!.access_token, filters),
    enabled: !!session?.access_token,
  });
}

export function useBlogPost(id: string | undefined) {
  const { session } = useAuth();
  return useQuery({
    queryKey: [POST_KEY, id],
    queryFn: () => getBlogPost(session!.access_token, id!),
    enabled: !!session?.access_token && !!id,
  });
}

function useInvalidatePosts() {
  const queryClient = useQueryClient();
  return (id?: string) => {
    queryClient.invalidateQueries({ queryKey: [POSTS_KEY] });
    if (id) queryClient.invalidateQueries({ queryKey: [POST_KEY, id] });
  };
}

export function useCreateBlogPost() {
  const { session } = useAuth();
  const invalidate = useInvalidatePosts();
  return useMutation({
    mutationFn: (input: CreateBlogPostInput) => createBlogPost(session!.access_token, input),
    onSuccess: () => invalidate(),
  });
}

/** Also the autosave target (Sprint 3's useAutosave hook calls this via
 * a thin wrapper in the editor — see BlogEditor). */
export function useUpdateBlogPost(id: string) {
  const { session } = useAuth();
  const invalidate = useInvalidatePosts();
  return useMutation({
    mutationFn: (input: UpdateBlogPostInput) => updateBlogPost(session!.access_token, id, input),
    onSuccess: () => invalidate(id),
  });
}

export function useDeleteBlogPost() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  const invalidate = useInvalidatePosts();
  return useMutation({
    mutationFn: (id: string) => deleteBlogPost(session!.access_token, id),
    // Optimistic update (this sprint's §3 requirement): the row
    // disappears immediately rather than waiting on the round trip,
    // with an automatic rollback if the request fails — the same
    // pattern Phase 2.4 §20 specifies for exactly this kind of action.
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: [POSTS_KEY] });
      const previous = queryClient.getQueriesData({ queryKey: [POSTS_KEY] });

      queryClient.setQueriesData({ queryKey: [POSTS_KEY] }, (old: any) => {
        if (!old?.data) return old;
        return { ...old, data: old.data.filter((p: { id: string }) => p.id !== id) };
      });

      return { previous };
    },
    onError: (_err, _id, context) => {
      context?.previous?.forEach(([key, value]: [readonly unknown[], unknown]) => {
        queryClient.setQueryData(key, value);
      });
    },
    onSettled: () => invalidate(),
  });
}

/** One hook covering every lifecycle action (this sprint's reuse
 * mandate — a single mutation shape parameterized by action, rather than
 * five near-identical hooks). Status changes apply optimistically
 * (Sprint 5 §3) — the PublishPanel badge updates instantly, rolling back
 * if the server rejects the transition (e.g. missing featured image). */
export function useBlogPostLifecycle(id: string) {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  const invalidate = useInvalidatePosts();
  const token = () => session!.access_token;

  function optimisticStatus(nextStatus: string) {
    return {
      onMutate: async () => {
        await queryClient.cancelQueries({ queryKey: [POST_KEY, id] });
        const previous = queryClient.getQueryData([POST_KEY, id]);
        queryClient.setQueryData([POST_KEY, id], (old: any) =>
          old ? { ...old, status: nextStatus } : old
        );
        return { previous };
      },
      onError: (_err: unknown, _vars: unknown, context: { previous?: unknown }) => {
        if (context?.previous) queryClient.setQueryData([POST_KEY, id], context.previous);
      },
      onSettled: () => invalidate(id),
    };
  }

  const publish = useMutation({ mutationFn: () => publishBlogPost(token(), id), ...optimisticStatus("published") });
  const unpublish = useMutation({ mutationFn: () => unpublishBlogPost(token(), id), ...optimisticStatus("draft") });
  const archive = useMutation({ mutationFn: () => archiveBlogPost(token(), id), ...optimisticStatus("archived") });
  const restore = useMutation({ mutationFn: () => restoreBlogPostFromArchive(token(), id), ...optimisticStatus("draft") });
  const schedule = useMutation({
    mutationFn: (scheduledAt: string) => scheduleBlogPost(token(), id, scheduledAt),
    onSuccess: () => invalidate(id),
  });

  return { publish, unpublish, archive, restore, schedule };
}

export function useBlogCategories() {
  return useQuery({ queryKey: [CATEGORIES_KEY], queryFn: listBlogCategories, staleTime: 5 * 60_000 });
}

export function useCreateBlogCategory() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: { name: string; description?: string }) =>
      createBlogCategory(session!.access_token, input),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [CATEGORIES_KEY] }),
  });
}

export function useTags() {
  return useQuery({ queryKey: [TAGS_KEY], queryFn: listTags, staleTime: 5 * 60_000 });
}

export function useCreateTag() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (name: string) => createTag(session!.access_token, name),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [TAGS_KEY] }),
  });
}

/** Returns a stable checkAvailability function bound to the current
 * session/post-id, for TitleSlugFields' `checkSlugAvailability` prop
 * (Sprint 3 built the prop, Sprint 5 is its first real wiring). */
export function useCheckSlugAvailability(excludeId?: string) {
  const { session } = useAuth();
  return React.useCallback(
    (slug: string) => checkBlogSlugAvailability(session!.access_token, slug, excludeId),
    [session, excludeId]
  );
}
