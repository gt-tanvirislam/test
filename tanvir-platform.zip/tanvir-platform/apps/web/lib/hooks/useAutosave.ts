"use client";

import * as React from "react";

export type AutosaveStatus = "idle" | "saving" | "saved" | "error";

interface UseAutosaveOptions<T> {
  data: T;
  onSave: (data: T) => Promise<void>;
  /** ms of inactivity before saving — Phase 2.2 §11's "~30s" default. */
  debounceMs?: number;
  enabled?: boolean;
}

/**
 * Autosave foundation (this sprint's §5 — architecture only, no realtime
 * sync). Debounces changes to `data` and calls `onSave`. A future
 * BlogEditor/PortfolioEditor wires this to its real form state and a
 * real "save draft" API call — this hook has no knowledge of what it's
 * saving, matching the "reusable across every future module" requirement.
 *
 * Deliberately does NOT create a revision snapshot on every autosave —
 * per Phase 2.2 §21, a revision is only created at publish or an
 * explicit "save version" action, autosave just keeps the draft current.
 */
export function useAutosave<T>({ data, onSave, debounceMs = 30_000, enabled = true }: UseAutosaveOptions<T>) {
  const [status, setStatus] = React.useState<AutosaveStatus>("idle");
  const [lastSavedAt, setLastSavedAt] = React.useState<Date | null>(null);
  const dataRef = React.useRef(data);
  dataRef.current = data;

  React.useEffect(() => {
    if (!enabled) return;

    const timeout = setTimeout(async () => {
      setStatus("saving");
      try {
        await onSave(dataRef.current);
        setStatus("saved");
        setLastSavedAt(new Date());
      } catch {
        setStatus("error");
      }
    }, debounceMs);

    return () => clearTimeout(timeout);
    // Re-runs whenever `data` changes — resets the debounce timer on
    // every edit, per the "periodic while editing" spec (not fixed-interval).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, debounceMs, enabled]);

  return { status, lastSavedAt };
}
