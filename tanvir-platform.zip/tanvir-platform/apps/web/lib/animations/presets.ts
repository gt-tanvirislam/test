import type { Variants } from "framer-motion";

import { motion as motionTokens } from "@tanvir-platform/ui";

/**
 * Named Framer Motion variants (Phase 2.7 §8) — every animated component
 * uses one of these rather than defining a bespoke curve inline. Values
 * derive from the motion tokens (packages/ui/src/tokens), never hardcoded.
 *
 * GSAP ScrollTrigger presets are added in the sprint that builds the first
 * public marketing page (homepage), since they need real DOM sections to
 * register against — no value in stubbing them before there's content to
 * animate.
 */

const { duration, easing } = motionTokens;
const s = (ms: number) => ms / 1000;

export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: s(duration.base), ease: easing.standard },
  },
};

export const fadeInUp: Variants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: s(duration.base), ease: easing.out },
  },
};

export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.96 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: s(duration.fast), ease: easing.out },
  },
};

/** Modal/drawer entrance — Phase 2.5 §3.8 */
export const overlayEnter: Variants = {
  hidden: { opacity: 0, scale: 0.96 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: s(duration.base), ease: easing.out },
  },
  exit: {
    opacity: 0,
    scale: 0.98,
    transition: { duration: s(duration.fast), ease: easing.in },
  },
};
