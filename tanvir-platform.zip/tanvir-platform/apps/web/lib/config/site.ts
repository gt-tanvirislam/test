import type { FooterColumn } from "@/components/layout/Footer";
import type { NavItem } from "@/components/layout/NavBar";
import { getNavigation } from "@/lib/api/navigation";
import { getSiteSettings } from "@/lib/api/settings";

export interface SiteConfig {
  siteName: string;
  navItems: NavItem[];
  footerColumns: FooterColumn[];
  socialLinks: { platform: string; url: string }[];
  contactEmail: string | null;
}

/**
 * Site configuration source (Sprint 7 — "Global Site Settings
 * (future-ready)"). This is the ONE function every public layout piece
 * calls for structural content — no component below this ever hardcodes
 * a nav item or social link.
 *
 * Structural chrome (nav items, footer columns) and the editable content
 * bits (site name, social links, public contact email) now all come from
 * the backend: the Navigation module (`GET /navigation`) supplies the header
 * menu and footer columns, and the Settings module (`GET /settings`)
 * supplies the site name, social links, and contact email. Each fetch is
 * wrapped independently so a backend outage — or a fresh DB with no rows —
 * degrades to the honest static defaults below rather than breaking every
 * public page: never a crash, never invented content.
 */
const STATIC_SITE_CONFIG: SiteConfig = {
  siteName: "Tamvir Islam",
  navItems: [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
    { label: "Services", href: "/services" },
    { label: "Portfolio", href: "/portfolio" },
    { label: "Blog", href: "/blog" },
    { label: "Contact", href: "/contact" },
  ],
  footerColumns: [
    {
      title: "Site",
      items: [
        { label: "About", href: "/about" },
        { label: "Services", href: "/services" },
        { label: "Portfolio", href: "/portfolio" },
        { label: "Blog", href: "/blog" },
      ],
    },
    {
      title: "Get in touch",
      items: [{ label: "Contact", href: "/contact" }],
    },
  ],
  socialLinks: [], // overlaid from Settings when available (Phase 2.11 §3)
  contactEmail: null, // overlaid from Settings when available (Phase 2.11 §12)
};
export interface HomepageContent {
  hero: {
    eyebrow: string;
    headline: string;
    subheadline: string;
    primaryCta: { label: string; href: string };
    secondaryCta?: { label: string; href: string };
  };
  aboutIntro: {
    eyebrow: string;
    headline: string;
    body: string;
    ctaLabel: string;
    ctaHref: string;
  };
  whyChooseUs: {
    eyebrow: string;
    headline: string;
    items: { title: string; description: string }[];
  };
  process: {
    eyebrow: string;
    headline: string;
    steps: { title: string; description: string }[];
  };
  finalCta: {
    headline: string;
    subheadline: string;
    ctaLabel: string;
    ctaHref: string;
  };
}

/**
 * Homepage content source (Sprint 9). Kept separate from
 * `getSiteConfig()` — that function is layout-wide chrome (nav/footer)
 * loaded on every route; this is homepage-specific and only the
 * homepage awaits it, avoiding an unrelated data dependency on every
 * other page.
 *
 * Content-policy note (Sprint 9, Phase 2.10 §8): every string below is
 * brand-positioning copy consistent with Phase 1.1/2.11's established
 * positioning — it contains NO invented statistics, testimonials,
 * client names, or unverifiable claims. It's still placeholder-quality
 * in the sense that Tamvir hasn't reviewed/approved the exact wording,
 * which is why it's isolated in this one function rather than baked
 * into section components — replacing it with approved copy later is a
 * one-file edit, not a component rewrite (matching this sprint's
 * "future-ready without rewriting the section" requirement for Why
 * Choose Us specifically, applied consistently to every text section).
 */
export async function getHomepageContent(): Promise<HomepageContent> {
  return {
    hero: {
      eyebrow: "Video Editing · Graphic Design · Motion Graphics · Photo Editing",
      headline: "Creative work built to an international standard.",
      subheadline:
        "I help brands and creators tell sharper stories through video, design, and motion — with the clarity and craftsmanship international clients expect.",
      primaryCta: { label: "View my work", href: "/portfolio" },
      secondaryCta: { label: "See services", href: "/services" },
    },
    aboutIntro: {
      eyebrow: "About",
      headline: "A creative practice built on craft and clear communication.",
      body: "Every project gets the same attention to detail, whether it's a short-form edit or a full brand identity — with a process designed to keep you informed at every step, wherever in the world you're working from.",
      ctaLabel: "More about my approach",
      ctaHref: "/about",
    },
    whyChooseUs: {
      eyebrow: "Why work with me",
      headline: "What you can expect",
      items: [
        {
          title: "International quality standard",
          description: "Work benchmarked against global creative studios, not just local expectations.",
        },
        {
          title: "Clear, responsive communication",
          description: "You'll always know where your project stands — no chasing for updates.",
        },
        {
          title: "One person, full accountability",
          description: "Your project is handled directly, not passed between account managers.",
        },
      ],
    },
    process: {
      eyebrow: "How it works",
      headline: "A straightforward process",
      steps: [
        { title: "Discover", description: "We talk through what you need and what success looks like." },
        { title: "Create", description: "I get to work, with regular check-ins so nothing feels like a black box." },
        { title: "Deliver", description: "You receive final files, ready to publish, with room for revisions along the way." },
      ],
    },
    finalCta: {
      headline: "Have a project in mind?",
      subheadline: "Tell me about it — I typically respond within a business day.",
      ctaLabel: "Get in touch",
      ctaHref: "/contact",
    },
  };
}

/** Fetch the editable navigation tree, mapping the API's `{label, url}`
 * shape to the `NavItem`/`FooterColumn` shape the layout components expect.
 * A backend outage or an empty tree falls back to the static structure so
 * the header/footer are never blank. */
async function resolveNavigation(): Promise<Pick<SiteConfig, "navItems" | "footerColumns">> {
  try {
    const nav = await getNavigation();
    const navItems: NavItem[] = nav.header.map((h) => ({ label: h.label, href: h.url }));
    const footerColumns: FooterColumn[] = nav.footer.map((c) => ({
      title: c.title,
      items: c.items.map((i) => ({ label: i.label, href: i.url })),
    }));
    return {
      navItems: navItems.length > 0 ? navItems : STATIC_SITE_CONFIG.navItems,
      footerColumns: footerColumns.length > 0 ? footerColumns : STATIC_SITE_CONFIG.footerColumns,
    };
  } catch {
    return {
      navItems: STATIC_SITE_CONFIG.navItems,
      footerColumns: STATIC_SITE_CONFIG.footerColumns,
    };
  }
}

/** Fetch the editable brand/contact bits. Falls back to the static defaults
 * (site name "Tamvir Islam", no social links, no contact email) on error. */
async function resolveSettings(): Promise<Pick<SiteConfig, "siteName" | "socialLinks" | "contactEmail">> {
  try {
    const settings = await getSiteSettings();
    return {
      // A blank site_name should never blank the header — fall back to the
      // static default if the stored value is empty.
      siteName: settings.site_name?.trim() || STATIC_SITE_CONFIG.siteName,
      socialLinks: settings.social_links ?? [],
      contactEmail: settings.contact_email,
    };
  } catch {
    return {
      siteName: STATIC_SITE_CONFIG.siteName,
      socialLinks: STATIC_SITE_CONFIG.socialLinks,
      contactEmail: STATIC_SITE_CONFIG.contactEmail,
    };
  }
}

export async function getSiteConfig(): Promise<SiteConfig> {
  // Independent fetches so one failing (or empty) source never suppresses the
  // other — nav can come from the DB while settings falls back, or vice versa.
  const [navigation, settings] = await Promise.all([resolveNavigation(), resolveSettings()]);
  return { ...STATIC_SITE_CONFIG, ...navigation, ...settings };
}
