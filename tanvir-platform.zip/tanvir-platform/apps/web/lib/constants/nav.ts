import {
  LayoutDashboard,
  FileText,
  Briefcase,
  FolderKanban,
  Newspaper,
  Image as ImageIcon,
  MessageSquare,
  Inbox,
  Star,
  HelpCircle,
  Search,
  Users,
  Menu,
  Settings,
} from "lucide-react";

/**
 * Single source of truth for dashboard navigation (Phase 2.4 §2's
 * grouped-sidebar spec, this sprint's required item list). Consumed by
 * both DashboardSidebar (desktop) and MobileNav (drawer) so they can
 * never drift out of sync.
 *
 * Each item carries the backend permission key that gates its screen
 * (`null` = visible to any authenticated user). The sidebar/drawer hide
 * items the current user lacks — but this is UX only: the backend's
 * `require_permission` on every endpoint remains authoritative, so hiding
 * a link never substitutes for server-side enforcement. Keys match the
 * permission catalog seeded in migration 0001 and enforced in the routers.
 */
export const NAV_ITEMS = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard, permission: null },
  { label: "Pages", href: "/dashboard/pages", icon: FileText, permission: "content.view_drafts" },
  { label: "Services", href: "/dashboard/services", icon: Briefcase, permission: "content.view_drafts" },
  { label: "Portfolio", href: "/dashboard/portfolio", icon: FolderKanban, permission: "content.view_drafts" },
  { label: "Blog", href: "/dashboard/blog", icon: Newspaper, permission: "content.view_drafts" },
  { label: "Media Library", href: "/dashboard/media", icon: ImageIcon, permission: "media.manage" },
  { label: "Comments", href: "/dashboard/comments", icon: MessageSquare, permission: "comments.moderate" },
  { label: "Inquiries", href: "/dashboard/inquiries", icon: Inbox, permission: "inquiries.view" },
  { label: "Testimonials", href: "/dashboard/testimonials", icon: Star, permission: "testimonials.view" },
  { label: "FAQ", href: "/dashboard/faq", icon: HelpCircle, permission: "faq.view" },
  { label: "SEO", href: "/dashboard/seo", icon: Search, permission: "content.edit_any" },
  { label: "Users", href: "/dashboard/users", icon: Users, permission: "users.manage" },
  { label: "Navigation", href: "/dashboard/navigation", icon: Menu, permission: "navigation.manage" },
  { label: "Settings", href: "/dashboard/settings", icon: Settings, permission: "settings.manage" },
] as const;

export type NavItem = (typeof NAV_ITEMS)[number];

/**
 * Pure permission filter shared by the sidebar and mobile drawer (and unit
 * tested in isolation). An item with `permission: null` is always kept;
 * otherwise the user must hold the matching key. Extracted from the hook so
 * the branching logic can be tested without React context.
 */
export function filterNavByPermissions<T extends { permission: string | null }>(
  items: readonly T[],
  permissions: readonly string[]
): T[] {
  const granted = new Set(permissions);
  return items.filter((item) => item.permission === null || granted.has(item.permission));
}
