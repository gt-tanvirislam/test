"use client";

import * as React from "react";

/**
 * Root error boundary (Phase 2.7 §14). Calmer, apologetic tone per Phase
 * 2.6 §9 — no search bar (this is a system issue, not a navigation one).
 * Individual route segments get their own error.tsx as those segments are
 * built (Phase 2.7 §6's isolation principle), so a failure in one section
 * doesn't take down the whole page — this file is the outermost fallback.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  React.useEffect(() => {
    // Structured logging / error tracking integration lands with the
    // observability pass (Phase 2.8 §16) — console.error is a temporary
    // stand-in so failures aren't silently swallowed during this sprint.
    console.error(error);
  }, [error]);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <h1 className="text-h2 text-neutral-800 dark:text-text-dark-primary">
        Something went wrong.
      </h1>
      <p className="mt-3 max-w-sm text-body text-neutral-500 dark:text-text-dark-secondary">
        This wasn&apos;t your fault. Try again, or come back in a moment.
      </p>
      <button
        onClick={reset}
        className="mt-6 rounded-md border border-neutral-300 px-5 py-3 text-button font-medium text-neutral-800 hover:bg-neutral-50 dark:border-surface-dark-border dark:text-text-dark-primary"
      >
        Try again
      </button>
    </div>
  );
}
