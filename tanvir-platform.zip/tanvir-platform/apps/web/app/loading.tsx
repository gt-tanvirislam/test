/**
 * Root-level loading fallback. Per-segment loading.tsx (skeleton-shaped,
 * matching destination layout — Phase 2.6 §10) is added as each route's
 * real content is built; this is the generic top-level fallback used only
 * when no more specific segment boundary applies.
 */
export default function RootLoading() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div
        className="h-8 w-8 animate-spin rounded-full border-2 border-neutral-300 border-t-accent-500"
        role="status"
        aria-label="Loading"
      />
    </div>
  );
}
