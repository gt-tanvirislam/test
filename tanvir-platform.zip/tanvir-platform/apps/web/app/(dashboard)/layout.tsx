import { DashboardAuthGuard } from "@/components/dashboard/DashboardAuthGuard";
import { DashboardHeader } from "@/components/layout/DashboardHeader";
import { DashboardSidebar } from "@/components/layout/DashboardSidebar";

/**
 * Dashboard layout (Phase 2.7 §3) — sidebar + topbar shell, auth-gated.
 * Notification listener and real navigation are wired in the sprint that
 * builds the Users/Auth and Notifications backend modules.
 */
export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <DashboardAuthGuard>
      <div className="flex min-h-screen">
        <DashboardSidebar />
        <div className="flex flex-1 flex-col">
          <DashboardHeader />
          <main id="main-content" className="flex-1 p-6">{children}</main>
        </div>
      </div>
    </DashboardAuthGuard>
  );
}
