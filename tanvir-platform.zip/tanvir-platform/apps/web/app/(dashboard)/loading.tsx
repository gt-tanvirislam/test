import { Skeleton } from "@tanvir-platform/ui";

/**
 * Dashboard-scoped loading fallback (Phase 2.6 §10), migrated to the
 * shared Skeleton primitive (Sprint 5) for consistency with every other
 * loading state in the dashboard.
 */
export default function DashboardLoading() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-6 w-48" />
      <Skeleton className="h-32 w-full" />
    </div>
  );
}
