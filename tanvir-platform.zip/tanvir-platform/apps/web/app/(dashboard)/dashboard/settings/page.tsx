import { PageHeader } from "@tanvir-platform/ui";

import { PermissionGate } from "@/components/dashboard/PermissionGate";
import { SettingsForm } from "@/components/dashboard/settings/SettingsForm";

/**
 * Global site settings (Phase 2.2 §4.7). Edits the single settings record —
 * site name, tagline, public contact email, default SEO description, and
 * social links — read by the public site chrome via `getSiteConfig()`.
 *
 * Gated by `settings.manage`: a non-admin who reaches this route sees
 * AccessDenied. The gate is a UX guard only — the backend PATCH endpoint
 * independently enforces `settings.manage`, so it remains the authoritative
 * check.
 */
export default function SettingsPage() {
  return (
    <PermissionGate permission="settings.manage">
      <PageHeader title="Settings" description="Manage global site configuration." />
      <SettingsForm />
    </PermissionGate>
  );
}
