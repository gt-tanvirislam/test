import { PageHeader, EmptyState } from "@tanvir-platform/ui";
import { FolderKanban } from "lucide-react";

/**
 * SCAFFOLD PLACEHOLDER — Pages CRUD is built in a future sprint once
 * its backend module exists (Phase 2.8 §19). This sprint only confirms
 * the route, layout, and navigation work end to end.
 */
export default function PagesPlaceholder() {
  return (
    <div>
      <PageHeader title="Pages" description="Homepage sections, About, and other structural page content." />
      <EmptyState
        icon={<FolderKanban size={28} />}
        title="Coming in a future sprint"
        description="This section's management tools are built once the Pages backend module exists."
      />
    </div>
  );
}
