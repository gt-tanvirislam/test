"use client";

import { EmptyState, Skeleton } from "@tanvir-platform/ui";
import { FileWarning } from "lucide-react";
import { useParams } from "next/navigation";

import { BlogEditor } from "@/components/dashboard/blog/BlogEditor";
import { useBlogPost } from "@/lib/hooks/useBlog";

export default function EditBlogPostPage() {
  const params = useParams<{ id: string }>();
  const { data: post, isLoading, isError } = useBlogPost(params.id);

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (isError || !post) {
    return (
      <EmptyState
        icon={<FileWarning size={28} />}
        title="Post not found"
        description="This post may have been deleted or the link is incorrect."
      />
    );
  }

  return <BlogEditor post={post} />;
}
