"use client";

import * as React from "react";
import { useRouter } from "next/navigation";

import { useCreateBlogPost } from "@/lib/hooks/useBlog";

/**
 * "New post" is a create-then-redirect flow (matches how Ghost/WordPress
 * handle this): a minimal draft is created immediately so autosave and
 * the publish workflow have a real `post_id` to operate against from the
 * first keystroke, rather than the editor needing a separate
 * "unsaved new post" mode.
 */
export default function NewBlogPostPage() {
  const router = useRouter();
  const createPost = useCreateBlogPost();
  const hasTriggered = React.useRef(false);

  React.useEffect(() => {
    if (hasTriggered.current) return;
    hasTriggered.current = true;

    createPost.mutateAsync({ title: "Untitled post" }).then((post) => {
      router.replace(`/dashboard/blog/${post.id}/edit`);
    });
  }, [createPost, router]);

  return (
    <div className="flex min-h-[50vh] items-center justify-center text-body-sm text-neutral-400">
      Creating draft…
    </div>
  );
}
