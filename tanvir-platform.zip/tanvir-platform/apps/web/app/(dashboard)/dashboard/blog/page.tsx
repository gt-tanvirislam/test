"use client";

import type { BlogPostListFilters } from "@tanvir-platform/types";
import { Button, EmptyState, PageHeader, Skeleton, useToast } from "@tanvir-platform/ui";
import { FileText, Plus } from "lucide-react";
import { useRouter } from "next/navigation";
import * as React from "react";

import { BlogListToolbar } from "@/components/dashboard/blog/BlogListToolbar";
import { BlogTable } from "@/components/dashboard/blog/BlogTable";
import { useBlogPosts, useDeleteBlogPost } from "@/lib/hooks/useBlog";

/**
 * Blog list page. Sprint 5 replaces the ad-hoc animate-pulse loading
 * rows with the shared Skeleton primitive and adds toast feedback on
 * delete failures (optimistic delete itself lives in useDeleteBlogPost).
 */
export default function BlogListPage() {
  const router = useRouter();
  const { showToast } = useToast();
  const [filters, setFilters] = React.useState<BlogPostListFilters>({ page: 1, per_page: 20 });
  const [selectedIds, setSelectedIds] = React.useState<string[]>([]);

  const { data, isLoading } = useBlogPosts(filters);
  const deletePost = useDeleteBlogPost();

  const posts = data?.data ?? [];

  async function handleDelete(id: string) {
    try {
      await deletePost.mutateAsync(id);
      setSelectedIds((prev) => prev.filter((i) => i !== id));
    } catch {
      showToast("Couldn't delete this post", "error");
    }
  }

  async function handleBulkDelete() {
    try {
      await Promise.all(selectedIds.map((id) => deletePost.mutateAsync(id)));
      setSelectedIds([]);
    } catch {
      showToast("Some posts couldn't be deleted", "error");
    }
  }

  return (
    <div>
      <PageHeader
        title="Blog"
        description="Write and manage blog posts."
        actions={
          <Button onClick={() => router.push("/dashboard/blog/new")}>
            <Plus size={16} />
            New post
          </Button>
        }
      />

      <BlogListToolbar filters={filters} onChange={setFilters} />

      {selectedIds.length > 0 && (
        <div className="mb-4 flex items-center justify-between rounded-sm bg-accent-50 px-3 py-2 text-body-sm dark:bg-surface-dark-2">
          <span>{selectedIds.length} selected</span>
          <Button variant="destructive" size="sm" onClick={handleBulkDelete}>
            Delete selected
          </Button>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : posts.length === 0 ? (
        <EmptyState
          icon={<FileText size={28} />}
          title="No posts yet"
          description="Write your first blog post to get started."
          action={<Button onClick={() => router.push("/dashboard/blog/new")}>New post</Button>}
        />
      ) : (
        <BlogTable
          posts={posts}
          selectedIds={selectedIds}
          onSelectionChange={setSelectedIds}
          onDelete={handleDelete}
        />
      )}
    </div>
  );
}
