import { PageHeader, EmptyState } from "@tanvir-platform/ui";
import { FolderKanban } from "lucide-react";

/**
 * SCAFFOLD PLACEHOLDER — FAQ CRUD is built in a future sprint once
 * its backend module exists (Phase 2.8 §19). This sprint only confirms
 * the route, layout, and navigation work end to end.
 */
export default function FaqPlaceholder() {
  return (
    <div>
      <PageHeader title="FAQ" description="Manage frequently asked questions." />
      <EmptyState
        icon={<FolderKanban size={28} />}
        title="Coming in a future sprint"
        description="This section's management tools are built once the FAQ backend module exists."
      />
    </div>
  );
}
