import { PageHeader } from "@tanvir-platform/ui";

import { PermissionGate } from "@/components/dashboard/PermissionGate";
import { NavigationEditor } from "@/components/dashboard/navigation/NavigationEditor";

/**
 * Navigation management (Phase 2.2 §4.7). Edits the header menu and footer
 * columns read by the public site chrome via `getSiteConfig()`.
 *
 * Gated by `navigation.manage`; the backend PUT endpoint enforces the same
 * permission independently, so this gate is a UX guard, not the security
 * boundary.
 */
export default function NavigationPage() {
  return (
    <PermissionGate permission="navigation.manage">
      <PageHeader title="Navigation" description="Manage the site header menu and footer links." />
      <NavigationEditor />
    </PermissionGate>
  );
}
