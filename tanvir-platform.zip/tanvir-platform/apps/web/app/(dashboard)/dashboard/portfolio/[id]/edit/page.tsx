"use client";

import { EmptyState, Skeleton } from "@tanvir-platform/ui";
import { FileWarning } from "lucide-react";
import { useParams } from "next/navigation";

import { PortfolioEditor } from "@/components/dashboard/portfolio/PortfolioEditor";
import { usePortfolioItem } from "@/lib/hooks/usePortfolio";

export default function EditPortfolioItemPage() {
  const params = useParams<{ id: string }>();
  const { data: item, isLoading, isError } = usePortfolioItem(params.id);

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (isError || !item) {
    return (
      <EmptyState
        icon={<FileWarning size={28} />}
        title="Project not found"
        description="This project may have been deleted or the link is incorrect."
      />
    );
  }

  return <PortfolioEditor item={item} />;
}
