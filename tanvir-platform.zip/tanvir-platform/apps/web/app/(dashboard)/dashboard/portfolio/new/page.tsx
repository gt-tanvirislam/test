"use client";

import * as React from "react";
import { useRouter } from "next/navigation";

import { useCreatePortfolioItem } from "@/lib/hooks/usePortfolio";

export default function NewPortfolioItemPage() {
  const router = useRouter();
  const createItem = useCreatePortfolioItem();
  const hasTriggered = React.useRef(false);

  React.useEffect(() => {
    if (hasTriggered.current) return;
    hasTriggered.current = true;

    createItem.mutateAsync({ title: "Untitled project" }).then((item) => {
      router.replace(`/dashboard/portfolio/${item.id}/edit`);
    });
  }, [createItem, router]);

  return (
    <div className="flex min-h-[50vh] items-center justify-center text-body-sm text-neutral-400">
      Creating draft…
    </div>
  );
}
