"use client";

import type { PortfolioItemListFilters } from "@tanvir-platform/types";
import { Button, EmptyState, PageHeader, Skeleton, useToast } from "@tanvir-platform/ui";
import { FolderKanban, Plus } from "lucide-react";
import { useRouter } from "next/navigation";
import * as React from "react";

import { PortfolioListToolbar } from "@/components/dashboard/portfolio/PortfolioListToolbar";
import { PortfolioTable } from "@/components/dashboard/portfolio/PortfolioTable";
import { useDeletePortfolioItem, usePortfolioItems } from "@/lib/hooks/usePortfolio";

/**
 * Portfolio list page (Sprint 6 — replaces the Sprint 1 placeholder).
 * Structurally identical to the Blog list page (Sprint 4/5), proving
 * the reference pattern generalizes to the second content module.
 */
export default function PortfolioListPage() {
  const router = useRouter();
  const { showToast } = useToast();
  const [filters, setFilters] = React.useState<PortfolioItemListFilters>({ page: 1, per_page: 20 });
  const [selectedIds, setSelectedIds] = React.useState<string[]>([]);

  const { data, isLoading } = usePortfolioItems(filters);
  const deleteItem = useDeletePortfolioItem();

  const items = data?.data ?? [];

  async function handleDelete(id: string) {
    try {
      await deleteItem.mutateAsync(id);
      setSelectedIds((prev) => prev.filter((i) => i !== id));
    } catch {
      showToast("Couldn't delete this project", "error");
    }
  }

  async function handleBulkDelete() {
    try {
      await Promise.all(selectedIds.map((id) => deleteItem.mutateAsync(id)));
      setSelectedIds([]);
    } catch {
      showToast("Some projects couldn't be deleted", "error");
    }
  }

  return (
    <div>
      <PageHeader
        title="Portfolio"
        description="Manage video, design, photo, and motion graphics projects."
        actions={
          <Button onClick={() => router.push("/dashboard/portfolio/new")}>
            <Plus size={16} />
            New project
          </Button>
        }
      />

      <PortfolioListToolbar filters={filters} onChange={setFilters} />

      {selectedIds.length > 0 && (
        <div className="mb-4 flex items-center justify-between rounded-sm bg-accent-50 px-3 py-2 text-body-sm dark:bg-surface-dark-2">
          <span>{selectedIds.length} selected</span>
          <Button variant="destructive" size="sm" onClick={handleBulkDelete}>
            Delete selected
          </Button>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={<FolderKanban size={28} />}
          title="No projects yet"
          description="Add your first portfolio project to get started."
          action={<Button onClick={() => router.push("/dashboard/portfolio/new")}>New project</Button>}
        />
      ) : (
        <PortfolioTable
          items={items}
          selectedIds={selectedIds}
          onSelectionChange={setSelectedIds}
          onDelete={handleDelete}
        />
      )}
    </div>
  );
}
