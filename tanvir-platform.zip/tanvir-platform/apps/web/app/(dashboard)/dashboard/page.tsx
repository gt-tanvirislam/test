import { PageHeader, StatCard, EmptyState } from "@tanvir-platform/ui";
import { Activity } from "lucide-react";

/**
 * Dashboard home — Sprint 1 upgrades Sprint 0's bare placeholder to use
 * the real shared components built this sprint. Actual stats/activity
 * feed/quick-actions content (Phase 2.4 §3) is wired once the modules
 * that generate that data exist — explicitly out of scope here.
 */
export default function DashboardHomePlaceholder() {
  return (
    <div>
      <PageHeader
        title="Dashboard"
        description="An overview of your site will appear here once content modules are built."
      />

      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Published posts" value="—" />
        <StatCard label="Portfolio items" value="—" />
        <StatCard label="New inquiries" value="—" />
      </div>

      <EmptyState
        icon={<Activity size={28} />}
        title="No activity yet"
        description="Once you start publishing content, recent activity will show up here."
      />
    </div>
  );
}
