"use client";

import type { MediaAsset } from "@tanvir-platform/types";
import { ActionBar, EmptyState, PageHeader, Skeleton } from "@tanvir-platform/ui";
import { ImageOff } from "lucide-react";
import * as React from "react";

import { MediaAssetDrawer } from "@/components/dashboard/media/MediaAssetDrawer";
import { MediaGrid } from "@/components/dashboard/media/MediaGrid";
import { MediaUploadButton } from "@/components/dashboard/media/MediaUploadButton";
import { UploadDialog } from "@/components/dashboard/media/UploadDialog";
import { useMediaAssets, useMediaFolders } from "@/lib/hooks/useMedia";

/**
 * Media Library (Phase 2.4 §8) — Sprint 2's real implementation,
 * replacing the placeholder from Sprint 1. Folder filtering, bulk
 * upload, and the "used/unused" filter (Phase 2.4 §21's flagged
 * performance follow-up) are left for a future pass; this sprint
 * delivers the complete core loop: upload → view → edit alt text →
 * delete-with-usage-protection.
 */
export default function MediaLibraryPage() {
  const [selectedFolderId, setSelectedFolderId] = React.useState<string | undefined>();
  const [pendingFile, setPendingFile] = React.useState<File | null>(null);
  const [selectedAsset, setSelectedAsset] = React.useState<MediaAsset | null>(null);

  const { data: foldersData } = useMediaFolders();
  const { data: assetsData, isLoading } = useMediaAssets(selectedFolderId);

  const assets = assetsData?.data ?? [];

  return (
    <div>
      <PageHeader
        title="Media Library"
        description="Upload and organize images, video, and documents."
        actions={<MediaUploadButton onFileSelected={setPendingFile} />}
      />

      <ActionBar>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedFolderId(undefined)}
            className={`rounded-sm px-3 py-1.5 text-body-sm ${
              !selectedFolderId
                ? "bg-accent-500 text-white"
                : "text-neutral-600 hover:bg-neutral-100 dark:text-text-dark-secondary"
            }`}
          >
            All
          </button>
          {foldersData?.map((folder) => (
            <button
              key={folder.id}
              onClick={() => setSelectedFolderId(folder.id)}
              className={`rounded-sm px-3 py-1.5 text-body-sm ${
                selectedFolderId === folder.id
                  ? "bg-accent-500 text-white"
                  : "text-neutral-600 hover:bg-neutral-100 dark:text-text-dark-secondary"
              }`}
            >
              {folder.name}
            </button>
          ))}
        </div>
      </ActionBar>

      {isLoading ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="aspect-square"
            >
              <Skeleton className="h-full w-full" />
            </div>
          ))}
        </div>
      ) : assets.length === 0 ? (
        <EmptyState
          icon={<ImageOff size={28} />}
          title="No files yet"
          description="Upload your first image, video, or document to get started."
        />
      ) : (
        <MediaGrid assets={assets} onSelect={setSelectedAsset} />
      )}

      <UploadDialog file={pendingFile} onClose={() => setPendingFile(null)} />
      <MediaAssetDrawer asset={selectedAsset} onClose={() => setSelectedAsset(null)} />
    </div>
  );
}
