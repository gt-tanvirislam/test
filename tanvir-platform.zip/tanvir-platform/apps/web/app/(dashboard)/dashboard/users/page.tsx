import { PageHeader, EmptyState } from "@tanvir-platform/ui";
import { FolderKanban } from "lucide-react";

import { PermissionGate } from "@/components/dashboard/PermissionGate";

/**
 * SCAFFOLD PLACEHOLDER — Users CRUD is built in a future sprint once
 * its backend module exists (Phase 2.8 §19). This sprint only confirms
 * the route, layout, and navigation work end to end.
 *
 * Gated by `users.manage`: even as a placeholder, a non-admin who reaches
 * this route sees AccessDenied rather than the scaffold — the same gate
 * the real CRUD screen will use. The backend `users.manage` permission
 * remains the authoritative check for any actual user data.
 */
export default function UsersPlaceholder() {
  return (
    <PermissionGate permission="users.manage">
      <PageHeader title="Users" description="Manage administrators and their roles." />
      <EmptyState
        icon={<FolderKanban size={28} />}
        title="Coming in a future sprint"
        description="This section's management tools are built once the Users backend module exists."
      />
    </PermissionGate>
  );
}
