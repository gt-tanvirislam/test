"use client";

import * as React from "react";
import { useRouter } from "next/navigation";

import { useCreateService } from "@/lib/hooks/useServices";

export default function NewServicePage() {
  const router = useRouter();
  const createService = useCreateService();
  const hasTriggered = React.useRef(false);

  React.useEffect(() => {
    if (hasTriggered.current) return;
    hasTriggered.current = true;

    createService.mutateAsync({ title: "Untitled service" }).then((service) => {
      router.replace(`/dashboard/services/${service.id}/edit`);
    });
  }, [createService, router]);

  return (
    <div className="flex min-h-[50vh] items-center justify-center text-body-sm text-neutral-400">
      Creating draft…
    </div>
  );
}
