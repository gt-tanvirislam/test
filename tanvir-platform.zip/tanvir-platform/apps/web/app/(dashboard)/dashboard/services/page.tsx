"use client";

import type { ServiceListFilters } from "@tanvir-platform/types";
import { Briefcase, Plus } from "lucide-react";
import { Button, EmptyState, PageHeader, Skeleton, useToast } from "@tanvir-platform/ui";
import { useRouter } from "next/navigation";
import * as React from "react";

import { ServiceListToolbar } from "@/components/dashboard/services/ServiceListToolbar";
import { ServiceTable } from "@/components/dashboard/services/ServiceTable";
import { useDeleteService, useServices } from "@/lib/hooks/useServices";

/**
 * Services list page (Sprint 8 — replaces the Sprint 1 placeholder).
 * Third proof this list-page pattern generalizes without modification
 * (Blog Sprint 4/5, Portfolio Sprint 6, now Services).
 */
export default function ServicesListPage() {
  const router = useRouter();
  const { showToast } = useToast();
  const [filters, setFilters] = React.useState<ServiceListFilters>({ page: 1, per_page: 20 });
  const [selectedIds, setSelectedIds] = React.useState<string[]>([]);

  const { data, isLoading } = useServices(filters);
  const deleteService = useDeleteService();

  const items = data?.data ?? [];

  async function handleDelete(id: string) {
    try {
      await deleteService.mutateAsync(id);
      setSelectedIds((prev) => prev.filter((i) => i !== id));
    } catch {
      showToast("Couldn't delete this service", "error");
    }
  }

  async function handleBulkDelete() {
    try {
      await Promise.all(selectedIds.map((id) => deleteService.mutateAsync(id)));
      setSelectedIds([]);
    } catch {
      showToast("Some services couldn't be deleted", "error");
    }
  }

  return (
    <div>
      <PageHeader
        title="Services"
        description="Manage your service offerings."
        actions={
          <Button onClick={() => router.push("/dashboard/services/new")}>
            <Plus size={16} />
            New service
          </Button>
        }
      />

      <ServiceListToolbar filters={filters} onChange={setFilters} />

      {selectedIds.length > 0 && (
        <div className="mb-4 flex items-center justify-between rounded-sm bg-accent-50 px-3 py-2 text-body-sm dark:bg-surface-dark-2">
          <span>{selectedIds.length} selected</span>
          <Button variant="destructive" size="sm" onClick={handleBulkDelete}>
            Delete selected
          </Button>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={<Briefcase size={28} />}
          title="No services yet"
          description="Add your first service offering to get started."
          action={<Button onClick={() => router.push("/dashboard/services/new")}>New service</Button>}
        />
      ) : (
        <ServiceTable
          items={items}
          selectedIds={selectedIds}
          onSelectionChange={setSelectedIds}
          onDelete={handleDelete}
        />
      )}
    </div>
  );
}
