"use client";

import { EmptyState, Skeleton } from "@tanvir-platform/ui";
import { FileWarning } from "lucide-react";
import { useParams } from "next/navigation";

import { ServiceEditor } from "@/components/dashboard/services/ServiceEditor";
import { useService } from "@/lib/hooks/useServices";

export default function EditServicePage() {
  const params = useParams<{ id: string }>();
  const { data: service, isLoading, isError } = useService(params.id);

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (isError || !service) {
    return (
      <EmptyState
        icon={<FileWarning size={28} />}
        title="Service not found"
        description="This service may have been deleted or the link is incorrect."
      />
    );
  }

  return <ServiceEditor service={service} />;
}
