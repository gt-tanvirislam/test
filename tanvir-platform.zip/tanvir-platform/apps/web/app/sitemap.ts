import type { MetadataRoute } from "next";

import { getPublicBlogPosts, getPublicPortfolioItems, getPublicServices } from "@/lib/api/public";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

/**
 * Live-generated sitemap (Phase 2.7 §10). Sprint 7 extends Sprint 0's
 * static-only version with real blog/portfolio entries, reusing the same
 * public API functions the index pages themselves call (Sprint 7) — no
 * separate sitemap-specific data-fetching logic.
 *
 * Fails soft: if the backend is unreachable at build/request time, the
 * static routes still generate rather than the whole sitemap erroring —
 * a broken backend shouldn't take down search-engine discoverability of
 * the pages that don't need it.
 */
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticRoutes: MetadataRoute.Sitemap = [
    "",
    "/about",
    "/services",
    "/portfolio",
    "/blog",
    "/contact",
  ].map((path) => ({
    url: `${SITE_URL}${path}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: path === "" ? 1 : 0.7,
  }));

  let dynamicRoutes: MetadataRoute.Sitemap = [];
  try {
    const [posts, portfolioItems, services] = await Promise.all([
      getPublicBlogPosts({ per_page: 100 }),
      getPublicPortfolioItems({ per_page: 100 }),
      getPublicServices({ per_page: 100 }),
    ]);

    dynamicRoutes = [
      ...posts.data.map((post) => ({
        url: `${SITE_URL}/blog/${post.slug}`,
        lastModified: new Date(post.updated_at),
        changeFrequency: "monthly" as const,
        priority: 0.6,
      })),
      ...portfolioItems.data.map((item) => ({
        url: `${SITE_URL}/portfolio/${item.slug}`,
        lastModified: new Date(item.updated_at),
        changeFrequency: "monthly" as const,
        priority: 0.6,
      })),
      ...services.data.map((service) => ({
        url: `${SITE_URL}/services/${service.slug}`,
        lastModified: new Date(),
        changeFrequency: "monthly" as const,
        priority: 0.7, // services are higher-intent pages than blog posts
      })),
    ];
  } catch {
    // Backend unreachable — static routes above still return correctly.
  }

  return [...staticRoutes, ...dynamicRoutes];
}
