import type { Metadata } from "next";

import {
  AboutIntro,
  CTASection,
  Hero,
  LatestBlogPosts,
  PortfolioShowcase,
  ProcessSteps,
  ServicesPreview,
  WhyChooseUs,
} from "@/components/sections";
import { getFeaturedPortfolioItems, getFeaturedServices, getLatestBlogPosts } from "@/lib/api/public";
import { getHomepageContent } from "@/lib/config/site";
import { buildMetadata } from "@/lib/seo/buildMetadata";

export const metadata: Metadata = buildMetadata({
  title: "Tamvir Islam",
  description:
    "Professional video editing, graphic design, motion graphics, and photo editing — built to an international standard.",
  path: "/",
});

/**
 * Homepage (Sprint 9). Replaces every scaffold placeholder since Sprint
 * 0. A Server Component — all three content sections' data is fetched
 * here, server-to-server, in parallel (Promise.all, avoiding a client-
 * side waterfall per this sprint's performance requirement) and passed
 * down as props to purely presentational section components.
 *
 * Section order follows Phase 2.6 §2's homepage sequence, trimmed to
 * what's actually built: Hero → Services → Portfolio → About →
 * Process → Why Choose Us → Blog → Final CTA. (Testimonials and Client
 * Logos are omitted — Phase 2.6 §2 lists them, but no real testimonial
 * data exists yet and the Content Quality Policy forbids fabricating
 * any; adding that section is a future sprint once real testimonials
 * exist to show.)
 */
export default async function HomePage() {
  const [homepageContent, services, portfolioItems, blogPosts] = await Promise.all([
    getHomepageContent(),
    getFeaturedServices(6),
    getFeaturedPortfolioItems(6),
    getLatestBlogPosts(3),
  ]);

  return (
    <>
      <Hero content={homepageContent.hero} />
      <ServicesPreview services={services} />
      <PortfolioShowcase items={portfolioItems} />
      <AboutIntro content={homepageContent.aboutIntro} />
      <ProcessSteps content={homepageContent.process} />
      <WhyChooseUs content={homepageContent.whyChooseUs} />
      <LatestBlogPosts posts={blogPosts} />
      <CTASection
        headline={homepageContent.finalCta.headline}
        subheadline={homepageContent.finalCta.subheadline}
        ctaLabel={homepageContent.finalCta.ctaLabel}
        ctaHref={homepageContent.finalCta.ctaHref}
      />
    </>
  );
}
