import { Footer } from "@/components/layout/Footer";
import { NavBar } from "@/components/layout/NavBar";
import { getSiteConfig } from "@/lib/config/site";

/**
 * Public layout (Sprint 5, completed Sprint 7). Now reads structural
 * content from `getSiteConfig()` instead of inline literals — the
 * two-line-change-per-page comment from Sprint 5 is resolved: adding a
 * page now means adding it to site.ts's config, not editing this file
 * or NavBar/Footer themselves.
 *
 * `getSiteConfig()` is awaited directly since this is a Server Component
 * (Phase 2.7 §6) — no client-side loading state needed for structural
 * chrome that's the same for every visitor.
 */
export default async function PublicLayout({ children }: { children: React.ReactNode }) {
  const config = await getSiteConfig();

  return (
    <div className="flex min-h-screen flex-col">
      <NavBar siteName={config.siteName} items={config.navItems} />
      <main id="main-content" className="flex flex-1 flex-col">
        {children}
      </main>
      <Footer
        siteName={config.siteName}
        columns={config.footerColumns}
        socialLinks={config.socialLinks}
        contactEmail={config.contactEmail}
      />
    </div>
  );
}
