import type { Metadata } from "next";
import Link from "next/link";

import { Container } from "@/components/layout/Container";
import { getPublicBlogPosts } from "@/lib/api/public";
import { buildMetadata } from "@/lib/seo/buildMetadata";

export const metadata: Metadata = buildMetadata({ title: "Blog", path: "/blog" });

/**
 * Blog index (Sprint 7). Deliberately minimal — a real title/date list,
 * not the full Phase 2.6 §6.1 designed page (featured articles, category
 * filters, pagination UI). This exists to prove the public API +
 * layout + SEO plumbing works end to end with real published data, which
 * a pure route scaffold (like About/Services this sprint) couldn't
 * demonstrate. The full editorial design is explicitly a future sprint.
 */
export default async function BlogIndexPage() {
  const { data: posts } = await getPublicBlogPosts({ per_page: 10 });

  return (
    <Container className="py-16">
      <p className="text-label uppercase tracking-wide text-neutral-400">Public Foundation</p>
      <h1 className="mt-3 text-h2 text-neutral-800 dark:text-text-dark-primary">Blog</h1>
      <p className="mt-3 max-w-xl text-body text-neutral-500 dark:text-text-dark-secondary">
        The full editorial design (featured articles, categories, reading progress) is a future
        sprint. This list is real published data, proving the public API integration works.
      </p>

      {posts.length === 0 ? (
        <p className="mt-8 text-body-sm text-neutral-400">No posts published yet.</p>
      ) : (
        <ul className="mt-8 flex flex-col gap-4">
          {posts.map((post) => (
            <li key={post.id} className="border-b border-neutral-200 pb-4 dark:border-surface-dark-border">
              <Link
                href={`/blog/${post.slug}`}
                className="text-h4 text-neutral-800 hover:text-accent-500 dark:text-text-dark-primary"
              >
                {post.title}
              </Link>
              {post.published_at && (
                <p className="mt-1 text-caption text-neutral-400">
                  {new Date(post.published_at).toLocaleDateString()}
                </p>
              )}
            </li>
          ))}
        </ul>
      )}
    </Container>
  );
}
