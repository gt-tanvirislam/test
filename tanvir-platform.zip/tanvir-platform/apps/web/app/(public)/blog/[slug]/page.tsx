import type { Metadata } from "next";
import { notFound } from "next/navigation";

import { Container } from "@/components/layout/Container";
import { getPublicBlogPostBySlug } from "@/lib/api/public";
import { buildMetadata } from "@/lib/seo/buildMetadata";

interface Props {
  params: { slug: string };
}

/**
 * Blog post detail (Sprint 7). Minimal — title + excerpt + raw body, not
 * the full Phase 2.6 §6.2 designed article (TOC, reading progress,
 * author box, related posts, comments). Proves three real pieces of
 * infrastructure work together: slug-based dynamic metadata (using the
 * post's own SEO override when present, matching `buildMetadata()`'s
 * fallback-chain design from Phase 2.7 §10), `notFound()` for missing/
 * unpublished slugs, and the public API's SEO-enriched response
 * (Sprint 5 §4's "SEO-ready responses" requirement) actually being used
 * by a real page rather than just existing on paper.
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const post = await getPublicBlogPostBySlug(params.slug);
  if (!post) return buildMetadata({ title: "Post not found", path: `/blog/${params.slug}`, noindex: true });

  return buildMetadata({
    title: post.seo?.meta_title || post.title,
    description: post.seo?.meta_description || post.excerpt || undefined,
    path: `/blog/${post.slug}`,
    noindex: post.seo?.noindex,
  });
}

export default async function BlogPostPage({ params }: Props) {
  const post = await getPublicBlogPostBySlug(params.slug);
  if (!post) notFound();

  return (
    <Container as="article" className="max-w-2xl py-16">
      <p className="text-label uppercase tracking-wide text-neutral-400">
        {post.published_at && new Date(post.published_at).toLocaleDateString()}
      </p>
      <h1 className="mt-3 text-h1 text-neutral-800 dark:text-text-dark-primary">{post.title}</h1>
      {post.excerpt && (
        <p className="mt-4 text-subtitle text-neutral-500 dark:text-text-dark-secondary">{post.excerpt}</p>
      )}
      <div className="mt-8 whitespace-pre-wrap text-body text-neutral-700 dark:text-text-dark-secondary">
        {post.body_mdx}
      </div>
      <p className="mt-12 text-caption text-neutral-400">
        Full editorial layout (table of contents, related posts, comments) is a future sprint.
      </p>
    </Container>
  );
}
