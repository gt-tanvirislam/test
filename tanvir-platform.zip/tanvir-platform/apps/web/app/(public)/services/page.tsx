import type { Metadata } from "next";
import Link from "next/link";

import { Container } from "@/components/layout/Container";
import { getPublicServices } from "@/lib/api/public";
import { buildMetadata } from "@/lib/seo/buildMetadata";

export const metadata: Metadata = buildMetadata({ title: "Services", path: "/services" });

/**
 * Services index (Sprint 8 — upgrades Sprint 7's pure scaffold now that
 * the Services backend exists, matching Blog/Portfolio's minimal-real-
 * integration pattern). Full designed page (pricing cards, feature
 * comparisons) is still a future sprint.
 */
export default async function ServicesIndexPage() {
  const { data: services } = await getPublicServices({ per_page: 20 });

  return (
    <Container className="py-16">
      <p className="text-label uppercase tracking-wide text-neutral-400">Public Foundation</p>
      <h1 className="mt-3 text-h2 text-neutral-800 dark:text-text-dark-primary">Services</h1>
      <p className="mt-3 max-w-xl text-body text-neutral-500 dark:text-text-dark-secondary">
        The full designed page (pricing, features, process) is a future sprint. This list is real
        published data, proving the public API integration works.
      </p>

      {services.length === 0 ? (
        <p className="mt-8 text-body-sm text-neutral-400">No services published yet.</p>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
          {services.map((service) => (
            <Link
              key={service.id}
              href={`/services/${service.slug}`}
              className="rounded-md border border-neutral-200 p-4 hover:border-accent-500 dark:border-surface-dark-border"
            >
              <p className="text-card-title text-neutral-800 dark:text-text-dark-primary">{service.title}</p>
              {service.short_description && (
                <p className="mt-1 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
                  {service.short_description}
                </p>
              )}
            </Link>
          ))}
        </div>
      )}
    </Container>
  );
}
