import type { Metadata } from "next";
import { notFound } from "next/navigation";

import { Container } from "@/components/layout/Container";
import { getPublicServiceBySlug } from "@/lib/api/public";
import { buildMetadata } from "@/lib/seo/buildMetadata";

interface Props {
  params: { slug: string };
}

/** Mirrors Blog/Portfolio's detail-route pattern (Sprint 7/8) — same
 * three pieces proven: dynamic SEO metadata, notFound() handling,
 * SEO-enriched public API response actually consumed. */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const service = await getPublicServiceBySlug(params.slug);
  if (!service)
    return buildMetadata({ title: "Service not found", path: `/services/${params.slug}`, noindex: true });

  const seo = service.seo as { meta_title?: string; meta_description?: string; noindex?: boolean } | null;
  return buildMetadata({
    title: seo?.meta_title || (service.title as string),
    description: seo?.meta_description || (service.short_description as string) || undefined,
    path: `/services/${service.slug}`,
    noindex: seo?.noindex,
  });
}

export default async function ServiceDetailPage({ params }: Props) {
  const service = await getPublicServiceBySlug(params.slug);
  if (!service) notFound();

  return (
    <Container as="article" className="max-w-2xl py-16">
      <h1 className="text-h1 text-neutral-800 dark:text-text-dark-primary">{service.title as string}</h1>
      {!!service.short_description && (
        <p className="mt-4 text-subtitle text-neutral-500 dark:text-text-dark-secondary">
          {service.short_description as string}
        </p>
      )}
      {!!service.full_description && (
        <div className="mt-8 whitespace-pre-wrap text-body text-neutral-700 dark:text-text-dark-secondary">
          {service.full_description as string}
        </div>
      )}
      <p className="mt-12 text-caption text-neutral-400">
        Full service layout (features, pricing, testimonials, FAQ) is a future sprint.
      </p>
    </Container>
  );
}
