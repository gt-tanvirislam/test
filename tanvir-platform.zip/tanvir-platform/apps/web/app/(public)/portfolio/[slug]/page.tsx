import type { Metadata } from "next";
import { notFound } from "next/navigation";

import { Container } from "@/components/layout/Container";
import { getPublicPortfolioItemBySlug } from "@/lib/api/public";
import { buildMetadata } from "@/lib/seo/buildMetadata";

interface Props {
  params: { slug: string };
}

/** Mirrors the Blog post detail's approach (Sprint 7) — same three
 * pieces proven: dynamic SEO metadata, notFound() handling, SEO-enriched
 * public API response actually consumed. */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const item = await getPublicPortfolioItemBySlug(params.slug);
  if (!item)
    return buildMetadata({ title: "Project not found", path: `/portfolio/${params.slug}`, noindex: true });

  return buildMetadata({
    title: item.seo?.meta_title || item.title,
    description: item.seo?.meta_description || item.short_description || undefined,
    path: `/portfolio/${item.slug}`,
    noindex: item.seo?.noindex,
  });
}

export default async function PortfolioItemPage({ params }: Props) {
  const item = await getPublicPortfolioItemBySlug(params.slug);
  if (!item) notFound();

  return (
    <Container as="article" className="max-w-2xl py-16">
      {item.category && <p className="text-label uppercase tracking-wide text-neutral-400">{item.category.name}</p>}
      <h1 className="mt-3 text-h1 text-neutral-800 dark:text-text-dark-primary">{item.title}</h1>
      {item.short_description && (
        <p className="mt-4 text-subtitle text-neutral-500 dark:text-text-dark-secondary">
          {item.short_description}
        </p>
      )}
      {item.full_case_study && (
        <div className="mt-8 whitespace-pre-wrap text-body text-neutral-700 dark:text-text-dark-secondary">
          {item.full_case_study}
        </div>
      )}
      <p className="mt-12 text-caption text-neutral-400">
        Full project layout (gallery, before/after slider, related projects) is a future sprint.
      </p>
    </Container>
  );
}
