import type { Metadata } from "next";
import Link from "next/link";

import { Container } from "@/components/layout/Container";
import { getPublicPortfolioItems } from "@/lib/api/public";
import { buildMetadata } from "@/lib/seo/buildMetadata";

export const metadata: Metadata = buildMetadata({ title: "Portfolio", path: "/portfolio" });

/** Mirrors the Blog index's approach (Sprint 7) — real data, minimal
 * presentation, full Behance-inspired browsing UX (Phase 2.6 §5.1) is a
 * future sprint. */
export default async function PortfolioIndexPage() {
  const { data: items } = await getPublicPortfolioItems({ per_page: 12 });

  return (
    <Container className="py-16">
      <p className="text-label uppercase tracking-wide text-neutral-400">Public Foundation</p>
      <h1 className="mt-3 text-h2 text-neutral-800 dark:text-text-dark-primary">Portfolio</h1>
      <p className="mt-3 max-w-xl text-body text-neutral-500 dark:text-text-dark-secondary">
        The full filterable, Behance-inspired browsing experience is a future sprint. This grid is
        real published data, proving the public API integration works.
      </p>

      {items.length === 0 ? (
        <p className="mt-8 text-body-sm text-neutral-400">No projects published yet.</p>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
          {items.map((item) => (
            <Link
              key={item.id}
              href={`/portfolio/${item.slug}`}
              className="rounded-md border border-neutral-200 p-4 hover:border-accent-500 dark:border-surface-dark-border"
            >
              <p className="text-card-title text-neutral-800 dark:text-text-dark-primary">{item.title}</p>
              {item.category && <p className="mt-1 text-caption text-neutral-400">{item.category.name}</p>}
            </Link>
          ))}
        </div>
      )}
    </Container>
  );
}
