import type { Metadata } from "next";

import { PageScaffold } from "@/components/layout/PageScaffold";
import { buildMetadata } from "@/lib/seo/buildMetadata";

export const metadata: Metadata = buildMetadata({ title: "About", path: "/about" });

export default function AboutPage() {
  return (
    <PageScaffold
      label="About"
      note="The full About page (story, timeline, skills) is built in a dedicated future sprint. This route confirms the public layout, navigation, and SEO plumbing work end to end."
    />
  );
}
