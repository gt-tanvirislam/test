import type { Metadata } from "next";

import { PageScaffold } from "@/components/layout/PageScaffold";
import { buildMetadata } from "@/lib/seo/buildMetadata";

export const metadata: Metadata = buildMetadata({ title: "Contact", path: "/contact" });

export default function ContactPage() {
  return (
    <PageScaffold
      label="Contact"
      note="The contact form and inquiry workflow (Phase 2.6 §8) are built once the Contact backend module exists."
    />
  );
}
