import { revalidatePath } from "next/cache";
import { NextResponse } from "next/server";

/**
 * On-demand ISR revalidation endpoint (Phase 2.7 §6, Phase 2.8 §15's
 * `revalidate_frontend_route` job). Called internally by the backend's
 * publish workflow — never exposed to the public or the dashboard client
 * directly. Protected by a shared secret rather than user auth, since the
 * caller is a server, not a logged-in person.
 *
 * Business logic (which paths to revalidate for which entity types) is
 * added once content modules exist to trigger it — this sprint only
 * establishes the authenticated endpoint shape.
 */
export async function POST(request: Request) {
  const secret = request.headers.get("x-revalidation-secret");

  if (!secret || secret !== process.env.REVALIDATION_SECRET) {
    return NextResponse.json({ error: { code: "UNAUTHORIZED", message: "Invalid secret" } }, { status: 401 });
  }

  const body = (await request.json().catch(() => null)) as { path?: string } | null;

  if (!body?.path) {
    return NextResponse.json(
      { error: { code: "VALIDATION_ERROR", message: "path is required" } },
      { status: 422 }
    );
  }

  revalidatePath(body.path);
  return NextResponse.json({ data: { revalidated: true, path: body.path } });
}
