/**
 * Auth layout (Phase 2.7 §2/§3) — deliberately minimal, no nav/footer/
 * sidebar chrome, since login and password-reset screens should have zero
 * distraction from their single task.
 */
export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-neutral-50 px-6 dark:bg-surface-dark-base">
      <div className="w-full max-w-sm">{children}</div>
    </div>
  );
}
