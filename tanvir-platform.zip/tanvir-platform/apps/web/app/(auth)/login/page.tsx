import type { Metadata } from "next";

import { LoginForm } from "@/components/dashboard/LoginForm";
import { buildMetadata } from "@/lib/seo/buildMetadata";

/**
 * Admin login (Phase 3.1). `noindex` — this route has no reason to
 * appear in search results, and per this sprint's explicit rule, no page
 * on the public site links here either.
 */
export const metadata: Metadata = buildMetadata({
  title: "Sign in",
  path: "/login",
  noindex: true,
});

export default function LoginPage() {
  return (
    <div className="rounded-lg border border-neutral-200 bg-neutral-0 p-8 shadow-sm dark:border-surface-dark-border dark:bg-surface-dark-1">
      <h1 className="text-h4 text-neutral-800 dark:text-text-dark-primary">Sign in</h1>
      <p className="mt-1 mb-6 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
        Administrator access only.
      </p>
      <LoginForm />
    </div>
  );
}
