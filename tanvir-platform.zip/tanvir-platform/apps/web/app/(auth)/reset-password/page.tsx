/**
 * SCAFFOLD PLACEHOLDER — see app/(auth)/login/page.tsx for rationale.
 */
export default function ResetPasswordPlaceholder() {
  return (
    <div className="rounded-lg border border-neutral-200 bg-neutral-0 p-8 text-center shadow-sm dark:border-surface-dark-border dark:bg-surface-dark-1">
      <h1 className="text-h4 text-neutral-800 dark:text-text-dark-primary">Reset password</h1>
      <p className="mt-2 text-body-sm text-neutral-500 dark:text-text-dark-secondary">
        Implemented alongside the authentication backend module.
      </p>
    </div>
  );
}
