import type { Metadata } from "next";

import { AuthProvider } from "@/lib/auth/AuthProvider";
import { QueryProvider } from "@/lib/api/QueryProvider";
import { buildMetadata } from "@/lib/seo/buildMetadata";
import { bodyFont, displayFont } from "@/lib/theme/fonts";
import { themeInitScript } from "@/lib/theme/theme-init-script";
import { ThemeProvider } from "@/lib/theme/ThemeProvider";
import { ToastProvider } from "@tanvir-platform/ui";

import { SkipToContent } from "@/components/layout/SkipToContent";
import "../styles/globals.css";

export const metadata: Metadata = buildMetadata({ title: "Tamvir Islam" });

/**
 * Root layout (Phase 2.7 §3) — the absolute minimum shared across every
 * route: HTML shell, font variables, theme flash-prevention script, and
 * the three cross-cutting providers (Theme, Auth, React Query).
 *
 * Deliberately does NOT include navigation, footer, or any page content —
 * those belong to the (public) and (dashboard) route-group layouts,
 * created in the sprint that builds each area's real UI. This file must
 * stay fast and stable, since it loads on every single route.
 */
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${bodyFont.variable} ${displayFont.variable}`} suppressHydrationWarning>
      <head>
        {/* eslint-disable-next-line react/no-danger */}
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body>
        <SkipToContent />
        <ThemeProvider>
          <QueryProvider>
            <AuthProvider>
              <ToastProvider>{children}</ToastProvider>
            </AuthProvider>
          </QueryProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
