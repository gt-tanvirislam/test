import Link from "next/link";

/**
 * Global 404 (Phase 2.6 §9 — "treated as a recovery opportunity, not a
 * wall"). Full version (illustration, search bar, popular-content links)
 * lands once Search and content modules exist to populate the "popular
 * content" links meaningfully — this foundation establishes the correct
 * tone and the required recovery action (a way back) immediately.
 */
export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <p className="text-label uppercase tracking-wide text-neutral-400">404</p>
      <h1 className="mt-3 text-h2 text-neutral-800 dark:text-text-dark-primary">
        This page doesn&apos;t exist.
      </h1>
      <p className="mt-3 max-w-sm text-body text-neutral-500 dark:text-text-dark-secondary">
        The page you&apos;re looking for may have moved or never existed.
      </p>
      <Link
        href="/"
        className="mt-6 rounded-md bg-accent-500 px-5 py-3 text-button font-medium text-white hover:bg-accent-400"
      >
        Back to homepage
      </Link>
    </div>
  );
}
