import { act, renderHook } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { useSlugField } from "@/lib/hooks/useSlugField";

describe("useSlugField", () => {
  it("auto-generates the slug from the title initially", () => {
    const { result } = renderHook(({ title }) => useSlugField({ title }), {
      initialProps: { title: "My First Post" },
    });

    expect(result.current.slug).toBe("my-first-post");
    expect(result.current.isManuallyEdited).toBe(false);
  });

  it("keeps following title changes until manually edited", () => {
    const { result, rerender } = renderHook(({ title }) => useSlugField({ title }), {
      initialProps: { title: "Draft Title" },
    });

    rerender({ title: "Updated Title" });
    expect(result.current.slug).toBe("updated-title");
  });

  it("locks the slug after a manual edit, ignoring further title changes", () => {
    const { result, rerender } = renderHook(({ title }) => useSlugField({ title }), {
      initialProps: { title: "Draft Title" },
    });

    act(() => result.current.onManualChange("custom-url"));
    expect(result.current.slug).toBe("custom-url");
    expect(result.current.isManuallyEdited).toBe(true);

    rerender({ title: "A Totally Different Title" });
    expect(result.current.slug).toBe("custom-url");
  });

  it("resetToAutoGenerate re-syncs the slug with the current title", () => {
    const { result } = renderHook(({ title }) => useSlugField({ title }), {
      initialProps: { title: "Draft Title" },
    });

    act(() => result.current.onManualChange("custom-url"));
    act(() => result.current.resetToAutoGenerate());

    expect(result.current.slug).toBe("draft-title");
    expect(result.current.isManuallyEdited).toBe(false);
  });
});
