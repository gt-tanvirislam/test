import "@testing-library/jest-dom/vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

import { TagInput } from "@/components/features/content-editor/TagInput";

describe("TagInput", () => {
  it("adds a tag on Enter and clears the draft", () => {
    const handleChange = vi.fn();
    render(<TagInput label="Tags" value={[]} onChange={handleChange} />);

    const input = screen.getByLabelText("Tags");
    fireEvent.change(input, { target: { value: "Branding" } });
    fireEvent.keyDown(input, { key: "Enter" });

    expect(handleChange).toHaveBeenCalledWith(["Branding"]);
  });

  it("does not add a duplicate tag", () => {
    const handleChange = vi.fn();
    render(<TagInput label="Tags" value={["Branding"]} onChange={handleChange} />);

    const input = screen.getByLabelText("Tags");
    fireEvent.change(input, { target: { value: "Branding" } });
    fireEvent.keyDown(input, { key: "Enter" });

    expect(handleChange).not.toHaveBeenCalled();
  });

  it("removes a tag when its remove button is clicked", () => {
    const handleChange = vi.fn();
    render(<TagInput label="Tags" value={["Branding", "Logo"]} onChange={handleChange} />);

    fireEvent.click(screen.getByLabelText("Remove Branding"));

    expect(handleChange).toHaveBeenCalledWith(["Logo"]);
  });
});
