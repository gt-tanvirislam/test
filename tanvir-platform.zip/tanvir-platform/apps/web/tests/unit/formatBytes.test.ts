import { describe, expect, it } from "vitest";

import { formatBytes } from "@tanvir-platform/utils";

describe("formatBytes", () => {
  it("formats bytes under 1KB as-is", () => {
    expect(formatBytes(512)).toBe("512 B");
  });

  it("formats KB range with one decimal", () => {
    expect(formatBytes(2048)).toBe("2.0 KB");
  });

  it("formats MB range with one decimal", () => {
    expect(formatBytes(5 * 1024 * 1024)).toBe("5.0 MB");
  });
});
