import { describe, expect, it } from "vitest";

import { generateSlug } from "@tanvir-platform/utils";

describe("generateSlug", () => {
  it("lowercases and hyphenates a normal title", () => {
    expect(generateSlug("5 Lightroom Presets That Changed My Workflow")).toBe(
      "5-lightroom-presets-that-changed-my-workflow"
    );
  });

  it("strips special characters", () => {
    expect(generateSlug("Before & After: Retouching!")).toBe("before-after-retouching");
  });

  it("collapses repeated whitespace/hyphens", () => {
    expect(generateSlug("Too   many   spaces --- here")).toBe("too-many-spaces-here");
  });

  it("trims leading/trailing hyphens", () => {
    expect(generateSlug("  -Leading and trailing-  ")).toBe("leading-and-trailing");
  });
});
