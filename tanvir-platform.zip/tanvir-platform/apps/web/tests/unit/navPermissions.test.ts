import { describe, expect, it } from "vitest";

import { NAV_ITEMS, filterNavByPermissions } from "@/lib/constants/nav";

/**
 * RBAC nav filtering (frontend gating, task #12). The backend enforces
 * every endpoint independently — this only controls which links a user
 * sees. These tests pin the branching so an editor never sees admin-only
 * links and the always-on Dashboard item is never hidden.
 */
describe("filterNavByPermissions", () => {
  it("always keeps items with permission: null (e.g. Dashboard)", () => {
    const result = filterNavByPermissions(NAV_ITEMS, []);
    const labels = result.map((i) => i.label);
    expect(labels).toContain("Dashboard");
    // Nothing permission-gated survives an empty permission set.
    expect(labels).not.toContain("Users");
    expect(labels).not.toContain("Settings");
    expect(labels).not.toContain("Blog");
  });

  it("shows a screen only when its exact permission key is held", () => {
    const editor = ["content.view_drafts", "content.edit_any"];
    const labels = filterNavByPermissions(NAV_ITEMS, editor).map((i) => i.label);

    expect(labels).toContain("Blog"); // content.view_drafts
    expect(labels).toContain("SEO"); // content.edit_any
    expect(labels).toContain("Dashboard"); // always
    expect(labels).not.toContain("Users"); // needs users.manage
    expect(labels).not.toContain("Settings"); // needs settings.manage
    expect(labels).not.toContain("Media Library"); // needs media.manage
  });

  it("grants admin-only links when the matching keys are present", () => {
    const admin = ["users.manage", "settings.manage"];
    const labels = filterNavByPermissions(NAV_ITEMS, admin).map((i) => i.label);
    expect(labels).toContain("Users");
    expect(labels).toContain("Settings");
    expect(labels).toContain("Dashboard");
  });

  it("returns items whose permission is exactly matched, not prefix-matched", () => {
    // Holding "users" must NOT unlock "users.manage".
    const labels = filterNavByPermissions(NAV_ITEMS, ["users"]).map((i) => i.label);
    expect(labels).not.toContain("Users");
  });
});
