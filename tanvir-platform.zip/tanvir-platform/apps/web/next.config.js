/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  // Image optimization — remote patterns will be scoped to the Supabase
  // Storage project domain once provisioned. Kept broad-but-explicit here
  // (per Phase 2.7 §12) so swapping in a CDN later is a config-only change.
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "*.supabase.co",
        pathname: "/storage/v1/object/**",
      },
    ],
    formats: ["image/avif", "image/webp"],
  },

  // Security headers (Phase 2.10 §13) applied globally.
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=(self)",
          },
        ],
      },
    ];
  },

  // Transpile shared workspace packages so they can ship untranspiled TS.
  transpilePackages: [
    "@tanvir-platform/ui",
    "@tanvir-platform/types",
    "@tanvir-platform/utils",
  ],
};

module.exports = nextConfig;
