"""
Integration test for the Settings module (task #13).

Exercises the real `SiteSettingsService` against a SQLite database using the
same StaticPool + JSONB-shim harness as the scheduled-publishing test, so the
singleton semantics, partial-update behaviour, and durability are verified end
to end rather than mocked:

  * the singleton row is lazily created on first read and is stable across
    sessions (same id, only one row);
  * a partial PATCH updates only the provided fields and leaves the rest
    untouched, and the change survives into a fresh session (durability);
  * an explicit null clears a field, while an omitted field is preserved.
"""

import pytest
from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.pool import StaticPool

from app.modules.settings.models import SITE_SETTINGS_ID, SiteSettings
from app.modules.settings.repository import SiteSettingsRepository
from app.modules.settings.schemas import UpdateSiteSettingsIn
from app.modules.settings.service import SiteSettingsService


@compiles(JSONB, "sqlite")
def _compile_jsonb_as_json_on_sqlite(element, compiler, **kw):  # noqa: ANN001
    """Render Postgres JSONB as JSON for SQLite DDL (test-only)."""
    return "JSON"


@compiles(UUID, "sqlite")
def _compile_uuid_as_char_on_sqlite(element, compiler, **kw):  # noqa: ANN001
    """Render Postgres UUID as CHAR(32) for SQLite DDL (test-only).

    Postgres has a native UUID type; SQLite does not. Without this, the
    ``postgresql.UUID`` column compiles to a bare ``UUID`` type name, which
    SQLite maps to NUMERIC affinity. NUMERIC affinity then coerces the
    all-numeric sentinel id (``00000000-...-000000000001``) to the integer 1
    on write, and SQLAlchemy's UUID result processor blows up calling
    ``uuid.UUID(1)`` on read. CHAR(32) gives the column TEXT affinity, so the
    32-hex-char string is stored and read back verbatim. Test-only: production
    runs on Postgres with the native type.
    """
    return "CHAR(32)"


@pytest.fixture
async def engine():
    eng = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )
    async with eng.begin() as conn:
        await conn.run_sync(lambda sc: SiteSettings.__table__.create(sc, checkfirst=True))
    yield eng
    await eng.dispose()


def _sessionmaker(engine):
    return async_sessionmaker(engine, expire_on_commit=False)


async def _service_call(engine, fn):
    """Run `fn(service)` in its own committed session (mirrors the per-request
    unit-of-work: the service flushes, the boundary commits)."""
    Session = _sessionmaker(engine)
    async with Session() as session:
        service = SiteSettingsService(SiteSettingsRepository(session))
        result = await fn(service)
        await session.commit()
        return result


async def _row_count(engine) -> int:
    Session = _sessionmaker(engine)
    async with Session() as session:
        return await session.scalar(select(func.count()).select_from(SiteSettings))


@pytest.mark.asyncio
async def test_singleton_is_lazily_created_and_stable(engine):
    # Nothing seeded (the migration isn't run in this SQLite harness).
    assert await _row_count(engine) == 0

    first = await _service_call(engine, lambda s: s.get())
    assert first.id == SITE_SETTINGS_ID
    assert first.site_name == "Tamvir Islam"
    assert first.social_links == []
    assert await _row_count(engine) == 1

    # A second get() must reuse the same row, never create a second.
    await _service_call(engine, lambda s: s.get())
    assert await _row_count(engine) == 1


@pytest.mark.asyncio
async def test_partial_update_persists_and_leaves_other_fields_untouched(engine):
    await _service_call(
        engine,
        lambda s: s.update(
            UpdateSiteSettingsIn(
                tagline="Creative work to an international standard",
                social_links=[{"platform": "instagram", "url": "https://instagram.com/x"}],
            )
        ),
    )

    # Fresh session → real round-trip to the DB (durability).
    Session = _sessionmaker(engine)
    async with Session() as session:
        row = await session.get(SiteSettings, SITE_SETTINGS_ID)
        assert row.tagline == "Creative work to an international standard"
        assert row.social_links == [{"platform": "instagram", "url": "https://instagram.com/x"}]
        assert row.site_name == "Tamvir Islam"  # untouched default preserved
        assert row.contact_email is None  # never set → still null

    assert await _row_count(engine) == 1  # update never creates a duplicate


@pytest.mark.asyncio
async def test_explicit_null_clears_field_but_omitted_field_is_preserved(engine):
    await _service_call(
        engine, lambda s: s.update(UpdateSiteSettingsIn(tagline="temp", contact_email="hi@example.com"))
    )

    # Send tagline=None explicitly (clears it); omit contact_email (preserved).
    await _service_call(engine, lambda s: s.update(UpdateSiteSettingsIn(tagline=None)))

    Session = _sessionmaker(engine)
    async with Session() as session:
        row = await session.get(SiteSettings, SITE_SETTINGS_ID)
        assert row.tagline is None  # explicit null cleared it
        assert row.contact_email == "hi@example.com"  # omitted → preserved
