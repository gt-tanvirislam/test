"""
Integration test for scheduled publishing (Sprint 10 BUG-2).

Proves the whole fix end-to-end against a real database and the REAL
`BlogService.publish` path — not mocks:

  * a scheduled post whose time has passed is actually published, and the
    change SURVIVES into a brand-new session (durability, same standard as
    the BUG-1 persistence test);
  * a due post that fails publish-time validation (its featured image is
    missing) does NOT abort the batch — a sibling due post still publishes,
    and the bad one stays 'scheduled' (per-item SAVEPOINT isolation);
  * running the sweep again is idempotent: the already-published post is not
    republished and gains no second revision.

Two SQLite realities are bridged so the test exercises production semantics
faithfully:

  1. A `StaticPool` keeps one shared in-memory connection so writes committed
     in one session are visible to the next (and so `SAVEPOINT` works, which
     it does natively here — on Postgres, production, savepoints are native
     too).
  2. `blog_post_revisions.snapshot` is a Postgres `JSONB` column; a local
     `@compiles` shim renders it as `JSON` for SQLite DDL. Behaviour under
     test (isolation, idempotency, durability) is dialect-independent.
"""

import uuid
from datetime import datetime, timezone

import pytest
from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.pool import StaticPool

from app.modules.blog.models import (
    BlogCategory,
    BlogPost,
    BlogPostRevision,
    blog_post_tags,
)
from app.modules.blog.repository import BlogCategoryRepository, BlogPostRepository
from app.modules.blog.service import BlogService
from app.modules.scheduler.service import ContentPublisher, PublishScheduledService
from app.modules.taxonomy.models import Tag
from app.modules.taxonomy.repository import TagRepository

# Register the `users` table in Base.metadata so the author_id / created_by
# FKs on blog_posts and blog_post_revisions render at CREATE time. The table
# itself is never created (SQLite doesn't enforce FKs), so no user rows or
# dependent tables are needed.
import app.modules.users.models  # noqa: E402,F401

PAST = datetime(2020, 1, 1, tzinfo=timezone.utc)
NOW = datetime(2026, 1, 1, tzinfo=timezone.utc)


@compiles(JSONB, "sqlite")
def _compile_jsonb_as_json_on_sqlite(element, compiler, **kw):  # noqa: ANN001
    """Render Postgres JSONB as JSON for SQLite DDL (test-only)."""
    return "JSON"


_BLOG_TABLES = [
    BlogCategory.__table__,
    Tag.__table__,
    BlogPost.__table__,
    BlogPostRevision.__table__,
    blog_post_tags,
]


@pytest.fixture
async def engine():
    # StaticPool → a single shared in-memory connection, so data committed in
    # one session is visible from the next and SAVEPOINT works natively.
    eng = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )

    async with eng.begin() as conn:
        for table in _BLOG_TABLES:
            await conn.run_sync(lambda sc, t=table: t.create(sc, checkfirst=True))

    yield eng
    await eng.dispose()


def _sessionmaker(engine):
    return async_sessionmaker(engine, expire_on_commit=False)


def _blog_publisher(session) -> ContentPublisher:
    return ContentPublisher(
        "blog",
        BlogPost,
        BlogService(
            BlogPostRepository(session),
            BlogCategoryRepository(session),
            TagRepository(session),
        ),
    )


def _scheduled_post(*, featured_image_id, excerpt, scheduled_at=PAST) -> BlogPost:
    return BlogPost(
        id=uuid.uuid4(),
        author_id=uuid.uuid4(),
        title="Scheduled Post",
        slug=f"scheduled-{uuid.uuid4()}",
        excerpt=excerpt,
        body_mdx="body",
        featured_image_id=featured_image_id,
        status="scheduled",
        scheduled_at=scheduled_at,
    )


async def _run_sweep(engine, now=NOW):
    Session = _sessionmaker(engine)
    async with Session() as session:
        service = PublishScheduledService(session, [_blog_publisher(session)])
        result = await service.run(now=now)
        await session.commit()
        return result


async def _row(engine, post_id):
    """Read a post's lifecycle columns from a FRESH session (empty identity
    map ⇒ a real round-trip to the DB) — durability proof. Returns
    (status, scheduled_at, published_at)."""
    Session = _sessionmaker(engine)
    async with Session() as session:
        post = await session.get(BlogPost, post_id)
        assert post is not None, f"post {post_id} vanished from the database"
        return post.status, post.scheduled_at, post.published_at


async def _revision_count(engine, post_id) -> int:
    Session = _sessionmaker(engine)
    async with Session() as session:
        return await session.scalar(
            select(func.count())
            .select_from(BlogPostRevision)
            .where(BlogPostRevision.blog_post_id == post_id)
        )


@pytest.mark.asyncio
async def test_due_post_is_published_and_survives_a_new_session(engine):
    valid = _scheduled_post(featured_image_id=uuid.uuid4(), excerpt="ready")
    Session = _sessionmaker(engine)
    async with Session() as session:
        session.add(valid)
        await session.commit()

    result = await _run_sweep(engine)

    assert result.published_count == 1
    assert result.failed_count == 0

    status, scheduled_at, published_at = await _row(engine, valid.id)
    assert status == "published"
    assert published_at is not None
    assert scheduled_at is None  # cleared on publish
    assert await _revision_count(engine, valid.id) == 1  # publish snapshots a revision


@pytest.mark.asyncio
async def test_one_failing_item_does_not_block_a_sibling(engine):
    """The savepoint guarantee: the invalid post (no featured image) fails
    publish-time validation, but the valid post is still published, and the
    invalid one is left scheduled — not half-mutated."""
    valid = _scheduled_post(featured_image_id=uuid.uuid4(), excerpt="ready")
    invalid = _scheduled_post(featured_image_id=None, excerpt="ready")  # fails validation
    Session = _sessionmaker(engine)
    async with Session() as session:
        session.add_all([valid, invalid])
        await session.commit()

    result = await _run_sweep(engine)

    assert result.published_count == 1
    assert result.failed_count == 1
    assert result.failed[0].module == "blog"
    assert result.failed[0].id == invalid.id
    assert "ValidationError" in result.failed[0].error

    valid_status, _, valid_published_at = await _row(engine, valid.id)
    assert valid_status == "published"
    assert valid_published_at is not None

    invalid_status, invalid_scheduled_at, invalid_published_at = await _row(engine, invalid.id)
    assert invalid_status == "scheduled"  # untouched — savepoint rolled it back
    assert invalid_scheduled_at is not None
    assert invalid_published_at is None
    assert await _revision_count(engine, invalid.id) == 0


@pytest.mark.asyncio
async def test_sweep_is_idempotent(engine):
    valid = _scheduled_post(featured_image_id=uuid.uuid4(), excerpt="ready")
    Session = _sessionmaker(engine)
    async with Session() as session:
        session.add(valid)
        await session.commit()

    first = await _run_sweep(engine)
    _, _, published_at_after_first = await _row(engine, valid.id)
    revisions_after_first = await _revision_count(engine, valid.id)

    second = await _run_sweep(engine)
    _, _, published_at_after_second = await _row(engine, valid.id)
    revisions_after_second = await _revision_count(engine, valid.id)

    assert first.published_count == 1
    assert second.published_count == 0  # nothing scheduled remains → no-op
    assert published_at_after_second == published_at_after_first  # not republished
    assert revisions_after_second == revisions_after_first == 1  # no duplicate revision


@pytest.mark.asyncio
async def test_future_scheduled_post_is_left_alone(engine):
    future = _scheduled_post(
        featured_image_id=uuid.uuid4(),
        excerpt="ready",
        scheduled_at=datetime(2099, 1, 1, tzinfo=timezone.utc),
    )
    Session = _sessionmaker(engine)
    async with Session() as session:
        session.add(future)
        await session.commit()

    result = await _run_sweep(engine, now=NOW)

    assert result.published_count == 0
    status, _, _ = await _row(engine, future.id)
    assert status == "scheduled"
