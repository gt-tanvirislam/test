"""
Regression tests for BUG-3 — media `file_hash` uniqueness / upload lifecycle.

Before the Sprint 10 fix, `media_assets.file_hash` was NOT NULL with a
table-wide UNIQUE, and pending uploads were written with file_hash="". That
made the SECOND concurrent pending upload collide on "" (IntegrityError), and
it also meant re-uploading content identical to a *soft-deleted* asset failed
at the DB even though the app-level dedup query (which filters
`deleted_at IS NULL`) would have allowed it.

The fix: pending rows carry NULL, and the table-wide UNIQUE is replaced by a
PARTIAL unique index `WHERE file_hash IS NOT NULL AND deleted_at IS NULL`.

These tests build a real SQLite database from the actual MediaAsset model
metadata. SQLite (like Postgres) supports partial indexes and treats NULLs as
distinct under a unique index, so the exact behaviour the production partial
index guarantees is exercised here for real — not asserted by string-matching
DDL. The one Postgres-specific detail (the `postgresql_where` clause) is
verified separately by compiling the model's DDL for the Postgres dialect.
"""

import uuid

import pytest
from sqlalchemy import Index, text
from sqlalchemy.dialects import postgresql
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.schema import CreateIndex

from app.modules.media.models import MediaAsset


def _insert_values(**overrides):
    """Minimal valid MediaAsset column values; override per test."""
    values = {
        "id": uuid.uuid4(),
        "folder_id": None,
        "storage_path": f"images/{uuid.uuid4()}.jpg",
        "file_name": "photo.jpg",
        "mime_type": "image/jpeg",
        "file_size_bytes": 0,
        "file_hash": None,
        "alt_text": None,
        "width": None,
        "height": None,
        "duration_seconds": None,
        "deleted_at": None,
    }
    values.update(overrides)
    return values


@pytest.fixture
async def media_engine():
    """A real SQLite engine with just the media_assets table created from the
    live model metadata, so the model's own column nullability and unique
    index are what get exercised.

    SQLAlchemy renders the model's `postgresql_where` partial index as a
    plain (non-partial) unique index on non-Postgres dialects, so we drop the
    auto-created one and recreate an equivalent SQLite partial index to
    faithfully reproduce production semantics.
    """
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")

    async with engine.begin() as conn:
        await conn.run_sync(
            lambda sync_conn: MediaAsset.__table__.create(sync_conn, checkfirst=True)
        )
        # Replace the dialect-generic unique index with a real SQLite partial
        # index mirroring the production `postgresql_where`.
        await conn.execute(text("DROP INDEX IF EXISTS uq_media_assets_file_hash"))
        await conn.execute(
            text(
                "CREATE UNIQUE INDEX uq_media_assets_file_hash ON media_assets "
                "(file_hash) WHERE file_hash IS NOT NULL AND deleted_at IS NULL"
            )
        )

    yield engine
    await engine.dispose()


def _sessionmaker(engine):
    return async_sessionmaker(engine, expire_on_commit=False)


@pytest.mark.asyncio
async def test_many_pending_uploads_coexist_without_collision(media_engine):
    """The original crash: two pending uploads (file_hash=NULL) must both
    insert. NULLs are distinct under a unique index."""
    Session = _sessionmaker(media_engine)
    async with Session() as session:
        session.add(MediaAsset(**_insert_values(file_hash=None)))
        session.add(MediaAsset(**_insert_values(file_hash=None)))
        session.add(MediaAsset(**_insert_values(file_hash=None)))
        await session.commit()  # must not raise

    async with Session() as session:
        count = (
            await session.execute(text("SELECT COUNT(*) FROM media_assets"))
        ).scalar_one()
    assert count == 3


@pytest.mark.asyncio
async def test_two_confirmed_distinct_hashes_both_persist(media_engine):
    """Distinct confirmed content is not deduplicated — both survive."""
    Session = _sessionmaker(media_engine)
    async with Session() as session:
        session.add(MediaAsset(**_insert_values(file_hash="hash-aaa")))
        session.add(MediaAsset(**_insert_values(file_hash="hash-bbb")))
        await session.commit()

    async with Session() as session:
        count = (
            await session.execute(text("SELECT COUNT(*) FROM media_assets"))
        ).scalar_one()
    assert count == 2


@pytest.mark.asyncio
async def test_duplicate_live_confirmed_hash_is_rejected(media_engine):
    """Two LIVE confirmed assets with the same hash violate the partial
    unique index — this is the dedup guarantee, still enforced."""
    Session = _sessionmaker(media_engine)
    async with Session() as session:
        session.add(MediaAsset(**_insert_values(file_hash="same-hash")))
        await session.commit()

    with pytest.raises(IntegrityError):
        async with Session() as session:
            session.add(MediaAsset(**_insert_values(file_hash="same-hash")))
            await session.commit()


@pytest.mark.asyncio
async def test_reupload_identical_to_soft_deleted_asset_is_allowed(media_engine):
    """The latent bug: an asset with hash H is soft-deleted; re-uploading
    identical content (hash H again) must succeed, because the partial index
    excludes `deleted_at IS NOT NULL`. The old table-wide UNIQUE blocked it."""
    from datetime import datetime, timezone

    Session = _sessionmaker(media_engine)
    async with Session() as session:
        session.add(
            MediaAsset(
                **_insert_values(
                    file_hash="recycled-hash",
                    deleted_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
                )
            )
        )
        await session.commit()

    # A fresh live asset with the SAME hash must be accepted.
    async with Session() as session:
        session.add(MediaAsset(**_insert_values(file_hash="recycled-hash")))
        await session.commit()  # must not raise

    async with Session() as session:
        live = (
            await session.execute(
                text(
                    "SELECT COUNT(*) FROM media_assets "
                    "WHERE file_hash = 'recycled-hash' AND deleted_at IS NULL"
                )
            )
        ).scalar_one()
    assert live == 1


def test_model_emits_postgres_partial_unique_index() -> None:
    """The production DDL (Postgres) must carry the partial WHERE clause —
    this is what the SQLite tests above stand in for at runtime."""
    (index,) = [ix for ix in MediaAsset.__table__.indexes]
    assert index.unique is True
    ddl = str(CreateIndex(index).compile(dialect=postgresql.dialect()))
    normalized = " ".join(ddl.split())
    assert "CREATE UNIQUE INDEX uq_media_assets_file_hash" in normalized
    assert "WHERE file_hash IS NOT NULL AND deleted_at IS NULL" in normalized
