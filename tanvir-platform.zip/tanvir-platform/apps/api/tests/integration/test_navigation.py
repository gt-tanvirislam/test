"""
Integration test for the Navigation module (task #14).

Exercises the real `NavigationService` against SQLite using the same
StaticPool + type-shim harness as the settings/scheduler tests. Foreign-key
enforcement is switched ON for this connection (SQLite leaves it off by
default) so the parent-before-child insert ordering in `replace()` is
genuinely exercised, not silently tolerated:

  * an empty tree reads back as empty header/footer;
  * a full replace persists header links and footer columns-with-links, in
    order, and survives into a fresh session (durability);
  * a second replace fully supersedes the first (no leftover rows), proving
    the delete-all-then-rebuild is atomic from the caller's perspective;
  * footer column headers carry no url; their child links do.
"""

import pytest
from sqlalchemy import event, func, select
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.pool import StaticPool

from app.modules.navigation.models import NavigationItem
from app.modules.navigation.repository import NavigationRepository
from app.modules.navigation.schemas import (
    FooterColumnIn,
    FooterLinkIn,
    HeaderItemIn,
    ReplaceNavigationIn,
)
from app.modules.navigation.service import NavigationService


@compiles(UUID, "sqlite")
def _compile_uuid_as_char_on_sqlite(element, compiler, **kw):  # noqa: ANN001
    """Render Postgres UUID as CHAR(32) for SQLite DDL (test-only) so UUID
    values keep TEXT affinity instead of being coerced to integers."""
    return "CHAR(32)"


@pytest.fixture
async def engine():
    eng = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )

    # SQLite disables FK enforcement per-connection by default; turn it on so
    # the self-referential parent_id FK is actually checked, mirroring
    # Postgres. StaticPool reuses one connection, so this fires once for it.
    @event.listens_for(eng.sync_engine, "connect")
    def _fk_on(dbapi_conn, _record):  # noqa: ANN001
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    async with eng.begin() as conn:
        await conn.run_sync(lambda sc: NavigationItem.__table__.create(sc, checkfirst=True))
    yield eng
    await eng.dispose()


def _sessionmaker(engine):
    return async_sessionmaker(engine, expire_on_commit=False)


async def _service_call(engine, fn):
    Session = _sessionmaker(engine)
    async with Session() as session:
        service = NavigationService(NavigationRepository(session))
        result = await fn(service)
        await session.commit()
        return result


async def _row_count(engine) -> int:
    Session = _sessionmaker(engine)
    async with Session() as session:
        return await session.scalar(select(func.count()).select_from(NavigationItem))


def _sample_tree() -> ReplaceNavigationIn:
    return ReplaceNavigationIn(
        header=[
            HeaderItemIn(label="Home", url="/"),
            HeaderItemIn(label="About", url="/about"),
        ],
        footer=[
            FooterColumnIn(
                title="Site",
                items=[
                    FooterLinkIn(label="About", url="/about"),
                    FooterLinkIn(label="Blog", url="/blog"),
                ],
            ),
            FooterColumnIn(title="Get in touch", items=[FooterLinkIn(label="Contact", url="/contact")]),
        ],
    )


@pytest.mark.asyncio
async def test_empty_navigation_reads_back_empty(engine):
    result = await _service_call(engine, lambda s: s.get())
    assert result.header == []
    assert result.footer == []
    assert await _row_count(engine) == 0


@pytest.mark.asyncio
async def test_replace_persists_tree_in_order_and_is_durable(engine):
    await _service_call(engine, lambda s: s.replace(_sample_tree()))

    # Fresh session → true round-trip through the DB.
    result = await _service_call(engine, lambda s: s.get())

    assert [h.label for h in result.header] == ["Home", "About"]
    assert [h.url for h in result.header] == ["/", "/about"]

    assert [c.title for c in result.footer] == ["Site", "Get in touch"]
    assert [i.label for i in result.footer[0].items] == ["About", "Blog"]
    assert [i.url for i in result.footer[1].items] == ["/contact"]

    # 2 header + 2 columns + (2 + 1) links = 7 rows.
    assert await _row_count(engine) == 7


@pytest.mark.asyncio
async def test_second_replace_fully_supersedes_the_first(engine):
    await _service_call(engine, lambda s: s.replace(_sample_tree()))
    await _service_call(
        engine,
        lambda s: s.replace(
            ReplaceNavigationIn(
                header=[HeaderItemIn(label="Work", url="/portfolio")],
                footer=[],
            )
        ),
    )

    result = await _service_call(engine, lambda s: s.get())
    assert [h.label for h in result.header] == ["Work"]
    assert result.footer == []
    assert await _row_count(engine) == 1  # no leftover rows from the first tree


@pytest.mark.asyncio
async def test_footer_column_headers_have_no_url_children_do(engine):
    await _service_call(engine, lambda s: s.replace(_sample_tree()))

    Session = _sessionmaker(engine)
    async with Session() as session:
        rows = (await session.execute(select(NavigationItem))).scalars().all()

    columns = [r for r in rows if r.location == "footer" and r.parent_id is None]
    links = [r for r in rows if r.location == "footer" and r.parent_id is not None]

    assert columns and all(c.url is None for c in columns)  # group titles, not links
    assert links and all(l.url is not None for l in links)  # real links
