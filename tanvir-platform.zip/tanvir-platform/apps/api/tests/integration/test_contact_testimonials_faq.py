"""
Integration test for the Contact, Testimonials, and FAQ modules (tasks
#15/#19/#20).

Runs the real services against SQLite using the same StaticPool + UUID
type-shim harness as the settings/navigation tests. It deliberately targets
the two behaviours most likely to cause a production bug:

  * Contact rate limiting — the soft per-email cap must allow the first N
    submissions and then reject, and must persist every allowed lead;
  * the public/published filters for Testimonials and FAQ — an unpublished
    row must NEVER appear in a public list (a leak here would put draft or
    fake-looking content on the live site), and the featured filter must
    narrow correctly.

Status transitions and soft-delete get a light touch too, since they share
the request unit-of-work boundary the other modules rely on.
"""

from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.pool import StaticPool

from app.core.exceptions import RateLimitedError
from app.modules.contact.models import ContactInquiry
from app.modules.contact.repository import ContactInquiryRepository
from app.modules.contact.schemas import CreateInquiryIn
from app.modules.contact.service import ContactInquiryService
from app.modules.faq.models import FAQItem
from app.modules.faq.repository import FAQRepository
from app.modules.faq.schemas import CreateFAQItemIn, UpdateFAQItemIn
from app.modules.faq.service import FAQService
from app.modules.testimonials.models import Testimonial
from app.modules.testimonials.repository import TestimonialRepository
from app.modules.testimonials.schemas import CreateTestimonialIn
from app.modules.testimonials.service import TestimonialService


@compiles(UUID, "sqlite")
def _compile_uuid_as_char_on_sqlite(element, compiler, **kw):  # noqa: ANN001
    return "CHAR(32)"


@pytest.fixture
async def engine():
    eng = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )

    @event.listens_for(eng.sync_engine, "connect")
    def _fk_on(dbapi_conn, _record):  # noqa: ANN001
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    async with eng.begin() as conn:
        for model in (ContactInquiry, Testimonial, FAQItem):
            await conn.run_sync(lambda sc, m=model: m.__table__.create(sc, checkfirst=True))
    yield eng
    await eng.dispose()


def _sessionmaker(engine):
    return async_sessionmaker(engine, expire_on_commit=False)


async def _contact_call(engine, fn):
    Session = _sessionmaker(engine)
    async with Session() as session:
        service = ContactInquiryService(
            ContactInquiryRepository(session), notify_to="owner@example.com"
        )
        result = await fn(service)
        await session.commit()
        return result


async def _testimonial_call(engine, fn):
    Session = _sessionmaker(engine)
    async with Session() as session:
        service = TestimonialService(TestimonialRepository(session))
        result = await fn(service)
        await session.commit()
        return result


async def _faq_call(engine, fn):
    Session = _sessionmaker(engine)
    async with Session() as session:
        service = FAQService(FAQRepository(session))
        result = await fn(service)
        await session.commit()
        return result


# ── Contact ─────────────────────────────────────────────────────────────


def _inquiry(email="lead@example.com", message="I need a promo video edited."):
    return CreateInquiryIn(name="Jordan Lee", email=email, message=message)


async def test_submit_persists_and_notifies(engine):
    inquiry = await _contact_call(engine, lambda s: s.submit(_inquiry()))
    assert inquiry.id is not None
    assert inquiry.status == "new"

    # Durable across a fresh session, and listable.
    items, total = await _contact_call(
        engine, lambda s: s.list(page=1, per_page=20, status=None, search=None)
    )
    assert total == 1
    assert items[0].email == "lead@example.com"


async def test_rate_limit_allows_then_blocks(engine):
    # The service caps at 5 per email per rolling hour. Six in a row: the
    # sixth must be rejected, and only five may have persisted.
    async def submit_six(service):
        allowed = 0
        for _ in range(5):
            await service.submit(_inquiry(email="flood@example.com"))
            allowed += 1
        with pytest.raises(RateLimitedError):
            await service.submit(_inquiry(email="flood@example.com"))
        return allowed

    allowed = await _contact_call(engine, submit_six)
    assert allowed == 5

    _, total = await _contact_call(
        engine, lambda s: s.list(page=1, per_page=50, status=None, search=None)
    )
    assert total == 5

    # A different email is unaffected by the first address's flood.
    other = await _contact_call(engine, lambda s: s.submit(_inquiry(email="fresh@example.com")))
    assert other.status == "new"


async def test_rate_limit_window_is_bounded(engine):
    # Submissions older than the window must not count toward the cap. Seed 5
    # rows with a created_at just outside the hour window, then confirm a new
    # submission is still allowed.
    Session = _sessionmaker(engine)
    old = datetime.now(timezone.utc) - timedelta(hours=2)
    async with Session() as session:
        repo = ContactInquiryRepository(session)
        for _ in range(5):
            row = await repo.create(name="Old", email="aged@example.com", message="hi")
            row.created_at = old
        await session.commit()

    # Should NOT raise — the 5 aged rows are outside the rolling window.
    fresh = await _contact_call(engine, lambda s: s.submit(_inquiry(email="aged@example.com")))
    assert fresh.id is not None


async def test_status_transition_and_soft_delete(engine):
    inquiry = await _contact_call(engine, lambda s: s.submit(_inquiry()))
    iid = inquiry.id

    updated = await _contact_call(engine, lambda s: s.update_status(iid, "contacted"))
    assert updated.status == "contacted"

    await _contact_call(engine, lambda s: s.delete(iid))
    # Soft-deleted rows drop out of the list.
    _, total = await _contact_call(
        engine, lambda s: s.list(page=1, per_page=20, status=None, search=None)
    )
    assert total == 0


# ── Testimonials ──────────────────────────────────────────────────────────


async def test_public_testimonials_exclude_unpublished(engine):
    async def seed(service):
        await service.create(
            CreateTestimonialIn(quote="Great work", author_name="A", is_published=True)
        )
        await service.create(
            CreateTestimonialIn(
                quote="Also great", author_name="B", is_published=True, is_featured=True
            )
        )
        # Draft — must never surface publicly.
        await service.create(
            CreateTestimonialIn(quote="Draft", author_name="C", is_published=False)
        )

    await _testimonial_call(engine, seed)

    published = await _testimonial_call(engine, lambda s: s.list_published())
    assert {t.author_name for t in published} == {"A", "B"}

    featured = await _testimonial_call(engine, lambda s: s.list_published(featured_only=True))
    assert [t.author_name for t in featured] == ["B"]

    # Dashboard sees everything including the draft.
    all_rows = await _testimonial_call(engine, lambda s: s.list_all())
    assert len(all_rows) == 3


# ── FAQ ─────────────────────────────────────────────────────────────────


async def test_public_faq_excludes_unpublished_and_orders(engine):
    async def seed(service):
        await service.create(
            CreateFAQItemIn(question="Q2", answer="A2", is_published=True, sort_order=2)
        )
        await service.create(
            CreateFAQItemIn(question="Q1", answer="A1", is_published=True, sort_order=1)
        )
        await service.create(
            CreateFAQItemIn(question="Draft", answer="hidden", is_published=False, sort_order=0)
        )

    await _faq_call(engine, seed)

    published = await _faq_call(engine, lambda s: s.list_published())
    # Draft excluded; remaining ordered by sort_order ascending.
    assert [i.question for i in published] == ["Q1", "Q2"]


async def test_faq_partial_update(engine):
    created = await _faq_call(
        engine, lambda s: s.create(CreateFAQItemIn(question="Q", answer="A", is_published=False))
    )
    fid = created.id

    updated = await _faq_call(
        engine, lambda s: s.update(fid, UpdateFAQItemIn(is_published=True))
    )
    # Only is_published changed; question/answer untouched.
    assert updated.is_published is True
    assert updated.question == "Q"
    assert updated.answer == "A"
