"""
Integration test for the request-scoped transaction boundary
(Sprint 10 fix for BUG-1 — "successful writes are never committed").

This drives the *real* `app.db.session.get_db_session` dependency exactly
the way FastAPI drives it — resume-to-completion on success (which runs the
`else: commit`), and `.athrow()` on failure (which runs the
`except: rollback; raise`) — against a real on-disk SQLite database via the
async engine. Durability is then proven by opening a BRAND-NEW engine (a
separate connection pool) and reading the row back, so a pass means the data
survived the original session being committed and closed, not that it was
merely cached in the unit of work.

SQLite (aiosqlite) is used deliberately: the transaction/commit semantics
under test live in `get_db_session`, which is database-agnostic, so this
runs with no external Postgres while still exercising the real dependency
and a real driver round-trip.
"""

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

import app.db.session as session_module
from app.db.session import get_db_session

CREATE_TABLE = "CREATE TABLE IF NOT EXISTS widgets (id INTEGER PRIMARY KEY, name TEXT NOT NULL)"


async def _count(engine, name: str) -> int:
    """Open a query on the given engine and count rows named `name`."""
    async with engine.connect() as conn:
        result = await conn.execute(text("SELECT COUNT(*) FROM widgets WHERE name = :n"), {"n": name})
        return result.scalar_one()


@pytest.fixture
async def sqlite_db(tmp_path, monkeypatch):
    """A file-backed SQLite database with the app's sessionmaker patched to
    point at it, so `get_db_session()` uses this DB instead of Postgres."""
    db_path = f"{tmp_path.as_posix()}/persistence.db"
    url = f"sqlite+aiosqlite:///{db_path}"

    engine = create_async_engine(url)
    async with engine.begin() as conn:
        await conn.execute(text(CREATE_TABLE))

    sessionmaker = async_sessionmaker(engine, expire_on_commit=False)
    monkeypatch.setattr(session_module, "AsyncSessionLocal", sessionmaker)

    yield url

    await engine.dispose()


async def _fresh_engine(url):
    return create_async_engine(url)


@pytest.mark.asyncio
async def test_successful_request_commits_and_data_survives_a_new_session(sqlite_db):
    url = sqlite_db

    # Drive get_db_session the way FastAPI does on a SUCCESSFUL request:
    # advance to the yield, do the write, then resume to completion so the
    # `else: commit` branch runs.
    gen = get_db_session()
    session = await gen.__anext__()
    await session.execute(text("INSERT INTO widgets (name) VALUES ('alpha')"))
    with pytest.raises(StopAsyncIteration):
        await gen.__anext__()  # resumes past yield -> commit

    # Prove durability from a completely separate engine / connection pool.
    verify_engine = await _fresh_engine(url)
    try:
        assert await _count(verify_engine, "alpha") == 1
    finally:
        await verify_engine.dispose()


@pytest.mark.asyncio
async def test_failed_request_rolls_back_and_leaves_no_partial_write(sqlite_db):
    url = sqlite_db

    # Drive get_db_session the way FastAPI does when the route RAISES:
    # advance to the yield, do a write, then throw into the generator.
    gen = get_db_session()
    session = await gen.__anext__()
    await session.execute(text("INSERT INTO widgets (name) VALUES ('beta')"))

    with pytest.raises(ValueError):
        await gen.athrow(ValueError("route blew up after a write"))

    # The write must NOT have survived — no partial write on failure.
    verify_engine = await _fresh_engine(url)
    try:
        assert await _count(verify_engine, "beta") == 0
    finally:
        await verify_engine.dispose()


@pytest.mark.asyncio
async def test_commit_and_rollback_are_independent(sqlite_db):
    """A committed write and a later rolled-back write don't interfere:
    the committed row stays, the rolled-back one never appears."""
    url = sqlite_db

    gen = get_db_session()
    session = await gen.__anext__()
    await session.execute(text("INSERT INTO widgets (name) VALUES ('keep')"))
    with pytest.raises(StopAsyncIteration):
        await gen.__anext__()

    gen2 = get_db_session()
    session2 = await gen2.__anext__()
    await session2.execute(text("INSERT INTO widgets (name) VALUES ('discard')"))
    with pytest.raises(RuntimeError):
        await gen2.athrow(RuntimeError("boom"))

    verify_engine = await _fresh_engine(url)
    try:
        assert await _count(verify_engine, "keep") == 1
        assert await _count(verify_engine, "discard") == 0
    finally:
        await verify_engine.dispose()
