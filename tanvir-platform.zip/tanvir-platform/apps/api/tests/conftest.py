"""
Shared test configuration.

Sets the environment variables `app.core.config.Settings` requires BEFORE
any `app.*` module is imported, so the whole suite is importable without a
real `.env` (previously there was no conftest at all, which is a large part
of why no test exercised the DB write path — see
`tests/integration/test_db_transaction.py`). These are inert dummy values:
the Postgres URL is never actually connected to (unit tests use mocks; the
DB integration tests build their own SQLite engine and patch the
sessionmaker), and the JWT secret is not a real credential.
"""

import os

os.environ.setdefault("DATABASE_URL", "postgresql+asyncpg://test:test@localhost:5432/test")
os.environ.setdefault("SUPABASE_URL", "http://localhost")
os.environ.setdefault("SUPABASE_JWT_SECRET", "test-jwt-secret-not-a-real-credential")
os.environ.setdefault("SUPABASE_SERVICE_ROLE_KEY", "")
os.environ.setdefault("ENVIRONMENT", "test")
os.environ.setdefault("LOG_LEVEL", "warning")
os.environ.setdefault("CORS_ALLOWED_ORIGINS", "http://localhost:3000")
os.environ.setdefault("FRONTEND_URL", "http://localhost:3000")
