"""Unit tests for BlogService (Phase 2.9 §10). Uses fake repositories to
prove the service composes ContentLifecycleService/slug/tag utilities
correctly, without needing a real database."""

import uuid
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from app.core.exceptions import ValidationError
from app.modules.blog.service import BlogService, _estimate_reading_time
from app.shared.publishable import ContentStatus


def _make_service():
    post_repo = AsyncMock()
    post_repo.session = AsyncMock()
    category_repo = AsyncMock()
    tag_repo = AsyncMock()
    tag_repo.get_or_create_many.return_value = []
    service = BlogService(post_repo, category_repo, tag_repo)
    return service, post_repo, tag_repo


def test_estimate_reading_time_rounds_to_nearest_minute() -> None:
    body = " ".join(["word"] * 400)  # 400 words / 200wpm = 2 minutes
    assert _estimate_reading_time(body) == 2


def test_estimate_reading_time_minimum_one_minute() -> None:
    assert _estimate_reading_time("just a few words") == 1


@pytest.mark.asyncio
async def test_publish_requires_featured_image_and_excerpt() -> None:
    service, post_repo, _ = _make_service()
    post_id = uuid.uuid4()
    fake_post = SimpleNamespace(
        id=post_id,
        status=ContentStatus.DRAFT.value,
        scheduled_at=None,
        published_at=None,
        featured_image_id=None,
        excerpt=None,
        tags=[],
    )
    post_repo.get_by_id_full.return_value = fake_post

    with pytest.raises(ValidationError):
        await service.publish(post_id, uuid.uuid4())


@pytest.mark.asyncio
async def test_publish_creates_a_revision_snapshot() -> None:
    service, post_repo, _ = _make_service()
    post_id = uuid.uuid4()
    fake_post = SimpleNamespace(
        id=post_id,
        status=ContentStatus.DRAFT.value,
        scheduled_at=None,
        published_at=None,
        featured_image_id=uuid.uuid4(),
        excerpt="A valid excerpt",
        title="A post",
        slug="a-post",
        body_mdx="content",
        category_id=None,
        tags=[],
    )
    post_repo.get_by_id_full.return_value = fake_post

    result = await service.publish(post_id, uuid.uuid4())

    assert result.status == ContentStatus.PUBLISHED.value
    post_repo.session.add.assert_called_once()  # the revision snapshot
