"""Unit tests for BlogPostRepository's public-facing methods (Phase 2.9
§10). These test the *delegation* logic (public list forces
status="published", unknown slugs return empty rather than erroring) via
a lightweight subclass that records calls, rather than hitting a real DB."""

import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.modules.blog.repository import BlogPostRepository


@pytest.mark.asyncio
async def test_list_published_forces_published_status(monkeypatch) -> None:
    repo = BlogPostRepository(AsyncMock())
    captured = {}

    async def fake_list_filtered(**kwargs):
        captured.update(kwargs)
        return [], 0

    repo.list_filtered = fake_list_filtered  # type: ignore[method-assign]

    await repo.list_published(page=1, per_page=10)

    assert captured["status"] == "published"


@pytest.mark.asyncio
async def test_list_published_returns_empty_for_unknown_category_slug() -> None:
    # `execute` is an explicit AsyncMock so `scalar_one_or_none()` returns a
    # real None (not a coroutine) — that None is what drives the
    # "unknown category slug → empty, not error" short-circuit under test.
    result = MagicMock()
    result.scalar_one_or_none.return_value = None  # no category found
    session = MagicMock()
    session.execute = AsyncMock(return_value=result)

    repo = BlogPostRepository(session)
    items, total = await repo.list_published(category_slug="does-not-exist")

    assert items == []
    assert total == 0
