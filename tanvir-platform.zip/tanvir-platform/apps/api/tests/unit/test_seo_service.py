"""Unit tests for SeoService (Phase 2.9 §10)."""

import uuid
from unittest.mock import AsyncMock

import pytest

from app.modules.seo.schemas import UpsertSeoMetadataIn
from app.modules.seo.service import SeoService


@pytest.mark.asyncio
async def test_upsert_creates_new_record_when_none_exists() -> None:
    fake_repo = AsyncMock()
    fake_repo.get_for_entity.return_value = None
    fake_repo.session = AsyncMock()

    service = SeoService(fake_repo)
    entity_id = uuid.uuid4()

    result = await service.upsert_for_entity(
        "blog_post", entity_id, UpsertSeoMetadataIn(meta_title="A great post")
    )

    assert result.entity_type == "blog_post"
    assert result.entity_id == entity_id
    assert result.meta_title == "A great post"
    fake_repo.session.add.assert_called_once()


@pytest.mark.asyncio
async def test_upsert_updates_existing_record_in_place() -> None:
    fake_repo = AsyncMock()
    existing = type("Fake", (), {"meta_title": "Old title", "meta_description": None})()
    fake_repo.get_for_entity.return_value = existing
    fake_repo.session = AsyncMock()

    service = SeoService(fake_repo)
    await service.upsert_for_entity(
        "blog_post", uuid.uuid4(), UpsertSeoMetadataIn(meta_title="New title")
    )

    assert existing.meta_title == "New title"
    fake_repo.session.add.assert_not_called()  # updated in place, not re-added
