"""Unit tests for slug utilities (Phase 2.9 §10)."""

import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import declarative_base

from app.shared.slug import generate_unique_slug, slugify

_Base = declarative_base()


class _FakeModel(_Base):
    """A real (throwaway) mapped model so `select(model.id)` receives an
    actual column expression — SQLAlchemy 2.0 rejects bare-string column
    stubs, and this also mirrors how the helper is called in production."""

    __tablename__ = "fake_slug_model"

    id = Column(Integer, primary_key=True)
    slug = Column(String)


def _session_returning(scalar_values):
    """Build a session whose `execute()` is awaitable and whose result's
    `scalar_one_or_none()` yields the given values in order. Wiring
    `execute` as an explicit AsyncMock (rather than relying on AsyncMock
    child-attribute typing) keeps this stable across Python/mock versions."""
    result = MagicMock()
    result.scalar_one_or_none.side_effect = list(scalar_values)
    session = MagicMock()
    session.execute = AsyncMock(return_value=result)
    return session


def test_slugify_basic_title() -> None:
    assert slugify("5 Lightroom Presets That Changed My Workflow") == (
        "5-lightroom-presets-that-changed-my-workflow"
    )


def test_slugify_strips_special_characters() -> None:
    assert slugify("Before & After: Retouching!") == "before-after-retouching"


@pytest.mark.asyncio
async def test_generate_unique_slug_returns_base_when_available() -> None:
    session = _session_returning([None])  # no collision on the base slug

    slug = await generate_unique_slug(session, _FakeModel, "My New Post")
    assert slug == "my-new-post"


@pytest.mark.asyncio
async def test_generate_unique_slug_appends_suffix_on_collision() -> None:
    # First check (base slug) finds a collision, second check (suffix -2) does not.
    session = _session_returning([uuid.uuid4(), None])

    slug = await generate_unique_slug(session, _FakeModel, "My New Post")
    assert slug == "my-new-post-2"
