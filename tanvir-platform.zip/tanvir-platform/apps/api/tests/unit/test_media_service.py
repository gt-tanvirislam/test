"""Unit tests for MediaService (Phase 2.9 §10 — fake repositories, no DB)."""

import uuid
from unittest.mock import AsyncMock

import pytest

from app.core.exceptions import ConflictError, ValidationError
from app.modules.media.schemas import ConfirmUploadIn, RequestUploadUrlIn
from app.modules.media.service import MediaService, _normalize_filename


def test_normalize_filename_lowercases_and_hyphenates() -> None:
    assert _normalize_filename("My Photo Shoot Final V2.JPG") == "my-photo-shoot-final-v2.jpg"


def test_normalize_filename_strips_special_characters() -> None:
    assert _normalize_filename("Client's Logo (Final)!.png") == "client-s-logo-final.png"


@pytest.mark.asyncio
async def test_request_upload_url_rejects_disallowed_mime_type() -> None:
    service = MediaService(AsyncMock(), AsyncMock(), AsyncMock())

    with pytest.raises(ValidationError):
        await service.request_upload_url(
            RequestUploadUrlIn(file_name="script.exe", mime_type="application/x-msdownload")
        )


@pytest.mark.asyncio
async def test_confirm_upload_requires_alt_text_for_images() -> None:
    fake_asset_repo = AsyncMock()
    fake_asset = type(
        "FakeAsset",
        (),
        {"id": uuid.uuid4(), "mime_type": "image/png", "storage_path": "images/x.png", "file_hash": None},
    )()
    fake_asset_repo.get_by_id.return_value = fake_asset

    service = MediaService(fake_asset_repo, AsyncMock(), AsyncMock())

    with pytest.raises(ValidationError):
        await service.confirm_upload(
            ConfirmUploadIn(pending_asset_id=fake_asset.id, file_size_bytes=1024, alt_text=None)
        )


@pytest.mark.asyncio
async def test_confirm_upload_rejects_oversized_file() -> None:
    fake_asset_repo = AsyncMock()
    fake_asset = type(
        "FakeAsset",
        (),
        {"id": uuid.uuid4(), "mime_type": "video/mp4", "storage_path": "videos/x.mp4", "file_hash": None},
    )()
    fake_asset_repo.get_by_id.return_value = fake_asset

    service = MediaService(fake_asset_repo, AsyncMock(), AsyncMock())

    with pytest.raises(ValidationError):
        await service.confirm_upload(
            ConfirmUploadIn(
                pending_asset_id=fake_asset.id,
                file_size_bytes=600 * 1024 * 1024,  # exceeds 500MB video limit
                alt_text=None,
            )
        )
