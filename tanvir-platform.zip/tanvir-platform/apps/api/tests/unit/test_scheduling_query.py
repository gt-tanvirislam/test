"""
Unit tests for `select_due_scheduled_ids` (Sprint 10 BUG-2).

Pins the exact definition of "due": status is 'scheduled', scheduled_at is
set and not in the future, and the row is live (not soft-deleted). Drafts,
already-published items, future schedules, NULL schedules, and soft-deleted
rows must all be excluded. Runs against a real SQLite table built from the
live BlogPost model, so the query is exercised against actual columns.
"""

import uuid
from datetime import datetime, timezone

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.modules.blog.models import BlogPost
from app.shared.scheduling import select_due_scheduled_ids

# Register the `users` table in Base.metadata so BlogPost's author_id FK can
# be rendered when the table is created (the row is never created; SQLite
# doesn't enforce the FK, so no users table is needed at runtime).
import app.modules.users.models  # noqa: E402,F401

PAST = datetime(2020, 1, 1, tzinfo=timezone.utc)
NOW = datetime(2023, 1, 1, tzinfo=timezone.utc)
FUTURE = datetime(2099, 1, 1, tzinfo=timezone.utc)


@pytest.fixture
async def session():
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(lambda sc: BlogPost.__table__.create(sc, checkfirst=True))
    maker = async_sessionmaker(engine, expire_on_commit=False)
    async with maker() as s:
        yield s
    await engine.dispose()


def _post(**overrides) -> BlogPost:
    values = {
        "id": uuid.uuid4(),
        "author_id": uuid.uuid4(),
        "title": "t",
        "slug": f"slug-{uuid.uuid4()}",
        "body_mdx": "body",
        "status": "scheduled",
        "scheduled_at": PAST,
    }
    values.update(overrides)
    return BlogPost(**values)


@pytest.mark.asyncio
async def test_returns_only_scheduled_items_whose_time_has_passed(session):
    due = _post(status="scheduled", scheduled_at=PAST)
    future = _post(status="scheduled", scheduled_at=FUTURE)
    draft = _post(status="draft", scheduled_at=None)
    published = _post(status="published", scheduled_at=None)
    null_scheduled = _post(status="scheduled", scheduled_at=None)
    deleted_due = _post(
        status="scheduled", scheduled_at=PAST, deleted_at=NOW
    )
    session.add_all([due, future, draft, published, null_scheduled, deleted_due])
    await session.flush()

    ids = await select_due_scheduled_ids(session, BlogPost, NOW)

    assert ids == [due.id]


@pytest.mark.asyncio
async def test_ordered_oldest_first(session):
    older = _post(scheduled_at=datetime(2020, 1, 1, tzinfo=timezone.utc))
    newer = _post(scheduled_at=datetime(2021, 6, 1, tzinfo=timezone.utc))
    session.add_all([newer, older])  # add out of order on purpose
    await session.flush()

    ids = await select_due_scheduled_ids(session, BlogPost, NOW)

    assert ids == [older.id, newer.id]


@pytest.mark.asyncio
async def test_empty_when_nothing_due(session):
    session.add(_post(status="scheduled", scheduled_at=FUTURE))
    session.add(_post(status="draft", scheduled_at=None))
    await session.flush()

    assert await select_due_scheduled_ids(session, BlogPost, NOW) == []
