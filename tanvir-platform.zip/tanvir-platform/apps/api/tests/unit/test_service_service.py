"""Unit tests for ServiceService (Phase 2.9 §10) — mirrors
test_blog_service.py/test_portfolio_service.py's structure."""

import uuid
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from app.core.exceptions import ValidationError
from app.modules.services.service import ServiceService


def _make_service():
    service_repo = AsyncMock()
    service_repo.session = AsyncMock()
    return (
        ServiceService(service_repo, AsyncMock(), AsyncMock(), AsyncMock(), AsyncMock()),
        service_repo,
    )


@pytest.mark.asyncio
async def test_publish_requires_featured_image_and_short_description() -> None:
    service, repo = _make_service()
    service_id = uuid.uuid4()
    fake = SimpleNamespace(
        id=service_id, status="draft", scheduled_at=None, published_at=None,
        featured_image_id=None, short_description=None, tags=[],
    )
    repo.get_by_id_full.return_value = fake

    with pytest.raises(ValidationError):
        await service.publish(service_id, uuid.uuid4())


@pytest.mark.asyncio
async def test_publish_creates_a_revision_snapshot() -> None:
    service, repo = _make_service()
    service_id = uuid.uuid4()
    fake = SimpleNamespace(
        id=service_id, status="draft", scheduled_at=None, published_at=None,
        featured_image_id=uuid.uuid4(), short_description="A blurb",
        title="A service", slug="a-service", full_description="", category_id=None,
        tags=[], pricing_text=None,
    )
    repo.get_by_id_full.return_value = fake

    result = await service.publish(service_id, uuid.uuid4())

    assert result.status == "published"
    repo.session.add.assert_called_once()


@pytest.mark.asyncio
async def test_set_features_and_benefits_use_distinct_item_types() -> None:
    """Proves the single service_list_items table's type discriminator
    keeps Features/Benefits/Process independent — replacing one never
    touches the others."""
    service, repo = _make_service()
    service_id = uuid.uuid4()
    fake = SimpleNamespace(id=service_id)
    repo.get_by_id_full.return_value = fake

    await service.set_features(service_id, [{"title": "Fast turnaround"}])
    service.list_item_repository.replace_all.assert_called_with(
        service_id, "feature", [{"title": "Fast turnaround"}]
    )

    await service.set_benefits(service_id, [{"title": "Peace of mind"}])
    service.list_item_repository.replace_all.assert_called_with(
        service_id, "benefit", [{"title": "Peace of mind"}]
    )
