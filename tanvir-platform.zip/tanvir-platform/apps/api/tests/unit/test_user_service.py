"""Unit test for UserService's permission-flattening logic (Phase 2.9 §10
— unit tests use fake repositories, no real DB)."""

import uuid
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from app.modules.users.service import UserService


def _fake_permission(key: str):
    return SimpleNamespace(key=key)


def _fake_role(name: str, permission_keys: list[str]):
    return SimpleNamespace(name=name, permissions=[_fake_permission(k) for k in permission_keys])


@pytest.mark.asyncio
async def test_permissions_are_flattened_and_deduplicated_across_roles() -> None:
    user_id = uuid.uuid4()
    fake_user = SimpleNamespace(
        id=user_id,
        email="admin@example.com",
        full_name="Admin User",
        roles=[
            _fake_role("editor", ["content.create", "media.upload"]),
            _fake_role("contributor", ["content.create"]),  # overlapping key, should dedupe
        ],
    )

    fake_repository = AsyncMock()
    fake_repository.get_by_id_with_roles.return_value = fake_user

    service = UserService(fake_repository)
    result = await service.get_current_user(user_id)

    assert result.roles == ["editor", "contributor"]
    assert result.permissions == ["content.create", "media.upload"]  # sorted + deduped
