"""
Route-ordering regression test (Sprint 5). FastAPI matches routes in
registration order — `/posts/check-slug` MUST be registered before
`/posts/{post_id}` or "check-slug" gets swallowed by the dynamic UUID
path param and fails validation. This test fails loudly if that ordering
is ever accidentally changed in a future edit.
"""

from app.modules.blog.router import router


def test_check_slug_route_registered_before_dynamic_post_id_route() -> None:
    paths_in_order = [route.path for route in router.routes]

    check_slug_index = paths_in_order.index("/blog/posts/check-slug")
    dynamic_id_index = paths_in_order.index("/blog/posts/{post_id}")

    assert check_slug_index < dynamic_id_index, (
        "check-slug must be registered before the dynamic {post_id} route, "
        "or FastAPI will try to parse 'check-slug' as a UUID and 422 every request."
    )
