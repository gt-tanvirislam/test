"""Unit tests for ContentLifecycleService (Phase 2.9 §10). Uses a plain
fake object satisfying the PublishableModel protocol — no DB, no
concrete content model needed, proving the lifecycle logic is genuinely
model-agnostic."""

from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest

from app.core.exceptions import ConflictError, ValidationError
from app.shared.publishable import ContentLifecycleService, ContentStatus


def _fake_content(status: str = ContentStatus.DRAFT.value):
    return SimpleNamespace(status=status, scheduled_at=None, published_at=None)


def test_publish_sets_published_status_and_timestamp() -> None:
    service = ContentLifecycleService()
    content = _fake_content()

    service.publish(content)

    assert content.status == ContentStatus.PUBLISHED.value
    assert content.published_at is not None
    assert content.scheduled_at is None


def test_publish_twice_raises_conflict() -> None:
    service = ContentLifecycleService()
    content = _fake_content(status=ContentStatus.PUBLISHED.value)

    with pytest.raises(ConflictError):
        service.publish(content)


def test_unpublish_requires_published_status() -> None:
    service = ContentLifecycleService()
    content = _fake_content(status=ContentStatus.DRAFT.value)

    with pytest.raises(ValidationError):
        service.unpublish(content)


def test_schedule_rejects_past_datetime() -> None:
    service = ContentLifecycleService()
    content = _fake_content()

    with pytest.raises(ValidationError):
        service.schedule(content, datetime.now(timezone.utc) - timedelta(days=1))


def test_schedule_sets_scheduled_status() -> None:
    service = ContentLifecycleService()
    content = _fake_content()
    future = datetime.now(timezone.utc) + timedelta(days=1)

    service.schedule(content, future)

    assert content.status == ContentStatus.SCHEDULED.value
    assert content.scheduled_at == future


def test_archive_and_restore_round_trip() -> None:
    service = ContentLifecycleService()
    content = _fake_content(status=ContentStatus.PUBLISHED.value)

    service.archive(content)
    assert content.status == ContentStatus.ARCHIVED.value

    service.restore_from_archive(content)
    assert content.status == ContentStatus.DRAFT.value


def test_restore_requires_archived_status() -> None:
    service = ContentLifecycleService()
    content = _fake_content(status=ContentStatus.DRAFT.value)

    with pytest.raises(ValidationError):
        service.restore_from_archive(content)
