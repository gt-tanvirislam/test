"""Unit test for the shared revision helper (Sprint 6's extraction from
BlogService). Proves it works generically across two different revision
models without either module needing its own copy of this logic."""

import uuid
from unittest.mock import MagicMock

from app.modules.blog.models import BlogPostRevision
from app.modules.portfolio.models import PortfolioItemRevision
from app.shared.revision import create_revision


def test_create_revision_works_for_blog_post_revisions() -> None:
    session = MagicMock()
    entity_id = uuid.uuid4()

    create_revision(
        session, BlogPostRevision, entity_fk_field="blog_post_id", entity_id=entity_id,
        snapshot={"title": "A post"}, actor_id=uuid.uuid4(),
    )

    session.add.assert_called_once()
    added = session.add.call_args[0][0]
    assert isinstance(added, BlogPostRevision)
    assert added.blog_post_id == entity_id


def test_create_revision_works_for_portfolio_item_revisions() -> None:
    session = MagicMock()
    entity_id = uuid.uuid4()

    create_revision(
        session, PortfolioItemRevision, entity_fk_field="portfolio_item_id", entity_id=entity_id,
        snapshot={"title": "A project"}, actor_id=uuid.uuid4(),
    )

    session.add.assert_called_once()
    added = session.add.call_args[0][0]
    assert isinstance(added, PortfolioItemRevision)
    assert added.portfolio_item_id == entity_id
