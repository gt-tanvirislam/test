"""
Unit tests for MediaService.confirm_upload (Sprint 10 BUG-3 lifecycle).

Covers the double-confirmation guard added alongside the file_hash fix: a
pending asset has file_hash=None; once confirmed it carries a real hash, and
confirming it again must be rejected rather than silently overwriting an asset
that may already be attached to published content.
"""

import uuid
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.exceptions import ConflictError
from app.modules.media.schemas import ConfirmUploadIn
from app.modules.media.service import MediaService


def _service(asset):
    asset_repo = AsyncMock()
    asset_repo.get_by_id.return_value = asset
    asset_repo.get_by_hash.return_value = None
    asset_repo.session = AsyncMock()
    folder_repo = AsyncMock()
    storage = MagicMock()
    return MediaService(asset_repo, folder_repo, storage), asset_repo


def _pending_asset():
    return SimpleNamespace(
        id=uuid.uuid4(),
        storage_path="images/abc/photo.jpg",
        mime_type="image/jpeg",
        file_hash=None,  # pending
        file_size_bytes=0,
        alt_text=None,
    )


@pytest.mark.asyncio
async def test_confirm_upload_finalizes_a_pending_asset() -> None:
    asset = _pending_asset()
    service, asset_repo = _service(asset)

    result = await service.confirm_upload(
        ConfirmUploadIn(
            pending_asset_id=asset.id, file_size_bytes=1000, alt_text="a cat"
        )
    )

    assert result.file_hash is not None  # finalized
    assert result.file_size_bytes == 1000
    assert result.alt_text == "a cat"


@pytest.mark.asyncio
async def test_confirm_upload_rejects_double_confirmation() -> None:
    asset = _pending_asset()
    asset.file_hash = "already-finalized"  # already confirmed
    asset.file_size_bytes = 1000
    service, _ = _service(asset)

    with pytest.raises(ConflictError):
        await service.confirm_upload(
            ConfirmUploadIn(
                pending_asset_id=asset.id, file_size_bytes=2000, alt_text="new"
            )
        )

    # The already-confirmed asset must be untouched.
    assert asset.file_size_bytes == 1000
