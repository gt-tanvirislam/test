"""Unit tests for PortfolioService (Phase 2.9 §10). Mirrors
test_blog_service.py's structure — proving the pattern generalizes."""

import uuid
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from app.core.exceptions import ValidationError
from app.modules.portfolio.service import PortfolioService
from app.shared.publishable import ContentStatus


def _make_service():
    item_repo = AsyncMock()
    item_repo.session = AsyncMock()
    return (
        PortfolioService(item_repo, AsyncMock(), AsyncMock(), AsyncMock(), AsyncMock()),
        item_repo,
    )


@pytest.mark.asyncio
async def test_publish_requires_featured_image_and_short_description() -> None:
    service, item_repo = _make_service()
    item_id = uuid.uuid4()
    fake_item = SimpleNamespace(
        id=item_id, status=ContentStatus.DRAFT.value, scheduled_at=None, published_at=None,
        featured_image_id=None, short_description=None, tags=[],
    )
    item_repo.get_by_id_full.return_value = fake_item

    with pytest.raises(ValidationError):
        await service.publish(item_id, uuid.uuid4())


@pytest.mark.asyncio
async def test_publish_creates_a_revision_snapshot() -> None:
    service, item_repo = _make_service()
    item_id = uuid.uuid4()
    fake_item = SimpleNamespace(
        id=item_id, status=ContentStatus.DRAFT.value, scheduled_at=None, published_at=None,
        featured_image_id=uuid.uuid4(), short_description="A short blurb",
        title="A project", slug="a-project", full_case_study="", category_id=None,
        tags=[], client_name=None, results=None,
    )
    item_repo.get_by_id_full.return_value = fake_item

    result = await service.publish(item_id, uuid.uuid4())

    assert result.status == ContentStatus.PUBLISHED.value
    item_repo.session.add.assert_called_once()


@pytest.mark.asyncio
async def test_set_gallery_404s_for_missing_item() -> None:
    from app.core.exceptions import NotFoundError

    service, item_repo = _make_service()
    item_repo.get_by_id_full.return_value = None

    with pytest.raises(NotFoundError):
        await service.set_gallery(uuid.uuid4(), [uuid.uuid4()])
