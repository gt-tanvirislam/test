"""Unit test for resolve_image_urls (Sprint 9) — proves it batches
correctly and handles None IDs gracefully (a common case: many portfolio
items have no featured image yet)."""

import uuid
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.modules.media.router import resolve_image_urls


def _fake_asset(asset_id: uuid.UUID) -> SimpleNamespace:
    """A stand-in with the real, correctly-typed attributes MediaAssetOut
    reads — Pydantic v2 validates types strictly, so a bare MagicMock no
    longer coerces cleanly through `model_validate`."""
    return SimpleNamespace(
        id=asset_id,
        folder_id=None,
        storage_path="images/photo.jpg",
        file_name="photo.jpg",
        mime_type="image/jpeg",
        file_size_bytes=1234,
        alt_text=None,
        width=None,
        height=None,
        duration_seconds=None,
        created_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
        variants=[],
    )


@pytest.mark.asyncio
async def test_resolve_image_urls_skips_none_ids_and_batches_the_rest(monkeypatch) -> None:
    asset_id = uuid.uuid4()

    fake_repo = AsyncMock()
    fake_repo.get_by_ids.return_value = [_fake_asset(asset_id)]

    fake_storage = MagicMock()
    fake_storage.get_public_url.return_value = "https://cdn.example.com/images/photo.jpg"

    monkeypatch.setattr(
        "app.modules.media.router.MediaAssetRepository", lambda session: fake_repo
    )

    result = await resolve_image_urls([asset_id, None, None], AsyncMock(), fake_storage)

    # None values never reach the repository's get_by_ids call.
    fake_repo.get_by_ids.assert_awaited_once_with([asset_id])
    assert result[asset_id] == "https://cdn.example.com/images/photo.jpg"
