"""
Declarative base + shared mixins (Phase 2.2 §1, Phase 2.10 §5). Every
future table's model composes these rather than redefining audit/soft-
delete columns per table.

No concrete tables are defined in this sprint — this is the shared
foundation the first real module (Users & Roles, Sprint 2) builds on.
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class UUIDPrimaryKeyMixin:
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )


class AuditMixin:
    """created_at/updated_at/created_by/updated_by — Phase 2.2 §1."""

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    # created_by/updated_by are FKs to users.id — added once the users
    # table exists (Sprint 2); referencing a nonexistent table now would
    # break migrations for every module built before Users.


class SoftDeleteMixin:
    """deleted_at — enforced automatically at the repository base level
    once BaseRepository is implemented (Sprint 2), per Phase 2.8 §4."""

    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
