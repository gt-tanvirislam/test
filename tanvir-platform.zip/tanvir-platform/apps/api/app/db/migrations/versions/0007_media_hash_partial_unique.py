"""media file_hash: nullable + partial unique index (BUG-3 fix)

Revision ID: 0007
Revises: 0006
Create Date: 2026-08-11

Fixes the media upload crash and the constraint/app-logic mismatch found in
the Sprint 10 takeover:

* `media_assets.file_hash` was NOT NULL with a table-wide UNIQUE, but pending
  uploads were inserted with file_hash="" — so the *second* concurrent pending
  upload collided on "" and raised an IntegrityError (500). Pending rows now
  carry NULL (distinct under a unique index), so any number can be in flight.
* The UNIQUE was table-wide, but the app-level dedup query filters
  `deleted_at IS NULL`. Re-uploading content identical to a *soft-deleted*
  asset therefore passed the app check but failed at the DB. The replacement
  partial unique index is scoped to `file_hash IS NOT NULL AND deleted_at IS
  NULL`, matching the app query exactly.

Existing rows: any legacy file_hash="" (pending rows from before this fix) are
normalized to NULL so they don't occupy the single "" slot under the new index.
"""

from alembic import op

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Drop the old table-wide unique constraint.
    op.drop_constraint("uq_media_assets_file_hash", "media_assets", type_="unique")

    # Make the column nullable so pending uploads can carry NULL.
    op.alter_column("media_assets", "file_hash", nullable=True)

    # Normalize any legacy empty-string hashes (old pending rows) to NULL so
    # they aren't caught by the new index and don't fight over the "" value.
    op.execute("UPDATE media_assets SET file_hash = NULL WHERE file_hash = ''")

    # Partial unique index: dedup only among live, confirmed assets.
    op.create_index(
        "uq_media_assets_file_hash",
        "media_assets",
        ["file_hash"],
        unique=True,
        postgresql_where="file_hash IS NOT NULL AND deleted_at IS NULL",
    )


def downgrade() -> None:
    op.drop_index("uq_media_assets_file_hash", table_name="media_assets")
    # Restore the pre-fix shape. Any NULL hashes must become '' again to
    # satisfy NOT NULL; this reintroduces the original collision risk, which
    # is inherent to the old schema being downgraded to.
    op.execute("UPDATE media_assets SET file_hash = '' WHERE file_hash IS NULL")
    op.alter_column("media_assets", "file_hash", nullable=False)
    op.create_unique_constraint("uq_media_assets_file_hash", "media_assets", ["file_hash"])
