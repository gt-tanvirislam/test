"""create navigation_items table and seed the current site navigation

Revision ID: 0009
Revises: 0008
Create Date: 2026-08-12

The `navigation_items` table from Phase 2.2 §4.7. A single adjacency-list
tree drives both the public header menu and footer columns, so navigation
becomes editable in the dashboard instead of being hardcoded in the
frontend.

The seed is NOT invented content — it is the exact navigation the public
site already ships (the static `getSiteConfig()` header/footer), now moved
into the database so it can be edited. Header links, footer column headers
(url = NULL), and their child links are inserted with deterministic ids so
the seed is idempotent-friendly and easy to reason about.
"""

import uuid

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision = "0009"
down_revision = "0008"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "navigation_items",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("location", sa.String(16), nullable=False),
        sa.Column(
            "parent_id",
            UUID(as_uuid=True),
            sa.ForeignKey("navigation_items.id", ondelete="CASCADE"),
            nullable=True,
        ),
        sa.Column("label", sa.String(120), nullable=False),
        sa.Column("url", sa.String(500), nullable=True),
        sa.Column("sort_order", sa.Integer, nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_navigation_items_location", "navigation_items", ["location"])
    op.create_index("ix_navigation_items_parent_id", "navigation_items", ["parent_id"])

    nav = sa.table(
        "navigation_items",
        sa.column("id", UUID(as_uuid=True)),
        sa.column("location", sa.String),
        sa.column("parent_id", UUID(as_uuid=True)),
        sa.column("label", sa.String),
        sa.column("url", sa.String),
        sa.column("sort_order", sa.Integer),
    )

    # ---- Header links (mirrors the shipped getSiteConfig navItems) --------
    header_rows = [
        {"label": "Home", "url": "/"},
        {"label": "About", "url": "/about"},
        {"label": "Services", "url": "/services"},
        {"label": "Portfolio", "url": "/portfolio"},
        {"label": "Blog", "url": "/blog"},
        {"label": "Contact", "url": "/contact"},
    ]
    op.bulk_insert(
        nav,
        [
            {
                "id": uuid.uuid4(),
                "location": "header",
                "parent_id": None,
                "label": row["label"],
                "url": row["url"],
                "sort_order": index,
            }
            for index, row in enumerate(header_rows)
        ],
    )

    # ---- Footer columns + their links (mirrors shipped footerColumns) -----
    footer_columns = [
        {
            "title": "Site",
            "items": [
                {"label": "About", "url": "/about"},
                {"label": "Services", "url": "/services"},
                {"label": "Portfolio", "url": "/portfolio"},
                {"label": "Blog", "url": "/blog"},
            ],
        },
        {
            "title": "Get in touch",
            "items": [{"label": "Contact", "url": "/contact"}],
        },
    ]
    for col_index, column in enumerate(footer_columns):
        column_id = uuid.uuid4()
        op.bulk_insert(
            nav,
            [
                {
                    "id": column_id,
                    "location": "footer",
                    "parent_id": None,
                    "label": column["title"],
                    "url": None,
                    "sort_order": col_index,
                }
            ],
        )
        op.bulk_insert(
            nav,
            [
                {
                    "id": uuid.uuid4(),
                    "location": "footer",
                    "parent_id": column_id,
                    "label": item["label"],
                    "url": item["url"],
                    "sort_order": link_index,
                }
                for link_index, item in enumerate(column["items"])
            ],
        )


def downgrade() -> None:
    op.drop_index("ix_navigation_items_parent_id", table_name="navigation_items")
    op.drop_index("ix_navigation_items_location", table_name="navigation_items")
    op.drop_table("navigation_items")
