"""create site_settings table (singleton) and seed the one row

Revision ID: 0008
Revises: 0007
Create Date: 2026-08-11

The `settings` table from Phase 2.2 §4.7. A single-row table: global site
configuration read by the public site (`getSiteConfig()`) and edited in the
dashboard. Seeds exactly one row at the fixed sentinel id the app reads by, so
`GET /settings` is deterministic. Seed values are honest and empty — only the
site name is set; tagline, contact email, and social links stay empty until
real values exist (Phase 2.10 §8 — no invented content).
"""

import uuid

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB, UUID

revision = "0008"
down_revision = "0007"
branch_labels = None
depends_on = None

SITE_SETTINGS_ID = uuid.UUID("00000000-0000-0000-0000-000000000001")


def upgrade() -> None:
    op.create_table(
        "site_settings",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("site_name", sa.String, nullable=False, server_default="Tamvir Islam"),
        sa.Column("tagline", sa.String, nullable=True),
        sa.Column("contact_email", sa.String, nullable=True),
        sa.Column("social_links", JSONB, nullable=False, server_default="[]"),
        sa.Column("default_meta_description", sa.Text, nullable=True),
        sa.Column("default_og_image_id", UUID(as_uuid=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )

    settings_table = sa.table(
        "site_settings",
        sa.column("id", UUID),
        sa.column("site_name", sa.String),
    )
    # Seed the single row. Other columns take their server defaults ([] /
    # NULL) — deliberately empty, not placeholder content.
    op.bulk_insert(settings_table, [{"id": SITE_SETTINGS_ID, "site_name": "Tamvir Islam"}])


def downgrade() -> None:
    op.drop_table("site_settings")
