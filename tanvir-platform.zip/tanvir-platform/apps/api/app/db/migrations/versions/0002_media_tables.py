"""create media tables and seed default folders

Revision ID: 0002
Revises: 0001
Create Date: 2026-08-05
"""

import uuid

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

# Matches Phase 2.2 §4.5 exactly.
FOLDER_NAMES = [
    "Images",
    "Videos",
    "Documents",
    "Blog Media",
    "Portfolio Media",
    "Gallery",
    "Temporary Uploads",
    "Profile Images",
]


def upgrade() -> None:
    op.create_table(
        "media_folders",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String, nullable=False),
        sa.Column("parent_id", UUID(as_uuid=True), sa.ForeignKey("media_folders.id", ondelete="CASCADE"), nullable=True),
    )

    op.create_table(
        "media_assets",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("folder_id", UUID(as_uuid=True), sa.ForeignKey("media_folders.id", ondelete="SET NULL"), nullable=True),
        sa.Column("storage_path", sa.String, nullable=False),
        sa.Column("file_name", sa.String, nullable=False),
        sa.Column("mime_type", sa.String, nullable=False),
        sa.Column("file_size_bytes", sa.BigInteger, nullable=False),
        sa.Column("file_hash", sa.String, nullable=False),
        sa.Column("alt_text", sa.String, nullable=True),
        sa.Column("width", sa.Integer, nullable=True),
        sa.Column("height", sa.Integer, nullable=True),
        sa.Column("duration_seconds", sa.Integer, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("file_hash", name="uq_media_assets_file_hash"),
    )
    op.create_index("ix_media_assets_folder_id", "media_assets", ["folder_id"])
    op.create_index("ix_media_assets_deleted_at", "media_assets", ["deleted_at"])

    op.create_table(
        "media_variants",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("media_asset_id", UUID(as_uuid=True), sa.ForeignKey("media_assets.id", ondelete="CASCADE"), nullable=False),
        sa.Column("variant_label", sa.String, nullable=False),
        sa.Column("storage_path", sa.String, nullable=False),
        sa.Column("width", sa.Integer, nullable=True),
        sa.Column("height", sa.Integer, nullable=True),
    )
    op.create_index("ix_media_variants_media_asset_id", "media_variants", ["media_asset_id"])

    op.create_table(
        "content_media",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("media_asset_id", UUID(as_uuid=True), sa.ForeignKey("media_assets.id", ondelete="CASCADE"), nullable=False),
        sa.Column("entity_type", sa.String, nullable=False),
        sa.Column("entity_id", UUID(as_uuid=True), nullable=False),
        sa.Column("role", sa.String, nullable=True),
        sa.Column("sort_order", sa.Integer, nullable=False, server_default="0"),
    )
    op.create_index("ix_content_media_entity", "content_media", ["entity_type", "entity_id"])

    folders_table = sa.table("media_folders", sa.column("id", UUID), sa.column("name", sa.String), sa.column("parent_id", UUID))
    op.bulk_insert(
        folders_table,
        [{"id": uuid.uuid4(), "name": name, "parent_id": None} for name in FOLDER_NAMES],
    )


def downgrade() -> None:
    op.drop_table("content_media")
    op.drop_table("media_variants")
    op.drop_table("media_assets")
    op.drop_table("media_folders")
