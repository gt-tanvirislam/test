"""create tags and blog tables

Revision ID: 0004
Revises: 0003
Create Date: 2026-08-05
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB, UUID

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Shared tags table (Phase 2.2 §4.3) — created here since Blog is the
    # first consumer, but NOT blog-specific; Portfolio adds its own join
    # table against this same table later.
    op.create_table(
        "tags",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String, nullable=False, unique=True),
        sa.Column("slug", sa.String, nullable=False, unique=True),
    )

    op.create_table(
        "blog_categories",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String, nullable=False, unique=True),
        sa.Column("slug", sa.String, nullable=False, unique=True),
        sa.Column("description", sa.String, nullable=True),
    )

    op.create_table(
        "blog_posts",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("author_id", UUID(as_uuid=True), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("category_id", UUID(as_uuid=True), sa.ForeignKey("blog_categories.id", ondelete="SET NULL"), nullable=True),
        sa.Column("title", sa.String, nullable=False),
        sa.Column("slug", sa.String, nullable=False, unique=True),
        sa.Column("excerpt", sa.String, nullable=True),
        sa.Column("body_mdx", sa.Text, nullable=False, server_default=""),
        sa.Column("featured_image_id", UUID(as_uuid=True), nullable=True),
        sa.Column("reading_time_minutes", sa.Integer, nullable=True),
        sa.Column("canonical_url", sa.String, nullable=True),
        sa.Column("featured", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("locale", sa.String, nullable=False, server_default="en"),
        sa.Column("status", sa.String, nullable=False, server_default="draft"),
        sa.Column("scheduled_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_blog_posts_slug", "blog_posts", ["slug"])
    op.create_index("ix_blog_posts_status", "blog_posts", ["status"])
    op.create_index("ix_blog_posts_deleted_at", "blog_posts", ["deleted_at"])
    op.create_index("ix_blog_posts_category_id", "blog_posts", ["category_id"])
    # Full-text search index (Phase 2.2 §7's GIN index over title+body,
    # simplified here to title+excerpt for the dashboard search filter
    # this sprint implements; full public-search indexing is Search-module
    # scope per Phase 2.8 §19 step 10).
    op.execute(
        "CREATE INDEX ix_blog_posts_search ON blog_posts "
        "USING gin (to_tsvector('english', title || ' ' || coalesce(excerpt, '')))"
    )

    op.create_table(
        "blog_post_tags",
        sa.Column("blog_post_id", UUID(as_uuid=True), sa.ForeignKey("blog_posts.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("tag_id", UUID(as_uuid=True), sa.ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
    )

    op.create_table(
        "blog_post_revisions",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("blog_post_id", UUID(as_uuid=True), sa.ForeignKey("blog_posts.id", ondelete="CASCADE"), nullable=False),
        sa.Column("snapshot", JSONB, nullable=False),
        sa.Column("created_by", UUID(as_uuid=True), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_blog_post_revisions_post_created", "blog_post_revisions", ["blog_post_id", "created_at"])


def downgrade() -> None:
    op.drop_table("blog_post_revisions")
    op.drop_table("blog_post_tags")
    op.drop_index("ix_blog_posts_search", table_name="blog_posts")
    op.drop_table("blog_posts")
    op.drop_table("blog_categories")
    op.drop_table("tags")
