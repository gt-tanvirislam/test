"""create contact_inquiries, testimonials, faq_items and seed new permissions

Revision ID: 0010
Revises: 0009
Create Date: 2026-08-12

Adds the three remaining content/lead tables (Contact inquiries,
Testimonials, FAQ) and extends the RBAC matrix with the permissions that
gate them:

    inquiries.view / inquiries.manage
    testimonials.view / testimonials.manage
    faq.view / faq.manage

The grant policy mirrors migration 0001's matrix exactly: `owner` and
`admin` receive every one of these (none are in the owner-only set that
0001 reserved — users.manage / backups.manage). Role ids are looked up by
name at run time because 0001 seeded them with random UUIDs; we never
hardcode them. The permission rows themselves get fresh deterministic-at-
runtime UUIDs (uuid4), consistent with how 0001 created its permission rows.
"""

import uuid

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision = "0010"
down_revision = "0009"
branch_labels = None
depends_on = None


# New permission keys introduced by this migration.
NEW_PERMISSIONS = [
    "inquiries.view",
    "inquiries.manage",
    "testimonials.view",
    "testimonials.manage",
    "faq.view",
    "faq.manage",
]

# Which roles receive them. Same policy as 0001: owner + admin get the full
# set (these are ordinary content/lead permissions, not the owner-only
# users.manage / backups.manage). editor/contributor/viewer are unchanged.
ROLES_GRANTED = ["owner", "admin"]


def upgrade() -> None:
    # ── contact_inquiries ───────────────────────────────────────────────
    op.create_table(
        "contact_inquiries",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(160), nullable=False),
        sa.Column("email", sa.String(254), nullable=False),
        sa.Column("company", sa.String(160), nullable=True),
        sa.Column("service", sa.String(120), nullable=True),
        sa.Column("project_type", sa.String(120), nullable=True),
        sa.Column("budget_range", sa.String(60), nullable=True),
        sa.Column("preferred_contact", sa.String(60), nullable=True),
        sa.Column("message", sa.Text, nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="new"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_contact_inquiries_status", "contact_inquiries", ["status"])
    op.create_index("ix_contact_inquiries_email", "contact_inquiries", ["email"])
    op.create_index("ix_contact_inquiries_deleted_at", "contact_inquiries", ["deleted_at"])
    op.create_index("ix_contact_inquiries_created_at", "contact_inquiries", ["created_at"])

    # ── testimonials ────────────────────────────────────────────────────
    op.create_table(
        "testimonials",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("quote", sa.Text, nullable=False),
        sa.Column("author_name", sa.String(160), nullable=False),
        sa.Column("author_title", sa.String(160), nullable=True),
        sa.Column("author_company", sa.String(160), nullable=True),
        sa.Column("avatar_image_id", UUID(as_uuid=True), nullable=True),
        sa.Column("is_published", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("is_featured", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("sort_order", sa.Integer, nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_testimonials_published", "testimonials", ["is_published"])
    op.create_index("ix_testimonials_deleted_at", "testimonials", ["deleted_at"])

    # ── faq_items ───────────────────────────────────────────────────────
    op.create_table(
        "faq_items",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("question", sa.String(500), nullable=False),
        sa.Column("answer", sa.Text, nullable=False),
        sa.Column("category", sa.String(120), nullable=True),
        sa.Column("is_published", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("sort_order", sa.Integer, nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_faq_items_published", "faq_items", ["is_published"])
    op.create_index("ix_faq_items_deleted_at", "faq_items", ["deleted_at"])

    # ── Seed the new permissions + role grants ──────────────────────────
    permissions_table = sa.table(
        "permissions",
        sa.column("id", UUID(as_uuid=True)),
        sa.column("key", sa.String),
        sa.column("description", sa.String),
    )
    role_permissions_table = sa.table(
        "role_permissions",
        sa.column("role_id", UUID(as_uuid=True)),
        sa.column("permission_id", UUID(as_uuid=True)),
    )

    permission_ids = {key: uuid.uuid4() for key in NEW_PERMISSIONS}
    op.bulk_insert(
        permissions_table,
        [{"id": permission_ids[key], "key": key, "description": None} for key in NEW_PERMISSIONS],
    )

    # Look up the existing role ids by name (0001 assigned them random UUIDs).
    bind = op.get_bind()
    role_rows = bind.execute(
        sa.text("SELECT id, name FROM roles WHERE name = ANY(:names)"),
        {"names": ROLES_GRANTED},
    ).fetchall()
    role_ids = {name: rid for rid, name in role_rows}

    grant_rows = [
        {"role_id": role_ids[role], "permission_id": permission_ids[key]}
        for role in ROLES_GRANTED
        if role in role_ids
        for key in NEW_PERMISSIONS
    ]
    if grant_rows:
        op.bulk_insert(role_permissions_table, grant_rows)


def downgrade() -> None:
    bind = op.get_bind()
    # Remove role grants + permission rows for the keys this migration added.
    bind.execute(
        sa.text(
            "DELETE FROM role_permissions WHERE permission_id IN "
            "(SELECT id FROM permissions WHERE key = ANY(:keys))"
        ),
        {"keys": NEW_PERMISSIONS},
    )
    bind.execute(
        sa.text("DELETE FROM permissions WHERE key = ANY(:keys)"),
        {"keys": NEW_PERMISSIONS},
    )

    op.drop_index("ix_faq_items_deleted_at", table_name="faq_items")
    op.drop_index("ix_faq_items_published", table_name="faq_items")
    op.drop_table("faq_items")

    op.drop_index("ix_testimonials_deleted_at", table_name="testimonials")
    op.drop_index("ix_testimonials_published", table_name="testimonials")
    op.drop_table("testimonials")

    op.drop_index("ix_contact_inquiries_created_at", table_name="contact_inquiries")
    op.drop_index("ix_contact_inquiries_deleted_at", table_name="contact_inquiries")
    op.drop_index("ix_contact_inquiries_email", table_name="contact_inquiries")
    op.drop_index("ix_contact_inquiries_status", table_name="contact_inquiries")
    op.drop_table("contact_inquiries")
