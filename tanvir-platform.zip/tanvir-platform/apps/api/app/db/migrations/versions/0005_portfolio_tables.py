"""create portfolio tables

Revision ID: 0005
Revises: 0004
Create Date: 2026-08-06
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "portfolio_categories",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String, nullable=False, unique=True),
        sa.Column("slug", sa.String, nullable=False, unique=True),
        sa.Column("description", sa.String, nullable=True),
    )

    op.create_table(
        "portfolio_items",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("author_id", UUID(as_uuid=True), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("category_id", UUID(as_uuid=True), sa.ForeignKey("portfolio_categories.id", ondelete="SET NULL"), nullable=True),
        sa.Column("title", sa.String, nullable=False),
        sa.Column("slug", sa.String, nullable=False, unique=True),
        sa.Column("short_description", sa.String, nullable=True),
        sa.Column("full_case_study", sa.Text, nullable=False, server_default=""),
        sa.Column("featured_image_id", UUID(as_uuid=True), nullable=True),
        sa.Column("client_name", sa.String, nullable=True),
        sa.Column("industry", sa.String, nullable=True),
        sa.Column("project_date", sa.Date, nullable=True),
        sa.Column("services_used", ARRAY(sa.String), nullable=False, server_default="{}"),
        sa.Column("technologies", ARRAY(sa.String), nullable=False, server_default="{}"),
        sa.Column("is_case_study", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("challenge", sa.Text, nullable=True),
        sa.Column("solution", sa.Text, nullable=True),
        sa.Column("results", sa.Text, nullable=True),
        sa.Column("results_metrics", JSONB, nullable=True),
        sa.Column("cta_text", sa.String, nullable=True),
        sa.Column("cta_link", sa.String, nullable=True),
        sa.Column("featured", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("status", sa.String, nullable=False, server_default="draft"),
        sa.Column("scheduled_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_portfolio_items_slug", "portfolio_items", ["slug"])
    op.create_index("ix_portfolio_items_status", "portfolio_items", ["status"])
    op.create_index("ix_portfolio_items_deleted_at", "portfolio_items", ["deleted_at"])
    op.create_index("ix_portfolio_items_category_id", "portfolio_items", ["category_id"])
    op.create_index("ix_portfolio_items_featured", "portfolio_items", ["featured"])
    op.execute(
        "CREATE INDEX ix_portfolio_items_search ON portfolio_items "
        "USING gin (to_tsvector('english', title || ' ' || coalesce(short_description, '')))"
    )

    op.create_table(
        "portfolio_item_tags",
        sa.Column("portfolio_item_id", UUID(as_uuid=True), sa.ForeignKey("portfolio_items.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("tag_id", UUID(as_uuid=True), sa.ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
    )

    op.create_table(
        "before_after_pairs",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("portfolio_item_id", UUID(as_uuid=True), sa.ForeignKey("portfolio_items.id", ondelete="CASCADE"), nullable=False),
        sa.Column("before_media_id", UUID(as_uuid=True), nullable=False),
        sa.Column("after_media_id", UUID(as_uuid=True), nullable=False),
        sa.Column("caption", sa.String, nullable=True),
        sa.Column("sort_order", sa.Integer, nullable=False, server_default="0"),
    )
    op.create_index("ix_before_after_pairs_item", "before_after_pairs", ["portfolio_item_id"])

    op.create_table(
        "portfolio_item_revisions",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("portfolio_item_id", UUID(as_uuid=True), sa.ForeignKey("portfolio_items.id", ondelete="CASCADE"), nullable=False),
        sa.Column("snapshot", JSONB, nullable=False),
        sa.Column("created_by", UUID(as_uuid=True), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_portfolio_item_revisions_item_created", "portfolio_item_revisions", ["portfolio_item_id", "created_at"])


def downgrade() -> None:
    op.drop_table("portfolio_item_revisions")
    op.drop_table("before_after_pairs")
    op.drop_table("portfolio_item_tags")
    op.drop_index("ix_portfolio_items_search", table_name="portfolio_items")
    op.drop_table("portfolio_items")
    op.drop_table("portfolio_categories")
