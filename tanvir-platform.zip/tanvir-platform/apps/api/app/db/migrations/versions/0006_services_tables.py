"""create services tables

Revision ID: 0006
Revises: 0005
Create Date: 2026-08-07
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB, UUID

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "service_categories",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String, nullable=False, unique=True),
        sa.Column("slug", sa.String, nullable=False, unique=True),
        sa.Column("description", sa.String, nullable=True),
    )

    op.create_table(
        "services",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("author_id", UUID(as_uuid=True), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("category_id", UUID(as_uuid=True), sa.ForeignKey("service_categories.id", ondelete="SET NULL"), nullable=True),
        sa.Column("title", sa.String, nullable=False),
        sa.Column("slug", sa.String, nullable=False, unique=True),
        sa.Column("short_description", sa.String, nullable=True),
        sa.Column("full_description", sa.Text, nullable=False, server_default=""),
        sa.Column("icon_key", sa.String, nullable=True),
        sa.Column("featured_image_id", UUID(as_uuid=True), nullable=True),
        sa.Column("pricing_text", sa.String, nullable=True),
        sa.Column("delivery_time", sa.String, nullable=True),
        sa.Column("cta_text", sa.String, nullable=True),
        sa.Column("cta_link", sa.String, nullable=True),
        sa.Column("featured", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("sort_order", sa.Integer, nullable=False, server_default="0"),
        sa.Column("status", sa.String, nullable=False, server_default="draft"),
        sa.Column("scheduled_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_services_slug", "services", ["slug"])
    op.create_index("ix_services_status", "services", ["status"])
    op.create_index("ix_services_deleted_at", "services", ["deleted_at"])
    op.create_index("ix_services_category_id", "services", ["category_id"])
    op.create_index("ix_services_sort_order", "services", ["sort_order"])
    op.execute(
        "CREATE INDEX ix_services_search ON services "
        "USING gin (to_tsvector('english', title || ' ' || coalesce(short_description, '')))"
    )

    op.create_table(
        "service_tags",
        sa.Column("service_id", UUID(as_uuid=True), sa.ForeignKey("services.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("tag_id", UUID(as_uuid=True), sa.ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
    )

    op.create_table(
        "service_list_items",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("service_id", UUID(as_uuid=True), sa.ForeignKey("services.id", ondelete="CASCADE"), nullable=False),
        sa.Column("item_type", sa.String, nullable=False),
        sa.Column("title", sa.String, nullable=False),
        sa.Column("description", sa.String, nullable=True),
        sa.Column("sort_order", sa.Integer, nullable=False, server_default="0"),
    )
    op.create_index("ix_service_list_items_service_type", "service_list_items", ["service_id", "item_type"])

    op.create_table(
        "service_revisions",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("service_id", UUID(as_uuid=True), sa.ForeignKey("services.id", ondelete="CASCADE"), nullable=False),
        sa.Column("snapshot", JSONB, nullable=False),
        sa.Column("created_by", UUID(as_uuid=True), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_service_revisions_service_created", "service_revisions", ["service_id", "created_at"])


def downgrade() -> None:
    op.drop_table("service_revisions")
    op.drop_table("service_list_items")
    op.drop_table("service_tags")
    op.drop_index("ix_services_search", table_name="services")
    op.drop_table("services")
    op.drop_table("service_categories")
