"""create seo_metadata table

Revision ID: 0003
Revises: 0002
Create Date: 2026-08-05
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "seo_metadata",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("entity_type", sa.String, nullable=False),
        sa.Column("entity_id", UUID(as_uuid=True), nullable=False),
        sa.Column("meta_title", sa.String, nullable=True),
        sa.Column("meta_description", sa.String, nullable=True),
        sa.Column("og_image_id", UUID(as_uuid=True), nullable=True),
        sa.Column("canonical_override", sa.String, nullable=True),
        sa.Column("noindex", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("twitter_card_type", sa.String, nullable=True),
        sa.Column("robots_directive", sa.String, nullable=True),
        sa.Column("json_ld_override", sa.String, nullable=True),
        sa.UniqueConstraint("entity_type", "entity_id", name="uq_seo_metadata_entity"),
    )
    op.create_index("ix_seo_metadata_entity", "seo_metadata", ["entity_type", "entity_id"])


def downgrade() -> None:
    op.drop_table("seo_metadata")
