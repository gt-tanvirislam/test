"""create identity tables (users, roles, permissions) and seed RBAC matrix

Revision ID: 0001
Revises:
Create Date: 2026-08-05
"""

import uuid

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

# Role/permission seed data mirrors the RBAC matrix in Phase 2.3 §2
# exactly — this migration IS that matrix, translated into rows.
ROLES = ["owner", "admin", "editor", "contributor", "viewer"]

PERMISSIONS = [
    "content.view_published",
    "content.view_drafts",
    "content.create",
    "content.edit_any",
    "content.edit_own",
    "content.publish",
    "content.delete",
    "content.restore",
    "media.manage",
    "media.upload",
    "settings.manage",
    "navigation.manage",
    "users.manage",
    "activity.view",
    "comments.moderate",
    "analytics.view",
    "backups.manage",
]

# role -> permission keys, per the Phase 2.3 §2 matrix
ROLE_PERMISSIONS: dict[str, list[str]] = {
    "owner": PERMISSIONS,  # full access
    "admin": [p for p in PERMISSIONS if p not in ("users.manage", "backups.manage")],
    "editor": [
        "content.view_published",
        "content.view_drafts",
        "content.create",
        "content.edit_any",
        "media.upload",
        "comments.moderate",
    ],
    "contributor": [
        "content.view_published",
        "content.create",
        "content.edit_own",
    ],
    "viewer": ["content.view_published"],
}


def upgrade() -> None:
    op.create_table(
        "roles",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String, nullable=False, unique=True),
        sa.Column("description", sa.String, nullable=True),
    )

    op.create_table(
        "permissions",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("key", sa.String, nullable=False, unique=True),
        sa.Column("description", sa.String, nullable=True),
    )

    op.create_table(
        "role_permissions",
        sa.Column("role_id", UUID(as_uuid=True), sa.ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
        sa.Column(
            "permission_id",
            UUID(as_uuid=True),
            sa.ForeignKey("permissions.id", ondelete="CASCADE"),
            primary_key=True,
        ),
    )

    op.create_table(
        "users",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),  # matches auth.users.id
        sa.Column("email", sa.String, nullable=False, unique=True),
        sa.Column("full_name", sa.String, nullable=False),
        sa.Column("avatar_media_id", UUID(as_uuid=True), nullable=True),
        sa.Column("status", sa.String, nullable=False, server_default="active"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_users_email", "users", ["email"])

    op.create_table(
        "user_roles",
        sa.Column("user_id", UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("role_id", UUID(as_uuid=True), sa.ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
    )

    # ── Seed roles, permissions, and the RBAC matrix (Phase 2.3 §2) ──────
    roles_table = sa.table("roles", sa.column("id", UUID), sa.column("name", sa.String), sa.column("description", sa.String))
    permissions_table = sa.table("permissions", sa.column("id", UUID), sa.column("key", sa.String), sa.column("description", sa.String))
    role_permissions_table = sa.table(
        "role_permissions", sa.column("role_id", UUID), sa.column("permission_id", UUID)
    )

    role_ids = {name: uuid.uuid4() for name in ROLES}
    permission_ids = {key: uuid.uuid4() for key in PERMISSIONS}

    op.bulk_insert(roles_table, [{"id": role_ids[name], "name": name, "description": None} for name in ROLES])
    op.bulk_insert(
        permissions_table,
        [{"id": permission_ids[key], "key": key, "description": None} for key in PERMISSIONS],
    )

    role_permission_rows = [
        {"role_id": role_ids[role], "permission_id": permission_ids[perm]}
        for role, perms in ROLE_PERMISSIONS.items()
        for perm in perms
    ]
    op.bulk_insert(role_permissions_table, role_permission_rows)


def downgrade() -> None:
    op.drop_table("user_roles")
    op.drop_index("ix_users_email", table_name="users")
    op.drop_table("users")
    op.drop_table("role_permissions")
    op.drop_table("permissions")
    op.drop_table("roles")
