"""
Database connection foundation (Phase 2.8 §4). Async SQLAlchemy engine
with pooled connections and a health-check-on-checkout to avoid serving
requests against stale connections after idle periods (relevant given
Render's free-tier cold-start behavior, flagged back in Phase 1.2).

No models or repositories are defined here yet — those arrive module by
module, starting with Users & Roles (Sprint 2), per Phase 2.8 §19.
"""

from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import get_settings
from app.core.logging import get_logger

settings = get_settings()
logger = get_logger(__name__)

engine = create_async_engine(
    settings.database_url,
    pool_pre_ping=True,  # health-check on checkout
    pool_size=5,
    max_overflow=10,
    echo=not settings.is_production,
)

AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency yielding a request-scoped session that owns the
    request's transaction (Phase 2.8 §2, and the "committed once at the
    end of the request" unit-of-work rule in the backend architecture
    blueprint §125). Repositories receive this via `Depends()` — they
    never construct their own session and never commit themselves.

    Transaction boundary (Sprint 10 fix): the whole request runs inside a
    single transaction. If the route handler returns normally, we commit
    once; if it raises, we roll back. Services therefore only ever
    `flush()` (to assign PKs / surface constraint errors mid-request) —
    the single commit here is what actually persists the work, so a
    failure part-way through a multi-write operation can never leave a
    partial write behind.

    Before this fix, `get_db_session` opened a session but nothing ever
    committed, so every write was silently rolled back on session close.
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception:
            # Route handler (or a downstream service) raised — discard the
            # whole transaction so no partial write survives. Re-raise so
            # the registered exception handlers still map it to the correct
            # HTTP response; `async with` will close the session either way.
            await session.rollback()
            raise
        else:
            # Handler completed successfully — persist the unit of work.
            await session.commit()
