"""Portfolio schemas (Phase 2.3 §6). Field-for-field mirrors Blog's
schema shape (Sprint 4) for everything they share, adding only the
genuinely Portfolio-specific fields."""

import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field

from app.modules.taxonomy.schemas import TagOut


class PortfolioCategoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    slug: str
    description: str | None


class CreatePortfolioCategoryIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: str | None = None


class BeforeAfterPairOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    before_media_id: uuid.UUID
    after_media_id: uuid.UUID
    caption: str | None
    sort_order: int


class BeforeAfterPairIn(BaseModel):
    before_media_id: uuid.UUID
    after_media_id: uuid.UUID
    caption: str | None = None


class PortfolioItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    author_id: uuid.UUID
    category_id: uuid.UUID | None
    category: PortfolioCategoryOut | None = None
    tags: list[TagOut] = []
    before_after_pairs: list[BeforeAfterPairOut] = []

    title: str
    slug: str
    short_description: str | None
    full_case_study: str
    featured_image_id: uuid.UUID | None

    client_name: str | None
    industry: str | None
    project_date: date | None
    services_used: list[str]
    technologies: list[str]

    is_case_study: bool
    challenge: str | None
    solution: str | None
    results: str | None
    results_metrics: dict | None

    cta_text: str | None
    cta_link: str | None
    featured: bool

    status: str
    scheduled_at: datetime | None
    published_at: datetime | None
    created_at: datetime
    updated_at: datetime


class PortfolioItemListItemOut(BaseModel):
    """Slimmer list-view shape (Sprint 5's over-fetching lesson applied
    from day one here, not retrofitted later)."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str
    slug: str
    status: str
    featured: bool
    category: PortfolioCategoryOut | None = None
    featured_image_id: uuid.UUID | None
    featured_image_url: str | None = None  # populated by the router (Sprint 9), not a DB column
    published_at: datetime | None
    updated_at: datetime


class CreatePortfolioItemIn(BaseModel):
    title: str = Field(..., min_length=3, max_length=200)
    slug: str | None = None
    short_description: str | None = Field(default=None, max_length=300)
    full_case_study: str = ""
    category_id: uuid.UUID | None = None
    tag_names: list[str] = []
    featured_image_id: uuid.UUID | None = None
    client_name: str | None = None
    industry: str | None = None
    project_date: date | None = None
    services_used: list[str] = []
    technologies: list[str] = []
    is_case_study: bool = False
    featured: bool = False


class UpdatePortfolioItemIn(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=200)
    slug: str | None = None
    short_description: str | None = Field(default=None, max_length=300)
    full_case_study: str | None = None
    category_id: uuid.UUID | None = None
    tag_names: list[str] | None = None
    featured_image_id: uuid.UUID | None = None
    author_id: uuid.UUID | None = None
    client_name: str | None = None
    industry: str | None = None
    project_date: date | None = None
    services_used: list[str] | None = None
    technologies: list[str] | None = None
    is_case_study: bool | None = None
    challenge: str | None = None
    solution: str | None = None
    results: str | None = None
    results_metrics: dict | None = None
    cta_text: str | None = None
    cta_link: str | None = None
    featured: bool | None = None


class SchedulePortfolioItemIn(BaseModel):
    scheduled_at: datetime


class SetGalleryIn(BaseModel):
    media_asset_ids: list[uuid.UUID]


class SetBeforeAfterPairsIn(BaseModel):
    pairs: list[BeforeAfterPairIn]
