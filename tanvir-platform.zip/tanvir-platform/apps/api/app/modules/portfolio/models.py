"""
Portfolio models (Phase 2.2 §4.3). Reuses the exact composition pattern
Blog established in Sprint 4: AuditMixin + SoftDeleteMixin (Sprint 0) +
PublishableStatusMixin (Sprint 3) + shared Tag table (Sprint 4's
taxonomy module, joined via `portfolio_item_tags`, NOT a second tags
table).

Gallery images deliberately do NOT get a new table — Portfolio uses the
existing polymorphic `content_media` table (Sprint 2) with
`entity_type="portfolio_item"`, exactly as Phase 2.2 §4.5 specified it
would be used. This is Portfolio proving that reuse decision was correct.
"""

import uuid
from datetime import date, datetime

from sqlalchemy import (
    ARRAY,
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Table,
    Column,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import AuditMixin, Base, SoftDeleteMixin
from app.modules.taxonomy.models import Tag
from app.shared.publishable import PublishableStatusMixin

portfolio_item_tags = Table(
    "portfolio_item_tags",
    Base.metadata,
    Column("portfolio_item_id", UUID(as_uuid=True), ForeignKey("portfolio_items.id", ondelete="CASCADE"), primary_key=True),
    Column("tag_id", UUID(as_uuid=True), ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
)


class PortfolioCategory(Base):
    __tablename__ = "portfolio_categories"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(String, nullable=True)


class PortfolioItem(Base, AuditMixin, SoftDeleteMixin, PublishableStatusMixin):
    __tablename__ = "portfolio_items"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    author_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    category_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("portfolio_categories.id", ondelete="SET NULL"), nullable=True
    )

    title: Mapped[str] = mapped_column(String, nullable=False)
    slug: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    short_description: Mapped[str | None] = mapped_column(String, nullable=True)
    full_case_study: Mapped[str] = mapped_column(Text, nullable=False, default="")
    featured_image_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    client_name: Mapped[str | None] = mapped_column(String, nullable=True)
    industry: Mapped[str | None] = mapped_column(String, nullable=True)
    project_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    # Free-text arrays (Sprint 6 decision — see completion report): no
    # `services` table exists yet to foreign-key against, so
    # "Services Used" is stored the same way "Technologies" already
    # needed to be, matching Blog's tag_names-before-real-FK precedent.
    services_used: Mapped[list[str]] = mapped_column(ARRAY(String), default=list, nullable=False)
    technologies: Mapped[list[str]] = mapped_column(ARRAY(String), default=list, nullable=False)

    is_case_study: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    challenge: Mapped[str | None] = mapped_column(Text, nullable=True)
    solution: Mapped[str | None] = mapped_column(Text, nullable=True)
    results: Mapped[str | None] = mapped_column(Text, nullable=True)
    results_metrics: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    cta_text: Mapped[str | None] = mapped_column(String, nullable=True)
    cta_link: Mapped[str | None] = mapped_column(String, nullable=True)

    featured: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    category: Mapped[PortfolioCategory | None] = relationship()
    tags: Mapped[list[Tag]] = relationship(secondary=portfolio_item_tags)
    before_after_pairs: Mapped[list["BeforeAfterPair"]] = relationship(
        back_populates="portfolio_item", cascade="all, delete-orphan", order_by="BeforeAfterPair.sort_order"
    )


class BeforeAfterPair(Base):
    """Supports MULTIPLE before/after comparisons per project (Phase
    2.2 §4.3) — the deliberate improvement over the brief's flat
    single-pair fields, explained in this sprint's completion report."""

    __tablename__ = "before_after_pairs"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    portfolio_item_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("portfolio_items.id", ondelete="CASCADE"), nullable=False
    )
    before_media_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    after_media_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    caption: Mapped[str | None] = mapped_column(String, nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    portfolio_item: Mapped[PortfolioItem] = relationship(back_populates="before_after_pairs")


class PortfolioItemRevision(Base):
    __tablename__ = "portfolio_item_revisions"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    portfolio_item_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("portfolio_items.id", ondelete="CASCADE"), nullable=False
    )
    snapshot: Mapped[dict] = mapped_column(JSONB, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
