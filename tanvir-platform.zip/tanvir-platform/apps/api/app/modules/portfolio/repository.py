"""
Portfolio repository (Phase 2.8 §3, §4). Applies Sprint 5's over-fetching
fix from the start rather than repeating Blog's original mistake:
list-view queries never eager-load tags/before-after pairs, only what
`PortfolioItemListItemOut` actually renders.
"""

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.modules.portfolio.models import BeforeAfterPair, PortfolioCategory, PortfolioItem, portfolio_item_tags
from app.shared.content_query import list_filtered_content
from app.shared.repository_base import BaseRepository


class PortfolioItemRepository(BaseRepository[PortfolioItem]):
    model = PortfolioItem

    def _detail_query(self):
        return select(PortfolioItem).options(
            selectinload(PortfolioItem.category),
            selectinload(PortfolioItem.tags),
            selectinload(PortfolioItem.before_after_pairs),
        )

    def _list_query(self):
        return select(PortfolioItem).options(selectinload(PortfolioItem.category))

    async def get_by_id_full(self, item_id: uuid.UUID) -> PortfolioItem | None:
        stmt = self._detail_query().where(PortfolioItem.id == item_id, PortfolioItem.deleted_at.is_(None))
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_slug(self, slug: str, *, published_only: bool = False) -> PortfolioItem | None:
        stmt = self._detail_query().where(PortfolioItem.slug == slug, PortfolioItem.deleted_at.is_(None))
        if published_only:
            stmt = stmt.where(PortfolioItem.status == "published")
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def slug_exists(self, slug: str, *, exclude_id: uuid.UUID | None = None) -> bool:
        stmt = select(PortfolioItem.id).where(PortfolioItem.slug == slug, PortfolioItem.deleted_at.is_(None))
        if exclude_id:
            stmt = stmt.where(PortfolioItem.id != exclude_id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none() is not None

    async def list_filtered(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        status: str | None = None,
        category_id: uuid.UUID | None = None,
        tag_id: uuid.UUID | None = None,
        author_id: uuid.UUID | None = None,
        search: str | None = None,
        featured: bool | None = None,
    ) -> tuple[list[PortfolioItem], int]:
        """
        Sprint 8: refactored to delegate to the shared
        `list_filtered_content()` helper (extracted this sprint the
        moment Services became a third identical-shape consumer) rather
        than the inline duplication this method had since Sprint 6. This
        method's remaining job is only declaring which columns are
        filterable/searchable for Portfolio specifically.
        """
        list_stmt = self._list_query().where(PortfolioItem.deleted_at.is_(None))
        count_stmt = select(func.count(func.distinct(PortfolioItem.id))).select_from(PortfolioItem).where(
            PortfolioItem.deleted_at.is_(None)
        )

        return await list_filtered_content(
            self.session,
            list_stmt=list_stmt,
            count_stmt=count_stmt,
            page=page,
            per_page=per_page,
            equality_filters={
                PortfolioItem.status: status,
                PortfolioItem.category_id: category_id,
                PortfolioItem.author_id: author_id,
                PortfolioItem.featured: featured,
            },
            search_columns=[PortfolioItem.title, PortfolioItem.short_description],
            search_term=search,
            tag_join_table=portfolio_item_tags,
            tag_id_column=portfolio_item_tags.c.tag_id,
            tag_id=tag_id,
            order_by_column=PortfolioItem.updated_at,
        )

    async def list_published(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        category_slug: str | None = None,
        tag_slug: str | None = None,
        search: str | None = None,
    ) -> tuple[list[PortfolioItem], int]:
        category_id = None
        if category_slug:
            result = await self.session.execute(
                select(PortfolioCategory.id).where(PortfolioCategory.slug == category_slug)
            )
            category_id = result.scalar_one_or_none()
            if category_id is None:
                return [], 0

        tag_id = None
        if tag_slug:
            from app.modules.taxonomy.models import Tag

            result = await self.session.execute(select(Tag.id).where(Tag.slug == tag_slug))
            tag_id = result.scalar_one_or_none()
            if tag_id is None:
                return [], 0

        return await self.list_filtered(
            page=page, per_page=per_page, status="published", category_id=category_id, tag_id=tag_id, search=search
        )


class PortfolioCategoryRepository(BaseRepository[PortfolioCategory]):
    model = PortfolioCategory

    async def list_all(self) -> list[PortfolioCategory]:
        result = await self.session.execute(select(PortfolioCategory).order_by(PortfolioCategory.name))
        return list(result.scalars().all())

    async def get_by_name(self, name: str) -> PortfolioCategory | None:
        result = await self.session.execute(select(PortfolioCategory).where(PortfolioCategory.name == name))
        return result.scalar_one_or_none()


class BeforeAfterPairRepository:
    """Not a BaseRepository subclass — before/after pairs are always
    managed as a complete ordered set scoped to one portfolio item
    (replace-all, per the GalleryField/content_media precedent below),
    never fetched/soft-deleted individually."""

    def __init__(self, session):
        self.session = session

    async def replace_all(self, portfolio_item_id: uuid.UUID, pairs: list[dict]) -> list[BeforeAfterPair]:
        await self.session.execute(
            BeforeAfterPair.__table__.delete().where(BeforeAfterPair.portfolio_item_id == portfolio_item_id)
        )
        new_pairs = [
            BeforeAfterPair(
                id=uuid.uuid4(),
                portfolio_item_id=portfolio_item_id,
                before_media_id=pair["before_media_id"],
                after_media_id=pair["after_media_id"],
                caption=pair.get("caption"),
                sort_order=index,
            )
            for index, pair in enumerate(pairs)
        ]
        self.session.add_all(new_pairs)
        await self.session.flush()
        return new_pairs
