"""Portfolio router (Phase 2.3 §6). Mirrors Blog's router shape
(Sprint 4/5) exactly, adding gallery and before/after endpoints."""

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ConflictError, NotFoundError
from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.media.repository import ContentMediaRepository, MediaAssetRepository
from app.infrastructure.storage.service import StorageService, get_storage_service
from app.modules.media.router import resolve_image_urls, serialize_media_asset
from app.modules.portfolio.models import PortfolioCategory
from app.modules.portfolio.repository import (
    BeforeAfterPairRepository,
    PortfolioCategoryRepository,
    PortfolioItemRepository,
)
from app.modules.portfolio.schemas import (
    BeforeAfterPairOut,
    CreatePortfolioCategoryIn,
    CreatePortfolioItemIn,
    PortfolioCategoryOut,
    PortfolioItemListItemOut,
    PortfolioItemOut,
    SchedulePortfolioItemIn,
    SetBeforeAfterPairsIn,
    SetGalleryIn,
    UpdatePortfolioItemIn,
)
from app.modules.portfolio.service import PortfolioService
from app.modules.taxonomy.repository import TagRepository
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope
from app.shared.slug import generate_unique_slug

router = APIRouter(prefix="/portfolio", tags=["portfolio"])


def get_portfolio_service(session: AsyncSession = Depends(get_db_session)) -> PortfolioService:
    return PortfolioService(
        PortfolioItemRepository(session),
        PortfolioCategoryRepository(session),
        TagRepository(session),
        ContentMediaRepository(session),
        BeforeAfterPairRepository(session),
    )


# ── Items ─────────────────────────────────────────────────────────────


@router.get("/items", summary="List portfolio items")
async def list_items(
    request: Request,
    page: int = 1,
    per_page: int = 20,
    status: str | None = None,
    category_id: uuid.UUID | None = None,
    tag_id: uuid.UUID | None = None,
    author_id: uuid.UUID | None = None,
    search: str | None = None,
    featured: bool | None = None,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.view_drafts")),
) -> dict[str, Any]:
    repository = PortfolioItemRepository(session)
    items, total = await repository.list_filtered(
        page=page, per_page=per_page, status=status, category_id=category_id,
        tag_id=tag_id, author_id=author_id, search=search, featured=featured,
    )
    return {
        "data": [PortfolioItemListItemOut.model_validate(i).model_dump(mode="json") for i in items],
        "meta": {
            "page": page, "per_page": per_page, "total": total,
            "total_pages": max(1, (total + per_page - 1) // per_page),
        },
    }


@router.get("/items/check-slug", summary="Check whether a slug is available")
async def check_slug_availability(
    request: Request,
    slug: str,
    exclude_id: uuid.UUID | None = None,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.create")),
) -> dict[str, Any]:
    repository = PortfolioItemRepository(session)
    exists = await repository.slug_exists(slug, exclude_id=exclude_id)
    return success_envelope({"available": not exists}, request)


@router.get("/items/{item_id}", summary="Get a single portfolio item by ID")
async def get_item(
    request: Request,
    item_id: uuid.UUID,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.view_drafts")),
) -> dict[str, Any]:
    repository = PortfolioItemRepository(session)
    item = await repository.get_by_id_full(item_id)
    if item is None:
        raise NotFoundError("Portfolio item not found")
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


@router.post("/items", summary="Create a draft portfolio item")
async def create_item(
    request: Request,
    payload: CreatePortfolioItemIn,
    service: PortfolioService = Depends(get_portfolio_service),
    current_user: CurrentUserOut = Depends(require_permission("content.create")),
) -> dict[str, Any]:
    item = await service.create(current_user.id, payload)
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


@router.patch("/items/{item_id}", summary="Update a portfolio item (also the autosave target)")
async def update_item(
    request: Request,
    item_id: uuid.UUID,
    payload: UpdatePortfolioItemIn,
    service: PortfolioService = Depends(get_portfolio_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    item = await service.update(item_id, payload)
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


@router.delete("/items/{item_id}", status_code=204, summary="Soft-delete a portfolio item")
async def delete_item(
    item_id: uuid.UUID,
    service: PortfolioService = Depends(get_portfolio_service),
    _: CurrentUserOut = Depends(require_permission("content.delete")),
) -> None:
    await service.delete(item_id)


@router.post("/items/{item_id}/restore", summary="Restore a soft-deleted item")
async def restore_item(
    request: Request,
    item_id: uuid.UUID,
    service: PortfolioService = Depends(get_portfolio_service),
    _: CurrentUserOut = Depends(require_permission("content.restore")),
) -> dict[str, Any]:
    item = await service.restore(item_id)
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


# ── Lifecycle ─────────────────────────────────────────────────────────


@router.post("/items/{item_id}/publish", summary="Publish a draft or scheduled item")
async def publish_item(
    request: Request,
    item_id: uuid.UUID,
    service: PortfolioService = Depends(get_portfolio_service),
    current_user: CurrentUserOut = Depends(require_permission("content.publish")),
) -> dict[str, Any]:
    item = await service.publish(item_id, current_user.id)
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


@router.post("/items/{item_id}/unpublish", summary="Revert a published item to draft")
async def unpublish_item(
    request: Request,
    item_id: uuid.UUID,
    service: PortfolioService = Depends(get_portfolio_service),
    _: CurrentUserOut = Depends(require_permission("content.publish")),
) -> dict[str, Any]:
    item = await service.unpublish(item_id)
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


@router.post("/items/{item_id}/schedule", summary="Schedule a draft to publish later")
async def schedule_item(
    request: Request,
    item_id: uuid.UUID,
    payload: SchedulePortfolioItemIn,
    service: PortfolioService = Depends(get_portfolio_service),
    _: CurrentUserOut = Depends(require_permission("content.publish")),
) -> dict[str, Any]:
    item = await service.schedule(item_id, payload.scheduled_at)
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


@router.post("/items/{item_id}/archive", summary="Archive an item")
async def archive_item(
    request: Request,
    item_id: uuid.UUID,
    service: PortfolioService = Depends(get_portfolio_service),
    _: CurrentUserOut = Depends(require_permission("content.delete")),
) -> dict[str, Any]:
    item = await service.archive(item_id)
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


@router.post("/items/{item_id}/restore-from-archive", summary="Restore an archived item to draft")
async def restore_from_archive(
    request: Request,
    item_id: uuid.UUID,
    service: PortfolioService = Depends(get_portfolio_service),
    _: CurrentUserOut = Depends(require_permission("content.restore")),
) -> dict[str, Any]:
    item = await service.restore_from_archive(item_id)
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


@router.post("/items/{item_id}/save-version", summary="Save an explicit revision snapshot")
async def save_version(
    request: Request,
    item_id: uuid.UUID,
    service: PortfolioService = Depends(get_portfolio_service),
    current_user: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    item = await service.save_version(item_id, current_user.id)
    return success_envelope(PortfolioItemOut.model_validate(item).model_dump(mode="json"), request)


# ── Gallery & Before/After ────────────────────────────────────────────


@router.put("/items/{item_id}/gallery", summary="Replace the item's gallery images")
async def set_gallery(
    request: Request,
    item_id: uuid.UUID,
    payload: SetGalleryIn,
    service: PortfolioService = Depends(get_portfolio_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    await service.set_gallery(item_id, payload.media_asset_ids)
    return success_envelope({"media_asset_ids": [str(i) for i in payload.media_asset_ids]}, request)


@router.get("/items/{item_id}/gallery", summary="Get the item's gallery images (Sprint 6 — fixes the same reload-hydration gap Sprint 5 fixed for featured images)")
async def get_gallery(
    request: Request,
    item_id: uuid.UUID,
    session: AsyncSession = Depends(get_db_session),
    storage: StorageService = Depends(get_storage_service),
    _: CurrentUserOut = Depends(require_permission("content.view_drafts")),
) -> dict[str, Any]:
    content_media_repository = ContentMediaRepository(session)
    asset_repository = MediaAssetRepository(session)

    links = await content_media_repository.list_for_entity("portfolio_item", item_id)
    assets = []
    for link in links:
        asset = await asset_repository.get_by_id(link.media_asset_id)
        if asset:
            assets.append(serialize_media_asset(asset, storage))
    return success_envelope(assets, request)


@router.put("/items/{item_id}/before-after", summary="Replace the item's before/after pairs")
async def set_before_after_pairs(
    request: Request,
    item_id: uuid.UUID,
    payload: SetBeforeAfterPairsIn,
    service: PortfolioService = Depends(get_portfolio_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    item = await service.set_before_after_pairs(item_id, [p.model_dump() for p in payload.pairs])
    return success_envelope(
        [BeforeAfterPairOut.model_validate(p).model_dump(mode="json") for p in item.before_after_pairs],
        request,
    )


# ── Categories ────────────────────────────────────────────────────────


@router.get("/categories", summary="List portfolio categories")
async def list_categories(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    repository = PortfolioCategoryRepository(session)
    categories = await repository.list_all()
    return success_envelope(
        [PortfolioCategoryOut.model_validate(c).model_dump(mode="json") for c in categories], request
    )


@router.post("/categories", summary="Create a portfolio category")
async def create_category(
    request: Request,
    payload: CreatePortfolioCategoryIn,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    repository = PortfolioCategoryRepository(session)
    if await repository.get_by_name(payload.name):
        raise ConflictError("A category with this name already exists")

    slug = await generate_unique_slug(session, PortfolioCategory, payload.name)
    category = PortfolioCategory(id=uuid.uuid4(), name=payload.name, slug=slug, description=payload.description)
    session.add(category)
    await session.flush()
    return success_envelope(PortfolioCategoryOut.model_validate(category).model_dump(mode="json"), request)


# ── Public API ────────────────────────────────────────────────────────


@router.get("/public/items", summary="List published portfolio items (public)")
async def list_public_items(
    request: Request,
    page: int = 1,
    per_page: int = 20,
    category: str | None = None,
    tag: str | None = None,
    search: str | None = None,
    featured: bool | None = None,
    session: AsyncSession = Depends(get_db_session),
    storage: StorageService = Depends(get_storage_service),
) -> dict[str, Any]:
    repository = PortfolioItemRepository(session)
    items, total = await repository.list_published(
        page=page, per_page=per_page, category_slug=category, tag_slug=tag, search=search
    )
    if featured is not None:
        items = [i for i in items if i.featured == featured]

    # Sprint 9: batch-resolve featured_image_id -> a real URL so public
    # showcase cards (Homepage's Portfolio Showcase) can actually render
    # images, reusing the same resolver Blog/Services' equivalent public
    # endpoints will use once they need it too.
    image_urls = await resolve_image_urls([i.featured_image_id for i in items], session, storage)

    data = []
    for item in items:
        serialized = PortfolioItemListItemOut.model_validate(item).model_dump(mode="json")
        serialized["featured_image_url"] = image_urls.get(item.featured_image_id)
        data.append(serialized)

    return {
        "data": data,
        "meta": {
            "page": page, "per_page": per_page, "total": total,
            "total_pages": max(1, (total + per_page - 1) // per_page),
        },
    }


@router.get("/public/items/{slug}", summary="Get a published portfolio item by slug, with SEO overrides (public)")
async def get_public_item(
    request: Request,
    slug: str,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    from app.modules.seo.repository import SeoMetadataRepository
    from app.modules.seo.schemas import SeoMetadataOut

    repository = PortfolioItemRepository(session)
    item = await repository.get_by_slug(slug, published_only=True)
    if item is None:
        raise NotFoundError("Portfolio item not found")

    seo_repository = SeoMetadataRepository(session)
    seo_record = await seo_repository.get_for_entity("portfolio_item", item.id)

    data = PortfolioItemOut.model_validate(item).model_dump(mode="json")
    data["seo"] = SeoMetadataOut.model_validate(seo_record).model_dump(mode="json") if seo_record else None
    return success_envelope(data, request)
