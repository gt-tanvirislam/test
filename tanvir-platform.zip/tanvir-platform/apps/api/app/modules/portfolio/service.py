"""
Portfolio service (Phase 2.8 §1). Mirrors BlogService's composition shape
(Sprint 4) — same lifecycle delegation, same slug/tag reuse — proving the
pattern generalizes to a second, more complex content type. The only
genuinely new orchestration is gallery/before-after-pair management,
which delegates to their own repositories rather than being inlined here.
"""

import uuid
from datetime import datetime

from app.core.exceptions import NotFoundError, ValidationError
from app.modules.media.repository import ContentMediaRepository
from app.modules.portfolio.models import PortfolioItem, PortfolioItemRevision
from app.modules.portfolio.repository import (
    BeforeAfterPairRepository,
    PortfolioCategoryRepository,
    PortfolioItemRepository,
)
from app.modules.portfolio.schemas import CreatePortfolioItemIn, UpdatePortfolioItemIn
from app.modules.taxonomy.repository import TagRepository
from app.shared.publishable import ContentLifecycleService, ContentStatus
from app.shared.revision import create_revision
from app.shared.slug import generate_unique_slug


class PortfolioService:
    def __init__(
        self,
        item_repository: PortfolioItemRepository,
        category_repository: PortfolioCategoryRepository,
        tag_repository: TagRepository,
        content_media_repository: ContentMediaRepository,
        before_after_repository: BeforeAfterPairRepository,
        lifecycle: ContentLifecycleService | None = None,
    ):
        self.item_repository = item_repository
        self.category_repository = category_repository
        self.tag_repository = tag_repository
        self.content_media_repository = content_media_repository
        self.before_after_repository = before_after_repository
        self.lifecycle = lifecycle or ContentLifecycleService()

    async def create(self, author_id: uuid.UUID, payload: CreatePortfolioItemIn) -> PortfolioItem:
        slug = payload.slug or await generate_unique_slug(
            self.item_repository.session, PortfolioItem, payload.title
        )
        tags = await self.tag_repository.get_or_create_many(payload.tag_names)

        item = PortfolioItem(
            id=uuid.uuid4(),
            author_id=author_id,
            category_id=payload.category_id,
            title=payload.title,
            slug=slug,
            short_description=payload.short_description,
            full_case_study=payload.full_case_study,
            featured_image_id=payload.featured_image_id,
            client_name=payload.client_name,
            industry=payload.industry,
            project_date=payload.project_date,
            services_used=payload.services_used,
            technologies=payload.technologies,
            is_case_study=payload.is_case_study,
            featured=payload.featured,
            status=ContentStatus.DRAFT.value,
        )
        item.tags = tags

        self.item_repository.session.add(item)
        await self.item_repository.session.flush()
        return item

    async def update(self, item_id: uuid.UUID, payload: UpdatePortfolioItemIn) -> PortfolioItem:
        """Same "autosave and manual edit are the same operation" design
        as BlogService.update (Sprint 4) — see that method's docstring
        for the full rationale, not repeated here."""
        item = await self.item_repository.get_by_id_full(item_id)
        if item is None:
            raise NotFoundError("Portfolio item not found")

        data = payload.model_dump(exclude_unset=True)

        simple_fields = [
            "short_description", "full_case_study", "category_id", "featured_image_id",
            "author_id", "client_name", "industry", "project_date", "services_used",
            "technologies", "is_case_study", "challenge", "solution", "results",
            "results_metrics", "cta_text", "cta_link", "featured",
        ]
        for field in simple_fields:
            if field in data:
                setattr(item, field, data[field])

        if "title" in data and data["title"] is not None:
            item.title = data["title"]
        if "slug" in data and data["slug"]:
            item.slug = await generate_unique_slug(
                self.item_repository.session, PortfolioItem, data["slug"], exclude_id=item.id
            )
        if "tag_names" in data and data["tag_names"] is not None:
            item.tags = await self.tag_repository.get_or_create_many(data["tag_names"])

        await self.item_repository.session.flush()
        return item

    async def delete(self, item_id: uuid.UUID) -> None:
        item = await self.item_repository.get_by_id(item_id)
        if item is None:
            raise NotFoundError("Portfolio item not found")
        await self.item_repository.soft_delete(item)

    async def restore(self, item_id: uuid.UUID) -> PortfolioItem:
        item = await self.item_repository.get_by_id(item_id, include_deleted=True)
        if item is None:
            raise NotFoundError("Portfolio item not found")
        await self.item_repository.restore(item)
        return item

    # ── Lifecycle — identical delegation shape to BlogService ───────────

    async def publish(self, item_id: uuid.UUID, actor_id: uuid.UUID) -> PortfolioItem:
        item = await self.item_repository.get_by_id_full(item_id)
        if item is None:
            raise NotFoundError("Portfolio item not found")

        if not item.featured_image_id or not item.short_description:
            raise ValidationError(
                "Featured image and short description are required to publish",
                fields={
                    "featured_image_id": "Required" if not item.featured_image_id else "",
                    "short_description": "Required" if not item.short_description else "",
                },
            )

        self.lifecycle.publish(item)
        await self._create_revision(item, actor_id)
        await self.item_repository.session.flush()
        return item

    async def unpublish(self, item_id: uuid.UUID) -> PortfolioItem:
        item = await self._get_or_404(item_id)
        self.lifecycle.unpublish(item)
        await self.item_repository.session.flush()
        return item

    async def schedule(self, item_id: uuid.UUID, scheduled_at: datetime) -> PortfolioItem:
        item = await self._get_or_404(item_id)
        self.lifecycle.schedule(item, scheduled_at)
        await self.item_repository.session.flush()
        return item

    async def archive(self, item_id: uuid.UUID) -> PortfolioItem:
        item = await self._get_or_404(item_id)
        self.lifecycle.archive(item)
        await self.item_repository.session.flush()
        return item

    async def restore_from_archive(self, item_id: uuid.UUID) -> PortfolioItem:
        item = await self._get_or_404(item_id)
        self.lifecycle.restore_from_archive(item)
        await self.item_repository.session.flush()
        return item

    async def save_version(self, item_id: uuid.UUID, actor_id: uuid.UUID) -> PortfolioItem:
        item = await self._get_or_404(item_id)
        await self._create_revision(item, actor_id)
        return item

    # ── Gallery & Before/After — the genuinely Portfolio-specific piece ──

    async def set_gallery(self, item_id: uuid.UUID, media_asset_ids: list[uuid.UUID]) -> None:
        await self._get_or_404(item_id)  # 404s if the item doesn't exist, per every other method's contract
        await self.content_media_repository.replace_gallery("portfolio_item", item_id, media_asset_ids)

    async def set_before_after_pairs(self, item_id: uuid.UUID, pairs: list[dict]) -> PortfolioItem:
        await self._get_or_404(item_id)
        await self.before_after_repository.replace_all(item_id, pairs)
        return await self.item_repository.get_by_id_full(item_id)  # re-fetch with pairs eager-loaded

    async def _get_or_404(self, item_id: uuid.UUID) -> PortfolioItem:
        item = await self.item_repository.get_by_id_full(item_id)
        if item is None:
            raise NotFoundError("Portfolio item not found")
        return item

    async def _create_revision(self, item: PortfolioItem, actor_id: uuid.UUID) -> None:
        snapshot = {
            "title": item.title,
            "slug": item.slug,
            "short_description": item.short_description,
            "full_case_study": item.full_case_study,
            "category_id": str(item.category_id) if item.category_id else None,
            "featured_image_id": str(item.featured_image_id) if item.featured_image_id else None,
            "tag_names": [t.name for t in item.tags],
            "client_name": item.client_name,
            "results": item.results,
        }
        create_revision(
            self.item_repository.session,
            PortfolioItemRevision,
            entity_fk_field="portfolio_item_id",
            entity_id=item.id,
            snapshot=snapshot,
            actor_id=actor_id,
        )
