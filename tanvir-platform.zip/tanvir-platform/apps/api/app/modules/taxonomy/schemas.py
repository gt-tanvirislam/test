"""Tag schemas (Phase 2.2 §4.3)."""

import uuid

from pydantic import BaseModel, ConfigDict, Field


class TagOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str


class CreateTagIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)
