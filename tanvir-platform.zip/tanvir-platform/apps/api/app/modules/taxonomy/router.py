"""
Tag router (Phase 2.2 §4.3). Entity-agnostic — this is THE reusable tag
system this sprint requires; Portfolio and any future tagged content
reuses these exact endpoints, never a per-module duplicate.
"""

from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.taxonomy.repository import TagRepository
from app.modules.taxonomy.schemas import CreateTagIn, TagOut
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/tags", tags=["taxonomy"])


@router.get("", summary="List all tags")
async def list_tags(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    # Public read — tags are used for public-facing archive pages
    # (Phase 2.6 §6.1) as much as the dashboard, so no permission gate.
    repository = TagRepository(session)
    tags = await repository.list_all()
    return success_envelope([TagOut.model_validate(t).model_dump(mode="json") for t in tags], request)


@router.post("", summary="Create a tag (or return the existing one with that name)")
async def create_tag(
    request: Request,
    payload: CreateTagIn,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.create")),
) -> dict[str, Any]:
    repository = TagRepository(session)
    tag = await repository.get_or_create(payload.name)
    return success_envelope(TagOut.model_validate(tag).model_dump(mode="json"), request)
