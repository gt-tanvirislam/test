"""
Shared Tag model (Phase 2.2 §4.3): "a single shared `tags` table... both
content types reference the same tags table via their own join tables."
Blog's `blog_post_tags` join is defined in modules/blog/models.py;
Portfolio adds `portfolio_item_tags` referencing this same table when
that module is built — no second tags table, ever.
"""

import uuid

from sqlalchemy import String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class Tag(Base):
    __tablename__ = "tags"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String, unique=True, nullable=False)
