"""
Tag repository (Phase 2.2 §4.3, Phase 2.8 §3). Not extending
BaseRepository — Tag has no soft-delete/audit fields (a lightweight
shared lookup table), so BaseRepository's soft-delete-aware queries don't
apply cleanly; kept intentionally small rather than forcing an
ill-fitting inheritance.
"""

import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.taxonomy.models import Tag
from app.shared.slug import slugify


class TagRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def list_all(self) -> list[Tag]:
        result = await self.session.execute(select(Tag).order_by(Tag.name))
        return list(result.scalars().all())

    async def get_by_name(self, name: str) -> Tag | None:
        result = await self.session.execute(select(Tag).where(Tag.name == name))
        return result.scalar_one_or_none()

    async def get_or_create(self, name: str) -> Tag:
        existing = await self.get_by_name(name)
        if existing:
            return existing

        tag = Tag(id=uuid.uuid4(), name=name, slug=slugify(name))
        self.session.add(tag)
        await self.session.flush()
        return tag

    async def get_or_create_many(self, names: list[str]) -> list[Tag]:
        """Used by BlogService when saving a post's tag list — resolves a
        list of tag name strings (what the frontend TagInput sends) into
        real Tag rows, creating any that don't exist yet."""
        return [await self.get_or_create(name) for name in names]

    async def get_by_ids(self, tag_ids: list[uuid.UUID]) -> list[Tag]:
        if not tag_ids:
            return []
        result = await self.session.execute(select(Tag).where(Tag.id.in_(tag_ids)))
        return list(result.scalars().all())
