"""User repository (Phase 2.8 §3, §4). Extends BaseRepository; adds only
the custom queries this module actually needs — no speculative methods."""

import uuid

from sqlalchemy import or_, select
from sqlalchemy.orm import selectinload

from app.modules.users.models import Role, User
from app.shared.repository_base import BaseRepository


class UserRepository(BaseRepository[User]):
    model = User

    async def get_by_id_with_roles(self, user_id: uuid.UUID) -> User | None:
        """Eager-loads roles + permissions in one query (Phase 2.8 §14's
        N+1 prevention rule) — this is called on every authenticated
        request via get_current_user, so it must not fan out into
        separate queries per role."""
        stmt = (
            select(User)
            .where(User.id == user_id, User.deleted_at.is_(None))
            .options(selectinload(User.roles).selectinload(Role.permissions))
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_email(self, email: str) -> User | None:
        stmt = select(User).where(User.email == email, User.deleted_at.is_(None))
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def search_active(self, search: str | None = None, limit: int = 50) -> list[User]:
        """Backs the author filter/selector (Sprint 5). Deliberately
        separate from the generic BaseRepository.list() — this needs an
        ILIKE search across two columns (name OR email), which doesn't
        fit BaseRepository's equality-filter dict, matching the same
        pattern BlogPostRepository.list_filtered already established for
        its own search requirement."""
        stmt = select(User).where(User.deleted_at.is_(None), User.status == "active")
        if search:
            pattern = f"%{search}%"
            stmt = stmt.where(or_(User.full_name.ilike(pattern), User.email.ilike(pattern)))
        stmt = stmt.order_by(User.full_name).limit(limit).options(selectinload(User.roles))
        result = await self.session.execute(stmt)
        return list(result.scalars().all())
