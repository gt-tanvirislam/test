"""User service (Phase 2.8 §1). Orchestrates the use case of resolving a
full CurrentUser (roles + flattened permission keys) from a user ID —
called by the auth dependency on every protected request."""

import uuid

from app.core.exceptions import NotFoundError
from app.modules.users.repository import UserRepository
from app.modules.users.schemas import CurrentUserOut


class UserService:
    def __init__(self, repository: UserRepository):
        self.repository = repository

    async def get_current_user(self, user_id: uuid.UUID) -> CurrentUserOut:
        user = await self.repository.get_by_id_with_roles(user_id)
        if user is None:
            raise NotFoundError("User not found")

        role_names = [role.name for role in user.roles]
        # Flatten permissions across all of the user's roles, deduplicated —
        # matches Phase 2.2 §4.1's "a user can hold more than one role"
        # design; a permission granted by ANY held role applies.
        permission_keys = sorted(
            {permission.key for role in user.roles for permission in role.permissions}
        )

        return CurrentUserOut(
            id=user.id,
            email=user.email,
            full_name=user.full_name,
            avatar_url=None,  # resolved from media_assets once the Media module exists
            roles=role_names,
            permissions=permission_keys,
        )
