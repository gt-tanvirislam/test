"""Request/response schemas for the users module (Phase 2.3 §4)."""

import uuid

from pydantic import BaseModel, ConfigDict


class RoleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str


class CurrentUserOut(BaseModel):
    """Matches packages/types/src/auth.ts's CurrentUser shape exactly —
    the frontend and backend contracts are kept in sync manually for now
    (Sprint 0 flagged this as a possible future codegen step)."""

    id: uuid.UUID
    email: str
    full_name: str
    avatar_url: str | None
    roles: list[str]
    permissions: list[str]


class UserSummaryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    email: str
    full_name: str
    status: str
    roles: list[str]
