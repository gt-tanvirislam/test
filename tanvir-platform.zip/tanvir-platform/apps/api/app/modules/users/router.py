"""
Users router (Sprint 5's §2 — author filter/selector support).

Deliberately a lightweight, broadly-accessible list distinct from full
user *management* (Phase 2.4 §10 — invite/suspend/role-editing, still
owner-only and not built until a dedicated Users-management sprint).
Any authenticated dashboard user with `content.view_drafts` can see
author names to filter/attribute content by — that's a much lower bar
than `users.manage`, and conflating the two would block every editor
from using the author filter at all.
"""

from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.users.repository import UserRepository
from app.modules.users.schemas import CurrentUserOut, UserSummaryOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/users", tags=["users"])


@router.get("", summary="List active users (for author filters/selectors)")
async def list_users(
    request: Request,
    search: str | None = None,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.view_drafts")),
) -> dict[str, Any]:
    repository = UserRepository(session)
    users = await repository.search_active(search)
    data = [
        UserSummaryOut(
            id=u.id, email=u.email, full_name=u.full_name, status=u.status, roles=[r.name for r in u.roles]
        ).model_dump(mode="json")
        for u in users
    ]
    return success_envelope(data, request)
