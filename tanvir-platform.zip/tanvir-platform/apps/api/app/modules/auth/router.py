"""
Auth router (Phase 2.3 §3). `/auth/me` is the only endpoint this module
owns — actual login/logout/password-reset are handled directly by the
Supabase Auth client SDK from the frontend (Phase 2.8 §5 — "the backend
never stores or handles raw passwords"), so there's no
`/auth/login`-equivalent route here to duplicate that.
"""

from typing import Any

from fastapi import APIRouter, Depends, Request

from app.core.permissions import get_current_user
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/auth", tags=["auth"])


@router.get("/me", summary="Get the currently authenticated user", description=(
    "Returns the authenticated user's profile, roles, and flattened permission "
    "keys, resolved from the Supabase-issued JWT."
))
async def read_current_user(
    request: Request,
    current_user: CurrentUserOut = Depends(get_current_user),
) -> dict[str, Any]:
    return success_envelope(current_user.model_dump(mode="json"), request)
