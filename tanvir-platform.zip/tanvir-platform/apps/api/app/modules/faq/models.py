"""FAQ model.

Owner-authored question/answer pairs shown on the public site (Contact,
Services, or a dedicated FAQ section). `is_published` gates public
visibility; `sort_order` gives manual ordering. Same soft-delete + audit
composition as the other lightweight content types.
"""

import uuid

from sqlalchemy import Boolean, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import AuditMixin, Base, SoftDeleteMixin


class FAQItem(Base, AuditMixin, SoftDeleteMixin):
    __tablename__ = "faq_items"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    question: Mapped[str] = mapped_column(String(500), nullable=False)
    answer: Mapped[str] = mapped_column(Text, nullable=False)

    # Optional grouping label (e.g. "Pricing", "Process") so the public UI can
    # section the list. Free-text, validated only for length.
    category: Mapped[str | None] = mapped_column(String(120), nullable=True)

    is_published: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
