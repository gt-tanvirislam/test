"""FAQ repository. BaseRepository for soft-delete + get_by_id; ordered list
helpers for dashboard (all) and public (published only)."""

import uuid
from typing import Any

from sqlalchemy import select

from app.modules.faq.models import FAQItem
from app.shared.repository_base import BaseRepository


class FAQRepository(BaseRepository[FAQItem]):
    model = FAQItem

    async def create(self, **fields: Any) -> FAQItem:
        item = FAQItem(id=uuid.uuid4(), **fields)
        self.session.add(item)
        await self.session.flush()
        return item

    async def list_all(self) -> list[FAQItem]:
        stmt = (
            select(FAQItem)
            .where(FAQItem.deleted_at.is_(None))
            .order_by(FAQItem.sort_order.asc(), FAQItem.created_at.desc())
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def list_published(self) -> list[FAQItem]:
        stmt = (
            select(FAQItem)
            .where(FAQItem.deleted_at.is_(None), FAQItem.is_published.is_(True))
            .order_by(FAQItem.sort_order.asc(), FAQItem.created_at.desc())
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())
