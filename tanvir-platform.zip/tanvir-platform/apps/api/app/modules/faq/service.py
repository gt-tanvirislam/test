"""FAQ service. Create, partial update, soft-delete, and the two read paths."""

import uuid

from app.core.exceptions import NotFoundError
from app.modules.faq.models import FAQItem
from app.modules.faq.repository import FAQRepository
from app.modules.faq.schemas import CreateFAQItemIn, UpdateFAQItemIn


class FAQService:
    def __init__(self, repository: FAQRepository):
        self.repository = repository

    async def create(self, payload: CreateFAQItemIn) -> FAQItem:
        data = payload.model_dump()
        data["question"] = data["question"].strip()
        data["answer"] = data["answer"].strip()
        return await self.repository.create(**data)

    async def update(self, item_id: uuid.UUID, payload: UpdateFAQItemIn) -> FAQItem:
        item = await self.get(item_id)
        provided = payload.model_dump(include=payload.model_fields_set)
        for field, value in provided.items():
            if field in ("question", "answer") and isinstance(value, str):
                value = value.strip()
            setattr(item, field, value)
        await self.repository.session.flush()
        return item

    async def get(self, item_id: uuid.UUID) -> FAQItem:
        item = await self.repository.get_by_id(item_id)
        if item is None:
            raise NotFoundError("FAQ item not found")
        return item

    async def list_all(self) -> list[FAQItem]:
        return await self.repository.list_all()

    async def list_published(self) -> list[FAQItem]:
        return await self.repository.list_published()

    async def delete(self, item_id: uuid.UUID) -> None:
        item = await self.get(item_id)
        await self.repository.soft_delete(item)
