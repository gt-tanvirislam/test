"""FAQ router.

Public: `GET /faq` returns published items only (empty list when none).
Management: full CRUD gated by `faq.view` (reads) / `faq.manage` (writes).
"""

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.faq.repository import FAQRepository
from app.modules.faq.schemas import (
    CreateFAQItemIn,
    FAQItemOut,
    PublicFAQItemOut,
    UpdateFAQItemIn,
)
from app.modules.faq.service import FAQService
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/faq", tags=["faq"])


def get_faq_service(session: AsyncSession = Depends(get_db_session)) -> FAQService:
    return FAQService(FAQRepository(session))


# ── Public ────────────────────────────────────────────────────────────


@router.get("", summary="List published FAQ items (public)")
async def list_public_faq(
    request: Request,
    service: FAQService = Depends(get_faq_service),
) -> dict[str, Any]:
    items = await service.list_published()
    return success_envelope(
        [PublicFAQItemOut.model_validate(i).model_dump(mode="json") for i in items],
        request,
    )


# ── Management ────────────────────────────────────────────────────────


@router.get("/manage", summary="List all FAQ items (dashboard)")
async def list_all_faq(
    request: Request,
    service: FAQService = Depends(get_faq_service),
    _: CurrentUserOut = Depends(require_permission("faq.view")),
) -> dict[str, Any]:
    items = await service.list_all()
    return success_envelope(
        [FAQItemOut.model_validate(i).model_dump(mode="json") for i in items], request
    )


@router.get("/manage/{item_id}", summary="Get a single FAQ item (dashboard)")
async def get_faq_item(
    request: Request,
    item_id: uuid.UUID,
    service: FAQService = Depends(get_faq_service),
    _: CurrentUserOut = Depends(require_permission("faq.view")),
) -> dict[str, Any]:
    item = await service.get(item_id)
    return success_envelope(FAQItemOut.model_validate(item).model_dump(mode="json"), request)


@router.post("/manage", summary="Create an FAQ item", status_code=201)
async def create_faq_item(
    request: Request,
    payload: CreateFAQItemIn,
    service: FAQService = Depends(get_faq_service),
    _: CurrentUserOut = Depends(require_permission("faq.manage")),
) -> dict[str, Any]:
    item = await service.create(payload)
    return success_envelope(FAQItemOut.model_validate(item).model_dump(mode="json"), request)


@router.patch("/manage/{item_id}", summary="Update an FAQ item")
async def update_faq_item(
    request: Request,
    item_id: uuid.UUID,
    payload: UpdateFAQItemIn,
    service: FAQService = Depends(get_faq_service),
    _: CurrentUserOut = Depends(require_permission("faq.manage")),
) -> dict[str, Any]:
    item = await service.update(item_id, payload)
    return success_envelope(FAQItemOut.model_validate(item).model_dump(mode="json"), request)


@router.delete("/manage/{item_id}", summary="Delete an FAQ item", status_code=204)
async def delete_faq_item(
    item_id: uuid.UUID,
    service: FAQService = Depends(get_faq_service),
    _: CurrentUserOut = Depends(require_permission("faq.manage")),
) -> None:
    await service.delete(item_id)
