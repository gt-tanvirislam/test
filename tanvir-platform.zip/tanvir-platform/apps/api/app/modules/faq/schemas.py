"""FAQ schemas. Full dashboard read shape (`FAQItemOut`), trimmed public
shape (`PublicFAQItemOut`), and create/partial-update write shapes."""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class CreateFAQItemIn(BaseModel):
    question: str = Field(..., min_length=1, max_length=500)
    answer: str = Field(..., min_length=1, max_length=5000)
    category: str | None = Field(default=None, max_length=120)
    is_published: bool = False
    sort_order: int = 0


class UpdateFAQItemIn(BaseModel):
    question: str | None = Field(default=None, min_length=1, max_length=500)
    answer: str | None = Field(default=None, min_length=1, max_length=5000)
    category: str | None = Field(default=None, max_length=120)
    is_published: bool | None = None
    sort_order: int | None = None


class FAQItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    question: str
    answer: str
    category: str | None
    is_published: bool
    sort_order: int
    created_at: datetime
    updated_at: datetime


class PublicFAQItemOut(BaseModel):
    """Public projection — internal flags and timestamps omitted."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    question: str
    answer: str
    category: str | None
