"""
Media models (Phase 2.2 §4.5). Second concrete module after Users — the
first to exercise SoftDeleteMixin's `deleted_at` in a real feature (safe
delete with usage-tracking, per Phase 2.4 §8).
"""

import uuid

from sqlalchemy import BigInteger, ForeignKey, Index, Integer, String, text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import AuditMixin, Base, SoftDeleteMixin

# Seed folders per Phase 2.2 §4.5 — created by the migration, referenced
# here only for the type.
MEDIA_FOLDER_NAMES = [
    "Images",
    "Videos",
    "Documents",
    "Blog Media",
    "Portfolio Media",
    "Gallery",
    "Temporary Uploads",
    "Profile Images",
]


class MediaFolder(Base):
    __tablename__ = "media_folders"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String, nullable=False)
    parent_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("media_folders.id", ondelete="CASCADE"), nullable=True
    )


class MediaAsset(Base, AuditMixin, SoftDeleteMixin):
    __tablename__ = "media_assets"
    # Partial unique index (Sprint 10 BUG-3 fix): identical content is
    # deduplicated only among LIVE, CONFIRMED assets. Pending uploads carry a
    # NULL hash — many can be in flight at once, since NULLs are distinct in a
    # unique index — and soft-deleted rows are excluded, so re-uploading
    # content identical to a trashed asset is allowed. This matches
    # MediaAssetRepository.get_by_hash's `deleted_at IS NULL` filter exactly,
    # which the old table-wide UNIQUE(file_hash) did not: pending rows all
    # shared file_hash="" (so the second concurrent upload hit an
    # IntegrityError), and a soft-deleted duplicate blocked re-upload at the
    # DB even though the app-level check would have allowed it.
    __table_args__ = (
        Index(
            "uq_media_assets_file_hash",
            "file_hash",
            unique=True,
            postgresql_where=text("file_hash IS NOT NULL AND deleted_at IS NULL"),
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    folder_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("media_folders.id", ondelete="SET NULL"), nullable=True
    )
    storage_path: Mapped[str] = mapped_column(String, nullable=False)
    file_name: Mapped[str] = mapped_column(String, nullable=False)
    mime_type: Mapped[str] = mapped_column(String, nullable=False)
    file_size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    # NULL until confirm_upload finalizes it (Sprint 10 BUG-3 fix). See the
    # partial unique index in __table_args__ for why pending = NULL matters.
    file_hash: Mapped[str | None] = mapped_column(String, nullable=True)
    alt_text: Mapped[str | None] = mapped_column(String, nullable=True)
    width: Mapped[int | None] = mapped_column(Integer, nullable=True)
    height: Mapped[int | None] = mapped_column(Integer, nullable=True)
    duration_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)

    variants: Mapped[list["MediaVariant"]] = relationship(back_populates="media_asset", cascade="all, delete-orphan")


class MediaVariant(Base):
    __tablename__ = "media_variants"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    media_asset_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("media_assets.id", ondelete="CASCADE"), nullable=False
    )
    variant_label: Mapped[str] = mapped_column(String, nullable=False)  # thumb/medium/large/webp
    storage_path: Mapped[str] = mapped_column(String, nullable=False)
    width: Mapped[int | None] = mapped_column(Integer, nullable=True)
    height: Mapped[int | None] = mapped_column(Integer, nullable=True)

    media_asset: Mapped[MediaAsset] = relationship(back_populates="variants")


class ContentMedia(Base):
    """Polymorphic join — links any media asset to any content record
    (Phase 2.2 §4.5). No content tables exist yet (Blog/Portfolio are
    future sprints), but this table is needed now so the usage-tracking
    endpoint (Phase 2.3 §8) has something real to query, even if it
    returns an empty list until content modules populate it."""

    __tablename__ = "content_media"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    media_asset_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("media_assets.id", ondelete="CASCADE"), nullable=False
    )
    entity_type: Mapped[str] = mapped_column(String, nullable=False)
    entity_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    role: Mapped[str | None] = mapped_column(String, nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
