"""Request/response schemas for the media module (Phase 2.3 §8)."""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class MediaFolderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    parent_id: uuid.UUID | None


class MediaVariantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    variant_label: str
    storage_path: str
    width: int | None
    height: int | None


class MediaAssetOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    folder_id: uuid.UUID | None
    storage_path: str
    file_name: str
    mime_type: str
    file_size_bytes: int
    alt_text: str | None
    width: int | None
    height: int | None
    duration_seconds: int | None
    created_at: datetime
    variants: list[MediaVariantOut] = []
    public_url: str = ""  # populated by the router (needs the storage service), not a DB column


class RequestUploadUrlIn(BaseModel):
    file_name: str = Field(..., min_length=1, max_length=255)
    mime_type: str = Field(..., min_length=1)
    folder_id: uuid.UUID | None = None


class RequestUploadUrlOut(BaseModel):
    upload_url: str
    storage_path: str
    pending_asset_id: uuid.UUID


class ConfirmUploadIn(BaseModel):
    pending_asset_id: uuid.UUID
    file_size_bytes: int = Field(..., gt=0)
    alt_text: str | None = None


class UpdateMediaAssetIn(BaseModel):
    alt_text: str | None = None
    folder_id: uuid.UUID | None = None


class MediaUsageOut(BaseModel):
    entity_type: str
    entity_id: uuid.UUID
    role: str | None
