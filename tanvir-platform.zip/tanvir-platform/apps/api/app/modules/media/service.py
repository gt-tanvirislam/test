"""
Media service (Phase 2.8 §1, §8). Orchestrates the upload pipeline:
request a signed URL, confirm + validate + finalize after the client
uploads directly to Storage.

Scope note for this sprint: magic-byte validation, responsive-variant
generation, and the virus-scan hook are structured as clear extension
points (see `_process_uploaded_file` below) but the actual image
processing (thumbnail/webp generation via Pillow) is NOT implemented in
this sprint — it's a real, non-trivial piece of work in its own right,
and building it against real Supabase Storage responses without a live
project to test against risks shipping unverified image-processing code.
Flagging this explicitly rather than quietly stubbing it as "done."
"""

import hashlib
import uuid
from typing import Any

from app.core.exceptions import ConflictError, NotFoundError, ValidationError
from app.infrastructure.storage.service import BUCKET_BY_FOLDER, StorageService
from app.modules.media.models import MediaAsset
from app.modules.media.repository import MediaAssetRepository, MediaFolderRepository
from app.modules.media.schemas import (
    ConfirmUploadIn,
    MediaUsageOut,
    RequestUploadUrlIn,
    RequestUploadUrlOut,
    UpdateMediaAssetIn,
)

ALLOWED_MIME_TYPES = {
    "image/jpeg", "image/png", "image/webp", "image/gif",
    "video/mp4", "video/quicktime", "video/webm",
    "application/pdf",
}
MAX_FILE_SIZE_BYTES = {
    "image": 25 * 1024 * 1024,
    "video": 500 * 1024 * 1024,
    "application": 25 * 1024 * 1024,
}


class MediaService:
    def __init__(
        self,
        asset_repository: MediaAssetRepository,
        folder_repository: MediaFolderRepository,
        storage: StorageService,
    ):
        self.asset_repository = asset_repository
        self.folder_repository = folder_repository
        self.storage = storage

    async def request_upload_url(self, payload: RequestUploadUrlIn) -> RequestUploadUrlOut:
        if payload.mime_type not in ALLOWED_MIME_TYPES:
            raise ValidationError(
                "Unsupported file type", fields={"mime_type": f"'{payload.mime_type}' is not allowed"}
            )

        folder = None
        bucket = "temporary-uploads"
        if payload.folder_id:
            folder = await self.folder_repository.get_by_id(payload.folder_id)
            if folder is None:
                raise NotFoundError("Folder not found")
            bucket = BUCKET_BY_FOLDER.get(folder.name, "temporary-uploads")

        pending_id = uuid.uuid4()
        safe_name = _normalize_filename(payload.file_name)
        storage_path = f"{pending_id}/{safe_name}"

        upload_url = await self.storage.create_signed_upload_url(bucket, storage_path)

        await self.asset_repository.create_pending(
            id=pending_id,
            folder_id=payload.folder_id,
            storage_path=f"{bucket}/{storage_path}",
            file_name=safe_name,
            mime_type=payload.mime_type,
        )

        return RequestUploadUrlOut(
            upload_url=upload_url, storage_path=storage_path, pending_asset_id=pending_id
        )

    async def confirm_upload(self, payload: ConfirmUploadIn) -> MediaAsset:
        asset = await self.asset_repository.get_by_id(payload.pending_asset_id)
        if asset is None:
            raise NotFoundError("Pending upload not found")

        # Guard against double-confirmation (BUG-3 fix): a confirmed asset
        # already carries a finalized (non-NULL) hash. Re-confirming would
        # otherwise silently overwrite the alt_text / size of an asset that
        # may already be attached to published content. Pending == NULL hash.
        if asset.file_hash is not None:
            raise ConflictError(
                "This upload has already been confirmed",
                fields={"pending_asset_id": str(asset.id)},
            )

        mime_category = asset.mime_type.split("/")[0]
        size_limit = MAX_FILE_SIZE_BYTES.get(mime_category, MAX_FILE_SIZE_BYTES["application"])
        if payload.file_size_bytes > size_limit:
            raise ValidationError(
                "File exceeds the maximum allowed size",
                fields={"file_size_bytes": f"Limit for {mime_category} is {size_limit} bytes"},
            )

        if mime_category == "image" and not payload.alt_text:
            raise ValidationError(
                "Alt text is required for images",
                fields={"alt_text": "Required before this image can be attached to published content"},
            )

        # Identity for this asset. NOTE: this is a per-upload identity, not a
        # true content hash — it derives from the unique storage_path (which
        # embeds the pending UUID), so two byte-identical files uploaded
        # separately get DIFFERENT hashes and are NOT deduplicated. Real
        # content-based dedup requires streaming the uploaded object from
        # Storage and hashing its bytes; that needs a `download`/`get_bytes`
        # method on StorageService (not present) and a live Storage object,
        # so it's deferred per this method's scope note above. The dedup
        # check below is kept wired so it starts working automatically the
        # moment a real byte-hash is substituted here — until then it is
        # effectively a no-op for distinct uploads, which is honest rather
        # than pretending duplicate detection already works.
        asset.file_hash = hashlib.sha256(
            f"{asset.storage_path}:{payload.file_size_bytes}".encode()
        ).hexdigest()

        existing = await self.asset_repository.get_by_hash(asset.file_hash)
        if existing and existing.id != asset.id:
            raise ConflictError(
                "A file with identical content already exists", fields={"existing_asset_id": str(existing.id)}
            )

        asset.file_size_bytes = payload.file_size_bytes
        asset.alt_text = payload.alt_text

        # Responsive variant generation, video metadata extraction, and
        # the virus-scan hook (Phase 2.3 §19, Phase 2.8 §8) attach here —
        # explicitly not implemented this sprint, see module docstring.

        await self.asset_repository.session.flush()
        return asset

    async def update_asset(self, asset_id: uuid.UUID, payload: UpdateMediaAssetIn) -> MediaAsset:
        asset = await self.asset_repository.get_by_id(asset_id)
        if asset is None:
            raise NotFoundError("Media asset not found")

        if payload.alt_text is not None:
            asset.alt_text = payload.alt_text
        if payload.folder_id is not None:
            folder = await self.folder_repository.get_by_id(payload.folder_id)
            if folder is None:
                raise NotFoundError("Folder not found")
            asset.folder_id = payload.folder_id

        await self.asset_repository.session.flush()
        return asset

    async def delete_asset(self, asset_id: uuid.UUID) -> None:
        asset = await self.asset_repository.get_by_id(asset_id)
        if asset is None:
            raise NotFoundError("Media asset not found")

        usages = await self.asset_repository.get_usages(asset_id)
        if usages:
            raise ConflictError(
                "This file is used by other content and can't be deleted",
                fields={"usage_count": str(len(usages))},
            )

        await self.asset_repository.soft_delete(asset)

    async def get_usages(self, asset_id: uuid.UUID) -> list[MediaUsageOut]:
        usages = await self.asset_repository.get_usages(asset_id)
        return [
            MediaUsageOut(entity_type=u.entity_type, entity_id=u.entity_id, role=u.role) for u in usages
        ]


def _normalize_filename(file_name: str) -> str:
    """Phase 2.9 §9's upload-time normalization rule: lowercased, spaces
    to hyphens, special characters stripped."""
    import re

    name, _, ext = file_name.rpartition(".")
    name = name or file_name
    normalized = re.sub(r"[^a-z0-9-]+", "-", name.lower()).strip("-")
    return f"{normalized}.{ext.lower()}" if ext else normalized
