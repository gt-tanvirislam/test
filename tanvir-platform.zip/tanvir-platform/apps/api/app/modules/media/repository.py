"""Media repository (Phase 2.8 §3, §4)."""

import uuid

from sqlalchemy import select

from app.modules.media.models import ContentMedia, MediaAsset, MediaFolder
from app.shared.repository_base import BaseRepository


class MediaAssetRepository(BaseRepository[MediaAsset]):
    model = MediaAsset

    async def get_by_hash(self, file_hash: str) -> MediaAsset | None:
        stmt = select(MediaAsset).where(MediaAsset.file_hash == file_hash, MediaAsset.deleted_at.is_(None))
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_ids(self, asset_ids: list[uuid.UUID]) -> list[MediaAsset]:
        """Batch lookup (Sprint 9) — mirrors TagRepository.get_by_ids'
        existing pattern (Sprint 4). Used by public content list
        endpoints (Portfolio's homepage showcase) to resolve a page of
        featured_image_id values into real assets in one query instead
        of N+1 per-item lookups."""
        if not asset_ids:
            return []
        stmt = select(MediaAsset).where(MediaAsset.id.in_(asset_ids), MediaAsset.deleted_at.is_(None))
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def get_usages(self, media_asset_id: uuid.UUID) -> list[ContentMedia]:
        """Backs the usage-tracking endpoint (Phase 2.3 §8) — returns an
        empty list until content modules (Blog/Portfolio) exist to write
        content_media rows, which is expected and correct at this stage."""
        stmt = select(ContentMedia).where(ContentMedia.media_asset_id == media_asset_id)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def create_pending(
        self,
        *,
        id: uuid.UUID,
        folder_id: uuid.UUID | None,
        storage_path: str,
        file_name: str,
        mime_type: str,
    ) -> MediaAsset:
        asset = MediaAsset(
            id=id,
            folder_id=folder_id,
            storage_path=storage_path,
            file_name=file_name,
            mime_type=mime_type,
            file_size_bytes=0,  # finalized in confirm_upload once the real size is known
            file_hash=None,  # NULL while pending — finalized in confirm_upload (BUG-3 fix)
        )
        self.session.add(asset)
        await self.session.flush()
        return asset


class MediaFolderRepository(BaseRepository[MediaFolder]):
    model = MediaFolder

    async def list_all(self) -> list[MediaFolder]:
        result = await self.session.execute(select(MediaFolder))
        return list(result.scalars().all())


class ContentMediaRepository:
    """
    Manages the polymorphic content_media join table (Phase 2.2 §4.5).
    Sprint 6 is the first real consumer — Portfolio's gallery — proving
    out the "any future gallery reuses this table" decision made when
    content_media was first created in Sprint 2, rather than Portfolio
    inventing its own gallery table.
    """

    def __init__(self, session):
        self.session = session

    async def list_for_entity(self, entity_type: str, entity_id: uuid.UUID) -> list[ContentMedia]:
        stmt = (
            select(ContentMedia)
            .where(ContentMedia.entity_type == entity_type, ContentMedia.entity_id == entity_id)
            .order_by(ContentMedia.sort_order)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def replace_gallery(
        self, entity_type: str, entity_id: uuid.UUID, media_asset_ids: list[uuid.UUID]
    ) -> list[ContentMedia]:
        """Replace-all semantics — matches how GalleryField (Sprint 3)
        already sends its full ordered list on every change, so a
        replace is simpler and less error-prone than diffing add/remove."""
        await self.session.execute(
            ContentMedia.__table__.delete().where(
                ContentMedia.entity_type == entity_type, ContentMedia.entity_id == entity_id
            )
        )
        rows = [
            ContentMedia(
                id=uuid.uuid4(),
                media_asset_id=media_asset_id,
                entity_type=entity_type,
                entity_id=entity_id,
                role="gallery",
                sort_order=index,
            )
            for index, media_asset_id in enumerate(media_asset_ids)
        ]
        self.session.add_all(rows)
        await self.session.flush()
        return rows
