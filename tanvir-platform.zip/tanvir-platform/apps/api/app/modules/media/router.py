"""Media router (Phase 2.3 §8)."""

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundError
from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.infrastructure.storage.service import StorageService, get_storage_service
from app.modules.media.repository import MediaAssetRepository, MediaFolderRepository
from app.modules.media.schemas import (
    ConfirmUploadIn,
    MediaAssetOut,
    MediaFolderOut,
    RequestUploadUrlIn,
    RequestUploadUrlOut,
    UpdateMediaAssetIn,
)
from app.modules.media.service import MediaService
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/media", tags=["media"])


def serialize_media_asset(asset: Any, storage: StorageService) -> dict[str, Any]:
    """storage_path is stored as `{bucket}/{path}` (Phase 2.8 §8) — split
    it back apart to resolve a public URL through the single storage
    abstraction (Phase 2.7 §12's getMediaUrl() equivalent, backend side).
    Public (not `_`-prefixed) since Sprint 6's Portfolio gallery endpoint
    reuses this rather than duplicating asset serialization."""
    out = MediaAssetOut.model_validate(asset).model_dump(mode="json")
    bucket, _, path = asset.storage_path.partition("/")
    out["public_url"] = storage.get_public_url(bucket, path) if path else ""
    return out


async def resolve_image_urls(
    asset_ids: list[uuid.UUID],
    session: AsyncSession,
    storage: StorageService,
) -> dict[uuid.UUID, str]:
    """Batch-resolves a page of featured_image_id values into public
    URLs in one query (Sprint 9 — public content list endpoints use this
    to enrich their responses without an N+1 per item). Returns a dict
    so callers look up `resolved.get(item.featured_image_id)` and get
    `None` gracefully for anything unresolved, rather than every caller
    re-implementing the batching."""
    repository = MediaAssetRepository(session)
    assets = await repository.get_by_ids([aid for aid in asset_ids if aid is not None])
    return {asset.id: serialize_media_asset(asset, storage)["public_url"] for asset in assets}


def get_media_service(
    session: AsyncSession = Depends(get_db_session),
    storage: StorageService = Depends(get_storage_service),
) -> MediaService:
    return MediaService(MediaAssetRepository(session), MediaFolderRepository(session), storage)


@router.post("/upload-url", summary="Request a signed upload URL")
async def request_upload_url(
    request: Request,
    payload: RequestUploadUrlIn,
    service: MediaService = Depends(get_media_service),
    _: CurrentUserOut = Depends(require_permission("media.upload")),
) -> dict[str, Any]:
    result = await service.request_upload_url(payload)
    return success_envelope(RequestUploadUrlOut.model_validate(result).model_dump(mode="json"), request)


@router.post("/confirm", summary="Confirm and finalize an upload")
async def confirm_upload(
    request: Request,
    payload: ConfirmUploadIn,
    service: MediaService = Depends(get_media_service),
    storage: StorageService = Depends(get_storage_service),
    _: CurrentUserOut = Depends(require_permission("media.upload")),
) -> dict[str, Any]:
    asset = await service.confirm_upload(payload)
    return success_envelope(serialize_media_asset(asset, storage), request)


@router.get("/assets", summary="List media assets")
async def list_assets(
    request: Request,
    page: int = 1,
    per_page: int = 20,
    folder_id: uuid.UUID | None = None,
    session: AsyncSession = Depends(get_db_session),
    storage: StorageService = Depends(get_storage_service),
    _: CurrentUserOut = Depends(require_permission("media.manage")),
) -> dict[str, Any]:
    repository = MediaAssetRepository(session)
    filters = {"folder_id": folder_id} if folder_id else None
    items, total = await repository.list(page=page, per_page=per_page, filters=filters)
    return {
        "data": [serialize_media_asset(item, storage) for item in items],
        "meta": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "total_pages": max(1, (total + per_page - 1) // per_page),
        },
    }


@router.get("/assets/{asset_id}", summary="Get a single media asset")
async def get_asset(
    request: Request,
    asset_id: uuid.UUID,
    session: AsyncSession = Depends(get_db_session),
    storage: StorageService = Depends(get_storage_service),
    _: CurrentUserOut = Depends(require_permission("media.manage")),
) -> dict[str, Any]:
    repository = MediaAssetRepository(session)
    asset = await repository.get_by_id(asset_id)
    if asset is None:
        raise NotFoundError("Media asset not found")
    return success_envelope(serialize_media_asset(asset, storage), request)


@router.patch("/assets/{asset_id}", summary="Update media asset metadata")
async def update_asset(
    request: Request,
    asset_id: uuid.UUID,
    payload: UpdateMediaAssetIn,
    service: MediaService = Depends(get_media_service),
    storage: StorageService = Depends(get_storage_service),
    _: CurrentUserOut = Depends(require_permission("media.manage")),
) -> dict[str, Any]:
    asset = await service.update_asset(asset_id, payload)
    return success_envelope(serialize_media_asset(asset, storage), request)


@router.delete("/assets/{asset_id}", status_code=204, summary="Delete a media asset")
async def delete_asset(
    asset_id: uuid.UUID,
    service: MediaService = Depends(get_media_service),
    _: CurrentUserOut = Depends(require_permission("media.manage")),
) -> None:
    await service.delete_asset(asset_id)


@router.get("/assets/{asset_id}/usage", summary="List content referencing this asset")
async def get_asset_usage(
    request: Request,
    asset_id: uuid.UUID,
    service: MediaService = Depends(get_media_service),
    _: CurrentUserOut = Depends(require_permission("media.manage")),
) -> dict[str, Any]:
    usages = await service.get_usages(asset_id)
    return success_envelope([u.model_dump(mode="json") for u in usages], request)


@router.get("/folders", summary="List media folders")
async def list_folders(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("media.manage")),
) -> dict[str, Any]:
    repository = MediaFolderRepository(session)
    folders = await repository.list_all()
    return success_envelope(
        [MediaFolderOut.model_validate(f).model_dump(mode="json") for f in folders], request
    )
