"""Navigation schemas (Phase 2.2 §4.7, Phase 2.3 §1).

Two shapes, one for reading and one for writing:

  * `NavigationOut` is the *resolved* public shape — a header link list plus
    footer columns each holding their links. This is exactly what
    `getSiteConfig()` needs, so the frontend never reassembles the tree.
  * `ReplaceNavigationIn` is the full desired state the dashboard PUTs. The
    service replaces the stored tree with it atomically, so partial/dangling
    trees can't be created through the API.

URLs are validated as site-relative paths ("/about") or absolute http(s)
URLs — the same two forms the public nav actually renders — so a bad value
can't reach the `<Link>`/`<a>` in the header or footer.
"""

from pydantic import BaseModel, ConfigDict, Field, field_validator


def _validate_nav_url(value: str) -> str:
    if value.startswith("/"):
        return value
    if value.startswith("http://") or value.startswith("https://"):
        return value
    raise ValueError("Navigation URL must be a site-relative path ('/about') or an absolute http(s) URL")


# ---- Read (resolved tree) -------------------------------------------------


class NavLinkOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    label: str
    url: str


class FooterColumnOut(BaseModel):
    title: str
    items: list[NavLinkOut]


class NavigationOut(BaseModel):
    header: list[NavLinkOut]
    footer: list[FooterColumnOut]


# ---- Write (full replace) -------------------------------------------------


class HeaderItemIn(BaseModel):
    label: str = Field(..., min_length=1, max_length=120)
    url: str = Field(..., min_length=1, max_length=500)

    _validate_url = field_validator("url")(_validate_nav_url)


class FooterLinkIn(BaseModel):
    label: str = Field(..., min_length=1, max_length=120)
    url: str = Field(..., min_length=1, max_length=500)

    _validate_url = field_validator("url")(_validate_nav_url)


class FooterColumnIn(BaseModel):
    title: str = Field(..., min_length=1, max_length=120)
    items: list[FooterLinkIn] = Field(default_factory=list)


class ReplaceNavigationIn(BaseModel):
    """The complete desired navigation tree. Both sections are required (an
    empty list is valid and means "no items"), so a PUT always expresses the
    full intended state rather than a partial patch."""

    header: list[HeaderItemIn] = Field(default_factory=list)
    footer: list[FooterColumnIn] = Field(default_factory=list)
