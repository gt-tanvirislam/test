"""Navigation model (Phase 2.2 §4.7 — the `navigation_items` table).

A single adjacency-list tree drives both the public header menu and the
footer columns, so navigation becomes editable in the dashboard instead of
being hardcoded in the frontend's `getSiteConfig()`:

  * header links  → `location="header"`, `parent_id=None`, `url` set;
  * footer columns→ `location="footer"`, `parent_id=None`, `url=None`
    (the column *title* is a group header, not a link);
  * footer links  → `location="footer"`, `parent_id=<column id>`, `url` set.

`sort_order` orders siblings. The whole set is rewritten atomically by the
service on every save (full-replace), so the tree can never drift into a
dangling/orphaned state through the API.
"""

import uuid

from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import AuditMixin, Base

# The two locations navigation items can live in. Kept as plain strings
# (validated at the schema layer) rather than a DB enum — consistent with
# how ContentStatus is handled elsewhere, and cheaper to evolve.
NAV_LOCATION_HEADER = "header"
NAV_LOCATION_FOOTER = "footer"


class NavigationItem(Base, AuditMixin):
    __tablename__ = "navigation_items"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    location: Mapped[str] = mapped_column(String(16), nullable=False)
    # Self-referential parent for footer column grouping. ondelete CASCADE so
    # removing a column removes its links; the service deletes children before
    # parents anyway, so the cascade is a safety net, not the primary path.
    parent_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("navigation_items.id", ondelete="CASCADE"), nullable=True
    )
    label: Mapped[str] = mapped_column(String(120), nullable=False)
    # NULL for footer column headers (group titles aren't links); a real path
    # for every actual link.
    url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
