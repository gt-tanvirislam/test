"""Navigation repository (Phase 2.8 §3).

Not extending BaseRepository: navigation items have no soft-delete
semantics (a removed menu item is genuinely gone, not archived), and the
access pattern is "load the whole tree" / "replace the whole tree" rather
than paginated CRUD — so BaseRepository's list/soft-delete machinery
doesn't fit. Kept small and explicit, like TagRepository.
"""

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.navigation.models import NavigationItem


class NavigationRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def list_all(self) -> list[NavigationItem]:
        """Every item, ordered so parents and siblings come out in a stable
        order the service can assemble into a tree without re-sorting."""
        result = await self.session.execute(
            select(NavigationItem).order_by(NavigationItem.sort_order, NavigationItem.label)
        )
        return list(result.scalars().all())

    async def delete_all(self) -> None:
        """Clear the whole tree ahead of a full-replace. ondelete=CASCADE on
        parent_id means child rows go too, so column-before-link ordering
        isn't required here."""
        await self.session.execute(delete(NavigationItem))
        await self.session.flush()

    def add(self, item: NavigationItem) -> None:
        self.session.add(item)
