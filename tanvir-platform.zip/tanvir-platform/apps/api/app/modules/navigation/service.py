"""Navigation service (Phase 2.8 §1).

`get()` assembles the flat rows into the resolved header/footer tree the
public site consumes. `replace()` performs a full replace: it clears the
existing tree and rebuilds it from the payload in one flush, so the write
is all-or-nothing at the request-boundary commit — a failed save leaves the
previous navigation intact rather than a half-applied tree.
"""

import uuid

from app.modules.navigation.models import (
    NAV_LOCATION_FOOTER,
    NAV_LOCATION_HEADER,
    NavigationItem,
)
from app.modules.navigation.repository import NavigationRepository
from app.modules.navigation.schemas import (
    FooterColumnOut,
    NavigationOut,
    NavLinkOut,
    ReplaceNavigationIn,
)


class NavigationService:
    def __init__(self, repository: NavigationRepository):
        self.repository = repository

    async def get(self) -> NavigationOut:
        items = await self.repository.list_all()

        # Header links: top-level header rows, already ordered by the repo.
        header = [
            NavLinkOut(label=i.label, url=i.url)
            for i in items
            if i.location == NAV_LOCATION_HEADER and i.parent_id is None and i.url is not None
        ]

        # Footer: top-level footer rows are column headers; their children are
        # the links. Group children by parent_id, preserving repo ordering.
        children_by_parent: dict[uuid.UUID, list[NavigationItem]] = {}
        for i in items:
            if i.location == NAV_LOCATION_FOOTER and i.parent_id is not None:
                children_by_parent.setdefault(i.parent_id, []).append(i)

        footer = [
            FooterColumnOut(
                title=col.label,
                items=[
                    NavLinkOut(label=c.label, url=c.url)
                    for c in children_by_parent.get(col.id, [])
                    if c.url is not None
                ],
            )
            for col in items
            if col.location == NAV_LOCATION_FOOTER and col.parent_id is None
        ]

        return NavigationOut(header=header, footer=footer)

    async def replace(self, payload: ReplaceNavigationIn) -> NavigationOut:
        await self.repository.delete_all()

        for index, item in enumerate(payload.header):
            self.repository.add(
                NavigationItem(
                    id=uuid.uuid4(),
                    location=NAV_LOCATION_HEADER,
                    parent_id=None,
                    label=item.label,
                    url=item.url,
                    sort_order=index,
                )
            )

        # Insert the footer column parents first and flush, so each column row
        # physically exists before its child links reference it. parent_id is a
        # raw FK column (no mapped relationship), so SQLAlchemy's unit of work
        # won't order parent-before-child for us — and Postgres checks the FK
        # immediately. Flushing here makes the write correct on Postgres, not
        # just on SQLite (where FKs are off by default in the test harness).
        column_rows: list[NavigationItem] = []
        for col_index, column in enumerate(payload.footer):
            column_row = NavigationItem(
                id=uuid.uuid4(),
                location=NAV_LOCATION_FOOTER,
                parent_id=None,
                label=column.title,
                url=None,  # column headers are group titles, not links
                sort_order=col_index,
            )
            self.repository.add(column_row)
            column_rows.append(column_row)
        await self.repository.session.flush()

        for column_row, column in zip(column_rows, payload.footer):
            for link_index, link in enumerate(column.items):
                self.repository.add(
                    NavigationItem(
                        id=uuid.uuid4(),
                        location=NAV_LOCATION_FOOTER,
                        parent_id=column_row.id,
                        label=link.label,
                        url=link.url,
                        sort_order=link_index,
                    )
                )

        await self.repository.session.flush()
        return await self.get()
