"""Navigation router (Phase 2.2 §4.7, Phase 2.3 §1).

GET is public: the header menu and footer render on every public page via
`getSiteConfig()`, so reads are unauthenticated. PUT requires
`navigation.manage` — the permission seeded in migration 0001 — and replaces
the entire navigation tree with the submitted state.
"""

from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.navigation.repository import NavigationRepository
from app.modules.navigation.schemas import ReplaceNavigationIn
from app.modules.navigation.service import NavigationService
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/navigation", tags=["navigation"])


def _service(session: AsyncSession) -> NavigationService:
    return NavigationService(NavigationRepository(session))


@router.get("", summary="Get the resolved navigation tree (header + footer)")
async def get_navigation(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    navigation = await _service(session).get()
    return success_envelope(navigation.model_dump(mode="json"), request)


@router.put("", summary="Replace the entire navigation tree")
async def replace_navigation(
    request: Request,
    payload: ReplaceNavigationIn,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("navigation.manage")),
) -> dict[str, Any]:
    navigation = await _service(session).replace(payload)
    return success_envelope(navigation.model_dump(mode="json"), request)
