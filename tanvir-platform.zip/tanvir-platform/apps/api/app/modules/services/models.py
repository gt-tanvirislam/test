"""
Services models (Phase 2.2 §4.4). Third content type — same composition
pattern as Blog (Sprint 4) and Portfolio (Sprint 6): AuditMixin +
SoftDeleteMixin (Sprint 0) + PublishableStatusMixin (Sprint 3) + shared
Tag table (Sprint 4) via `service_tags`. Gallery reuses `content_media`
(Sprint 2/6) with `entity_type="service"` — no new gallery table, same
pattern Portfolio proved out.

`ServiceListItem` is ONE table with a `item_type` discriminator for
Features/Benefits/Process steps rather than three near-identical tables
— these three fields share the exact same shape (title + description +
order) on this one model, so a single table with a type column is the
right level of reuse *within this module*, decided independently of
whether Blog/Portfolio need anything similar (they don't).
"""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Table, Column, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import AuditMixin, Base, SoftDeleteMixin
from app.modules.taxonomy.models import Tag
from app.shared.publishable import PublishableStatusMixin

service_tags = Table(
    "service_tags",
    Base.metadata,
    Column("service_id", UUID(as_uuid=True), ForeignKey("services.id", ondelete="CASCADE"), primary_key=True),
    Column("tag_id", UUID(as_uuid=True), ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
)


class ServiceListItemType(StrEnum):
    FEATURE = "feature"
    BENEFIT = "benefit"
    PROCESS_STEP = "process_step"


class ServiceCategory(Base):
    __tablename__ = "service_categories"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(String, nullable=True)


class Service(Base, AuditMixin, SoftDeleteMixin, PublishableStatusMixin):
    __tablename__ = "services"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    author_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    category_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("service_categories.id", ondelete="SET NULL"), nullable=True
    )

    title: Mapped[str] = mapped_column(String, nullable=False)
    slug: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    short_description: Mapped[str | None] = mapped_column(String, nullable=True)
    full_description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    icon_key: Mapped[str | None] = mapped_column(String, nullable=True)  # Lucide icon name, Phase 2.5 §2
    featured_image_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Free-text — custom-quoted pricing model (Phase 2.2 §13's decision),
    # never a rigid numeric price list.
    pricing_text: Mapped[str | None] = mapped_column(String, nullable=True)
    delivery_time: Mapped[str | None] = mapped_column(String, nullable=True)

    cta_text: Mapped[str | None] = mapped_column(String, nullable=True)
    cta_link: Mapped[str | None] = mapped_column(String, nullable=True)

    featured: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)  # manual display priority

    category: Mapped[ServiceCategory | None] = relationship()
    tags: Mapped[list[Tag]] = relationship(secondary=service_tags)
    list_items: Mapped[list["ServiceListItem"]] = relationship(
        back_populates="service", cascade="all, delete-orphan", order_by="ServiceListItem.sort_order"
    )


class ServiceListItem(Base):
    __tablename__ = "service_list_items"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    service_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("services.id", ondelete="CASCADE"), nullable=False
    )
    item_type: Mapped[str] = mapped_column(String, nullable=False)  # ServiceListItemType value
    title: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str | None] = mapped_column(String, nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    service: Mapped[Service] = relationship(back_populates="list_items")


class ServiceRevision(Base):
    __tablename__ = "service_revisions"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    service_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("services.id", ondelete="CASCADE"), nullable=False
    )
    snapshot: Mapped[dict] = mapped_column(JSONB, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
