"""
Services service (Phase 2.8 §1). Third module composing the exact same
shape as BlogService (Sprint 4) and PortfolioService (Sprint 6) —
concrete proof the reference pattern generalizes to a third, differently-
shaped content type.
"""

import uuid
from datetime import datetime

from app.core.exceptions import NotFoundError, ValidationError
from app.modules.media.repository import ContentMediaRepository
from app.modules.services.models import Service, ServiceListItemType, ServiceRevision
from app.modules.services.repository import (
    ServiceCategoryRepository,
    ServiceListItemRepository,
    ServiceRepository,
)
from app.modules.services.schemas import CreateServiceIn, UpdateServiceIn
from app.modules.taxonomy.repository import TagRepository
from app.shared.publishable import ContentLifecycleService, ContentStatus
from app.shared.revision import create_revision
from app.shared.slug import generate_unique_slug


class ServiceService:
    def __init__(
        self,
        service_repository: ServiceRepository,
        category_repository: ServiceCategoryRepository,
        tag_repository: TagRepository,
        content_media_repository: ContentMediaRepository,
        list_item_repository: ServiceListItemRepository,
        lifecycle: ContentLifecycleService | None = None,
    ):
        self.service_repository = service_repository
        self.category_repository = category_repository
        self.tag_repository = tag_repository
        self.content_media_repository = content_media_repository
        self.list_item_repository = list_item_repository
        self.lifecycle = lifecycle or ContentLifecycleService()

    async def create(self, author_id: uuid.UUID, payload: CreateServiceIn) -> Service:
        slug = payload.slug or await generate_unique_slug(
            self.service_repository.session, Service, payload.title
        )
        tags = await self.tag_repository.get_or_create_many(payload.tag_names)

        service = Service(
            id=uuid.uuid4(),
            author_id=author_id,
            category_id=payload.category_id,
            title=payload.title,
            slug=slug,
            short_description=payload.short_description,
            full_description=payload.full_description,
            featured_image_id=payload.featured_image_id,
            icon_key=payload.icon_key,
            pricing_text=payload.pricing_text,
            delivery_time=payload.delivery_time,
            featured=payload.featured,
            sort_order=payload.sort_order,
            status=ContentStatus.DRAFT.value,
        )
        service.tags = tags

        self.service_repository.session.add(service)
        await self.service_repository.session.flush()
        return service

    async def update(self, service_id: uuid.UUID, payload: UpdateServiceIn) -> Service:
        """Same autosave-and-manual-edit-are-one-operation design as
        BlogService/PortfolioService.update — see BlogService's
        docstring (Sprint 4) for the full rationale."""
        service = await self.service_repository.get_by_id_full(service_id)
        if service is None:
            raise NotFoundError("Service not found")

        data = payload.model_dump(exclude_unset=True)

        simple_fields = [
            "short_description", "full_description", "category_id", "featured_image_id",
            "author_id", "icon_key", "pricing_text", "delivery_time", "cta_text", "cta_link",
            "featured", "sort_order",
        ]
        for field in simple_fields:
            if field in data:
                setattr(service, field, data[field])

        if "title" in data and data["title"] is not None:
            service.title = data["title"]
        if "slug" in data and data["slug"]:
            service.slug = await generate_unique_slug(
                self.service_repository.session, Service, data["slug"], exclude_id=service.id
            )
        if "tag_names" in data and data["tag_names"] is not None:
            service.tags = await self.tag_repository.get_or_create_many(data["tag_names"])

        await self.service_repository.session.flush()
        return service

    async def delete(self, service_id: uuid.UUID) -> None:
        service = await self.service_repository.get_by_id(service_id)
        if service is None:
            raise NotFoundError("Service not found")
        await self.service_repository.soft_delete(service)

    async def restore(self, service_id: uuid.UUID) -> Service:
        service = await self.service_repository.get_by_id(service_id, include_deleted=True)
        if service is None:
            raise NotFoundError("Service not found")
        await self.service_repository.restore(service)
        return service

    # ── Lifecycle — identical delegation shape to Blog/Portfolio ────────

    async def publish(self, service_id: uuid.UUID, actor_id: uuid.UUID) -> Service:
        service = await self.service_repository.get_by_id_full(service_id)
        if service is None:
            raise NotFoundError("Service not found")

        if not service.featured_image_id or not service.short_description:
            raise ValidationError(
                "Featured image and short description are required to publish",
                fields={
                    "featured_image_id": "Required" if not service.featured_image_id else "",
                    "short_description": "Required" if not service.short_description else "",
                },
            )

        self.lifecycle.publish(service)
        await self._create_revision(service, actor_id)
        await self.service_repository.session.flush()
        return service

    async def unpublish(self, service_id: uuid.UUID) -> Service:
        service = await self._get_or_404(service_id)
        self.lifecycle.unpublish(service)
        await self.service_repository.session.flush()
        return service

    async def schedule(self, service_id: uuid.UUID, scheduled_at: datetime) -> Service:
        service = await self._get_or_404(service_id)
        self.lifecycle.schedule(service, scheduled_at)
        await self.service_repository.session.flush()
        return service

    async def archive(self, service_id: uuid.UUID) -> Service:
        service = await self._get_or_404(service_id)
        self.lifecycle.archive(service)
        await self.service_repository.session.flush()
        return service

    async def restore_from_archive(self, service_id: uuid.UUID) -> Service:
        service = await self._get_or_404(service_id)
        self.lifecycle.restore_from_archive(service)
        await self.service_repository.session.flush()
        return service

    async def save_version(self, service_id: uuid.UUID, actor_id: uuid.UUID) -> Service:
        service = await self._get_or_404(service_id)
        await self._create_revision(service, actor_id)
        return service

    # ── Gallery & list items — the genuinely Services-specific piece ────

    async def set_gallery(self, service_id: uuid.UUID, media_asset_ids: list[uuid.UUID]) -> None:
        await self._get_or_404(service_id)
        await self.content_media_repository.replace_gallery("service", service_id, media_asset_ids)

    async def set_features(self, service_id: uuid.UUID, items: list[dict]) -> Service:
        return await self._set_list_items(service_id, ServiceListItemType.FEATURE.value, items)

    async def set_benefits(self, service_id: uuid.UUID, items: list[dict]) -> Service:
        return await self._set_list_items(service_id, ServiceListItemType.BENEFIT.value, items)

    async def set_process_steps(self, service_id: uuid.UUID, items: list[dict]) -> Service:
        return await self._set_list_items(service_id, ServiceListItemType.PROCESS_STEP.value, items)

    async def _set_list_items(self, service_id: uuid.UUID, item_type: str, items: list[dict]) -> Service:
        await self._get_or_404(service_id)
        await self.list_item_repository.replace_all(service_id, item_type, items)
        return await self.service_repository.get_by_id_full(service_id)

    async def _get_or_404(self, service_id: uuid.UUID) -> Service:
        service = await self.service_repository.get_by_id_full(service_id)
        if service is None:
            raise NotFoundError("Service not found")
        return service

    async def _create_revision(self, service: Service, actor_id: uuid.UUID) -> None:
        snapshot = {
            "title": service.title,
            "slug": service.slug,
            "short_description": service.short_description,
            "full_description": service.full_description,
            "category_id": str(service.category_id) if service.category_id else None,
            "featured_image_id": str(service.featured_image_id) if service.featured_image_id else None,
            "tag_names": [t.name for t in service.tags],
            "pricing_text": service.pricing_text,
        }
        create_revision(
            self.service_repository.session,
            ServiceRevision,
            entity_fk_field="service_id",
            entity_id=service.id,
            snapshot=snapshot,
            actor_id=actor_id,
        )
