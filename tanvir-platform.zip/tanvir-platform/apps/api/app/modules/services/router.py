"""Services router (Phase 2.3 §7). Mirrors Blog/Portfolio's router shape."""

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ConflictError, NotFoundError
from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.infrastructure.storage.service import StorageService, get_storage_service
from app.modules.media.repository import ContentMediaRepository, MediaAssetRepository
from app.modules.media.router import serialize_media_asset
from app.modules.services.models import ServiceCategory
from app.modules.services.repository import (
    ServiceCategoryRepository,
    ServiceListItemRepository,
    ServiceRepository,
)
from app.modules.services.schemas import (
    CreateServiceCategoryIn,
    CreateServiceIn,
    ScheduleServiceIn,
    ServiceCategoryOut,
    ServiceListItemOut,
    ServiceListItemOutSlim,
    ServiceOut,
    SetServiceListItemsIn,
    UpdateServiceIn,
)
from app.modules.services.service import ServiceService
from app.modules.taxonomy.repository import TagRepository
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope
from app.shared.slug import generate_unique_slug

router = APIRouter(prefix="/services", tags=["services"])


def get_service_service(session: AsyncSession = Depends(get_db_session)) -> ServiceService:
    return ServiceService(
        ServiceRepository(session),
        ServiceCategoryRepository(session),
        TagRepository(session),
        ContentMediaRepository(session),
        ServiceListItemRepository(session),
    )


# ── Items ─────────────────────────────────────────────────────────────


@router.get("/items", summary="List services")
async def list_services(
    request: Request,
    page: int = 1,
    per_page: int = 20,
    status: str | None = None,
    category_id: uuid.UUID | None = None,
    tag_id: uuid.UUID | None = None,
    author_id: uuid.UUID | None = None,
    search: str | None = None,
    featured: bool | None = None,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.view_drafts")),
) -> dict[str, Any]:
    repository = ServiceRepository(session)
    items, total = await repository.list_filtered(
        page=page, per_page=per_page, status=status, category_id=category_id,
        tag_id=tag_id, author_id=author_id, search=search, featured=featured,
    )
    return {
        "data": [ServiceListItemOutSlim.model_validate(i).model_dump(mode="json") for i in items],
        "meta": {
            "page": page, "per_page": per_page, "total": total,
            "total_pages": max(1, (total + per_page - 1) // per_page),
        },
    }


@router.get("/items/check-slug", summary="Check whether a slug is available")
async def check_slug_availability(
    request: Request,
    slug: str,
    exclude_id: uuid.UUID | None = None,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.create")),
) -> dict[str, Any]:
    repository = ServiceRepository(session)
    exists = await repository.slug_exists(slug, exclude_id=exclude_id)
    return success_envelope({"available": not exists}, request)


@router.get("/items/{service_id}", summary="Get a single service by ID")
async def get_service(
    request: Request,
    service_id: uuid.UUID,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.view_drafts")),
) -> dict[str, Any]:
    repository = ServiceRepository(session)
    service = await repository.get_by_id_full(service_id)
    if service is None:
        raise NotFoundError("Service not found")
    return success_envelope(ServiceOut.model_validate(service).model_dump(mode="json"), request)


@router.post("/items", summary="Create a draft service")
async def create_service(
    request: Request,
    payload: CreateServiceIn,
    service: ServiceService = Depends(get_service_service),
    current_user: CurrentUserOut = Depends(require_permission("content.create")),
) -> dict[str, Any]:
    result = await service.create(current_user.id, payload)
    return success_envelope(ServiceOut.model_validate(result).model_dump(mode="json"), request)


@router.patch("/items/{service_id}", summary="Update a service (also the autosave target)")
async def update_service(
    request: Request,
    service_id: uuid.UUID,
    payload: UpdateServiceIn,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    result = await service.update(service_id, payload)
    return success_envelope(ServiceOut.model_validate(result).model_dump(mode="json"), request)


@router.delete("/items/{service_id}", status_code=204, summary="Soft-delete a service")
async def delete_service(
    service_id: uuid.UUID,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.delete")),
) -> None:
    await service.delete(service_id)


@router.post("/items/{service_id}/restore", summary="Restore a soft-deleted service")
async def restore_service(
    request: Request,
    service_id: uuid.UUID,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.restore")),
) -> dict[str, Any]:
    result = await service.restore(service_id)
    return success_envelope(ServiceOut.model_validate(result).model_dump(mode="json"), request)


# ── Lifecycle ─────────────────────────────────────────────────────────


@router.post("/items/{service_id}/publish", summary="Publish a draft or scheduled service")
async def publish_service(
    request: Request,
    service_id: uuid.UUID,
    service: ServiceService = Depends(get_service_service),
    current_user: CurrentUserOut = Depends(require_permission("content.publish")),
) -> dict[str, Any]:
    result = await service.publish(service_id, current_user.id)
    return success_envelope(ServiceOut.model_validate(result).model_dump(mode="json"), request)


@router.post("/items/{service_id}/unpublish", summary="Revert a published service to draft")
async def unpublish_service(
    request: Request,
    service_id: uuid.UUID,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.publish")),
) -> dict[str, Any]:
    result = await service.unpublish(service_id)
    return success_envelope(ServiceOut.model_validate(result).model_dump(mode="json"), request)


@router.post("/items/{service_id}/schedule", summary="Schedule a draft to publish later")
async def schedule_service(
    request: Request,
    service_id: uuid.UUID,
    payload: ScheduleServiceIn,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.publish")),
) -> dict[str, Any]:
    result = await service.schedule(service_id, payload.scheduled_at)
    return success_envelope(ServiceOut.model_validate(result).model_dump(mode="json"), request)


@router.post("/items/{service_id}/archive", summary="Archive a service")
async def archive_service(
    request: Request,
    service_id: uuid.UUID,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.delete")),
) -> dict[str, Any]:
    result = await service.archive(service_id)
    return success_envelope(ServiceOut.model_validate(result).model_dump(mode="json"), request)


@router.post("/items/{service_id}/restore-from-archive", summary="Restore an archived service to draft")
async def restore_from_archive(
    request: Request,
    service_id: uuid.UUID,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.restore")),
) -> dict[str, Any]:
    result = await service.restore_from_archive(service_id)
    return success_envelope(ServiceOut.model_validate(result).model_dump(mode="json"), request)


@router.post("/items/{service_id}/save-version", summary="Save an explicit revision snapshot")
async def save_version(
    request: Request,
    service_id: uuid.UUID,
    service: ServiceService = Depends(get_service_service),
    current_user: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    result = await service.save_version(service_id, current_user.id)
    return success_envelope(ServiceOut.model_validate(result).model_dump(mode="json"), request)


# ── List items (Features / Benefits / Process) ──────────────────────


@router.put("/items/{service_id}/features", summary="Replace the service's feature list")
async def set_features(
    request: Request,
    service_id: uuid.UUID,
    payload: SetServiceListItemsIn,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    result = await service.set_features(service_id, [i.model_dump() for i in payload.items])
    return success_envelope(_serialize_items(result, "feature"), request)


@router.put("/items/{service_id}/benefits", summary="Replace the service's benefit list")
async def set_benefits(
    request: Request,
    service_id: uuid.UUID,
    payload: SetServiceListItemsIn,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    result = await service.set_benefits(service_id, [i.model_dump() for i in payload.items])
    return success_envelope(_serialize_items(result, "benefit"), request)


@router.put("/items/{service_id}/process", summary="Replace the service's process steps")
async def set_process_steps(
    request: Request,
    service_id: uuid.UUID,
    payload: SetServiceListItemsIn,
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    result = await service.set_process_steps(service_id, [i.model_dump() for i in payload.items])
    return success_envelope(_serialize_items(result, "process_step"), request)


def _serialize_items(service: Any, item_type: str) -> list[dict[str, Any]]:
    return [
        ServiceListItemOut.model_validate(i).model_dump(mode="json")
        for i in service.list_items
        if i.item_type == item_type
    ]


# ── Gallery ───────────────────────────────────────────────────────────


@router.put("/items/{service_id}/gallery", summary="Replace the service's gallery images")
async def set_gallery(
    request: Request,
    service_id: uuid.UUID,
    payload: dict[str, list[uuid.UUID]],
    service: ServiceService = Depends(get_service_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    media_asset_ids = payload.get("media_asset_ids", [])
    await service.set_gallery(service_id, media_asset_ids)
    return success_envelope({"media_asset_ids": [str(i) for i in media_asset_ids]}, request)


@router.get("/items/{service_id}/gallery", summary="Get the service's gallery images")
async def get_gallery(
    request: Request,
    service_id: uuid.UUID,
    session: AsyncSession = Depends(get_db_session),
    storage: StorageService = Depends(get_storage_service),
    _: CurrentUserOut = Depends(require_permission("content.view_drafts")),
) -> dict[str, Any]:
    content_media_repository = ContentMediaRepository(session)
    asset_repository = MediaAssetRepository(session)

    links = await content_media_repository.list_for_entity("service", service_id)
    assets = []
    for link in links:
        asset = await asset_repository.get_by_id(link.media_asset_id)
        if asset:
            assets.append(serialize_media_asset(asset, storage))
    return success_envelope(assets, request)


# ── Categories ────────────────────────────────────────────────────────


@router.get("/categories", summary="List service categories")
async def list_categories(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    repository = ServiceCategoryRepository(session)
    categories = await repository.list_all()
    return success_envelope(
        [ServiceCategoryOut.model_validate(c).model_dump(mode="json") for c in categories], request
    )


@router.post("/categories", summary="Create a service category")
async def create_category(
    request: Request,
    payload: CreateServiceCategoryIn,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    repository = ServiceCategoryRepository(session)
    if await repository.get_by_name(payload.name):
        raise ConflictError("A category with this name already exists")

    slug = await generate_unique_slug(session, ServiceCategory, payload.name)
    category = ServiceCategory(id=uuid.uuid4(), name=payload.name, slug=slug, description=payload.description)
    session.add(category)
    await session.flush()
    return success_envelope(ServiceCategoryOut.model_validate(category).model_dump(mode="json"), request)


# ── Public API ────────────────────────────────────────────────────────


@router.get("/public/items", summary="List published services (public)")
async def list_public_services(
    request: Request,
    page: int = 1,
    per_page: int = 20,
    category: str | None = None,
    tag: str | None = None,
    search: str | None = None,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    repository = ServiceRepository(session)
    items, total = await repository.list_published(
        page=page, per_page=per_page, category_slug=category, tag_slug=tag, search=search
    )
    return {
        "data": [ServiceListItemOutSlim.model_validate(i).model_dump(mode="json") for i in items],
        "meta": {
            "page": page, "per_page": per_page, "total": total,
            "total_pages": max(1, (total + per_page - 1) // per_page),
        },
    }


@router.get("/public/items/{slug}", summary="Get a published service by slug, with SEO overrides (public)")
async def get_public_service(
    request: Request,
    slug: str,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    from app.modules.seo.repository import SeoMetadataRepository
    from app.modules.seo.schemas import SeoMetadataOut

    repository = ServiceRepository(session)
    service = await repository.get_by_slug(slug, published_only=True)
    if service is None:
        raise NotFoundError("Service not found")

    seo_repository = SeoMetadataRepository(session)
    seo_record = await seo_repository.get_for_entity("service", service.id)

    data = ServiceOut.model_validate(service).model_dump(mode="json")
    data["seo"] = SeoMetadataOut.model_validate(seo_record).model_dump(mode="json") if seo_record else None
    return success_envelope(data, request)
