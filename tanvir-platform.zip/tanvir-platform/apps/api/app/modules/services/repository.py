"""
Services repository (Phase 2.8 §3, §4). Third module, first to use
`list_filtered_content()` (Sprint 8) from the start rather than
duplicating the inline pattern Blog/Portfolio had before this sprint's
refactor.
"""

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.modules.services.models import Service, ServiceCategory, ServiceListItem, service_tags
from app.shared.content_query import list_filtered_content
from app.shared.repository_base import BaseRepository


class ServiceRepository(BaseRepository[Service]):
    model = Service

    def _detail_query(self):
        return select(Service).options(
            selectinload(Service.category), selectinload(Service.tags), selectinload(Service.list_items)
        )

    def _list_query(self):
        """List-view query — eager-loads category only, matching the
        over-fetching fix Sprint 5 applied to Blog and Sprint 6 applied
        to Portfolio from the start. `ServiceListItemOutSlim` never
        includes tags or list_items."""
        return select(Service).options(selectinload(Service.category))

    async def get_by_id_full(self, service_id: uuid.UUID) -> Service | None:
        stmt = self._detail_query().where(Service.id == service_id, Service.deleted_at.is_(None))
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_slug(self, slug: str, *, published_only: bool = False) -> Service | None:
        stmt = self._detail_query().where(Service.slug == slug, Service.deleted_at.is_(None))
        if published_only:
            stmt = stmt.where(Service.status == "published")
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def slug_exists(self, slug: str, *, exclude_id: uuid.UUID | None = None) -> bool:
        stmt = select(Service.id).where(Service.slug == slug, Service.deleted_at.is_(None))
        if exclude_id:
            stmt = stmt.where(Service.id != exclude_id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none() is not None

    async def list_filtered(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        status: str | None = None,
        category_id: uuid.UUID | None = None,
        tag_id: uuid.UUID | None = None,
        author_id: uuid.UUID | None = None,
        search: str | None = None,
        featured: bool | None = None,
    ) -> tuple[list[Service], int]:
        list_stmt = self._list_query().where(Service.deleted_at.is_(None))
        count_stmt = select(func.count(func.distinct(Service.id))).select_from(Service).where(
            Service.deleted_at.is_(None)
        )

        return await list_filtered_content(
            self.session,
            list_stmt=list_stmt,
            count_stmt=count_stmt,
            page=page,
            per_page=per_page,
            equality_filters={
                Service.status: status,
                Service.category_id: category_id,
                Service.author_id: author_id,
                Service.featured: featured,
            },
            search_columns=[Service.title, Service.short_description],
            search_term=search,
            tag_join_table=service_tags,
            tag_id_column=service_tags.c.tag_id,
            tag_id=tag_id,
            # Services order by sort_order (manual display priority)
            # rather than recency, unlike Blog/Portfolio — reflecting
            # this module's genuinely different content model (Phase
            # 2.2 §4.4's "display priority" requirement), not an
            # oversight or inconsistency with the other two.
            order_by_column=Service.sort_order,
            descending=False,
        )

    async def list_published(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        category_slug: str | None = None,
        tag_slug: str | None = None,
        search: str | None = None,
    ) -> tuple[list[Service], int]:
        category_id = None
        if category_slug:
            result = await self.session.execute(
                select(ServiceCategory.id).where(ServiceCategory.slug == category_slug)
            )
            category_id = result.scalar_one_or_none()
            if category_id is None:
                return [], 0

        tag_id = None
        if tag_slug:
            from app.modules.taxonomy.models import Tag

            result = await self.session.execute(select(Tag.id).where(Tag.slug == tag_slug))
            tag_id = result.scalar_one_or_none()
            if tag_id is None:
                return [], 0

        return await self.list_filtered(
            page=page, per_page=per_page, status="published", category_id=category_id, tag_id=tag_id, search=search
        )


class ServiceCategoryRepository(BaseRepository[ServiceCategory]):
    model = ServiceCategory

    async def list_all(self) -> list[ServiceCategory]:
        result = await self.session.execute(select(ServiceCategory).order_by(ServiceCategory.name))
        return list(result.scalars().all())

    async def get_by_name(self, name: str) -> ServiceCategory | None:
        result = await self.session.execute(select(ServiceCategory).where(ServiceCategory.name == name))
        return result.scalar_one_or_none()


class ServiceListItemRepository:
    """Manages the discriminated service_list_items table. Same
    replace-all semantics as BeforeAfterPairRepository (Sprint 6) — not
    unified into one shared "ordered child replace-all" abstraction,
    since the two shapes (two-media-refs vs title+description) differ
    enough that forcing a shared generic would add indirection without
    real savings (this sprint's "do not introduce speculative
    abstractions" rule)."""

    def __init__(self, session):
        self.session = session

    async def replace_all(
        self, service_id: uuid.UUID, item_type: str, items: list[dict]
    ) -> list[ServiceListItem]:
        await self.session.execute(
            ServiceListItem.__table__.delete().where(
                ServiceListItem.service_id == service_id, ServiceListItem.item_type == item_type
            )
        )
        new_items = [
            ServiceListItem(
                id=uuid.uuid4(),
                service_id=service_id,
                item_type=item_type,
                title=item["title"],
                description=item.get("description"),
                sort_order=index,
            )
            for index, item in enumerate(items)
        ]
        self.session.add_all(new_items)
        await self.session.flush()
        return new_items
