"""Services schemas (Phase 2.3 §7). Mirrors Blog/Portfolio's schema
shape for everything shared."""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.modules.taxonomy.schemas import TagOut


class ServiceCategoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    slug: str
    description: str | None


class CreateServiceCategoryIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: str | None = None


class ServiceListItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    item_type: str
    title: str
    description: str | None
    sort_order: int


class ServiceListItemIn(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: str | None = None


class ServiceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    author_id: uuid.UUID
    category_id: uuid.UUID | None
    category: ServiceCategoryOut | None = None
    tags: list[TagOut] = []
    list_items: list[ServiceListItemOut] = []

    title: str
    slug: str
    short_description: str | None
    full_description: str
    icon_key: str | None
    featured_image_id: uuid.UUID | None

    pricing_text: str | None
    delivery_time: str | None
    cta_text: str | None
    cta_link: str | None

    featured: bool
    sort_order: int

    status: str
    scheduled_at: datetime | None
    published_at: datetime | None
    created_at: datetime
    updated_at: datetime


class ServiceListItemOutSlim(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str
    slug: str
    status: str
    featured: bool
    category: ServiceCategoryOut | None = None
    icon_key: str | None
    sort_order: int
    published_at: datetime | None
    updated_at: datetime


class CreateServiceIn(BaseModel):
    title: str = Field(..., min_length=3, max_length=200)
    slug: str | None = None
    short_description: str | None = Field(default=None, max_length=300)
    full_description: str = ""
    category_id: uuid.UUID | None = None
    tag_names: list[str] = []
    featured_image_id: uuid.UUID | None = None
    icon_key: str | None = None
    pricing_text: str | None = None
    delivery_time: str | None = None
    featured: bool = False
    sort_order: int = 0


class UpdateServiceIn(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=200)
    slug: str | None = None
    short_description: str | None = Field(default=None, max_length=300)
    full_description: str | None = None
    category_id: uuid.UUID | None = None
    tag_names: list[str] | None = None
    featured_image_id: uuid.UUID | None = None
    author_id: uuid.UUID | None = None
    icon_key: str | None = None
    pricing_text: str | None = None
    delivery_time: str | None = None
    cta_text: str | None = None
    cta_link: str | None = None
    featured: bool | None = None
    sort_order: int | None = None


class ScheduleServiceIn(BaseModel):
    scheduled_at: datetime


class SetServiceListItemsIn(BaseModel):
    items: list[ServiceListItemIn]
