"""SEO metadata model (Phase 2.2 §4.7). Polymorphic — one row per
(entity_type, entity_id) pair, optional override on top of each future
content module's own fields plus site-wide settings fallback (Phase 2.7
§10's buildMetadata() pattern, backend side)."""

import uuid

from sqlalchemy import Boolean, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class SeoMetadata(Base):
    __tablename__ = "seo_metadata"
    __table_args__ = (UniqueConstraint("entity_type", "entity_id", name="uq_seo_metadata_entity"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    entity_type: Mapped[str] = mapped_column(String, nullable=False)
    entity_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)

    meta_title: Mapped[str | None] = mapped_column(String, nullable=True)
    meta_description: Mapped[str | None] = mapped_column(String, nullable=True)
    og_image_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    canonical_override: Mapped[str | None] = mapped_column(String, nullable=True)
    noindex: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    twitter_card_type: Mapped[str | None] = mapped_column(String, nullable=True)
    robots_directive: Mapped[str | None] = mapped_column(String, nullable=True)
    json_ld_override: Mapped[str | None] = mapped_column(
        String, nullable=True
    )  # raw JSON string; structured generation is per-module (Phase 2.7 §10), this is a manual override escape hatch
