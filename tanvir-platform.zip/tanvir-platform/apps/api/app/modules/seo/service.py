"""SEO service (Phase 2.8 §1). Any future content module (Blog, Portfolio,
Services) calls this the same way for its per-entity SEO override — one
implementation, reused everywhere, rather than each module managing its
own SEO fields inline on its own table."""

import uuid

from app.modules.seo.models import SeoMetadata
from app.modules.seo.repository import SeoMetadataRepository
from app.modules.seo.schemas import UpsertSeoMetadataIn


class SeoService:
    def __init__(self, repository: SeoMetadataRepository):
        self.repository = repository

    async def get_for_entity(self, entity_type: str, entity_id: uuid.UUID) -> SeoMetadata | None:
        return await self.repository.get_for_entity(entity_type, entity_id)

    async def upsert_for_entity(
        self, entity_type: str, entity_id: uuid.UUID, payload: UpsertSeoMetadataIn
    ) -> SeoMetadata:
        existing = await self.repository.get_for_entity(entity_type, entity_id)

        if existing:
            for field, value in payload.model_dump().items():
                setattr(existing, field, value)
            await self.repository.session.flush()
            return existing

        new_record = SeoMetadata(
            id=uuid.uuid4(), entity_type=entity_type, entity_id=entity_id, **payload.model_dump()
        )
        self.repository.session.add(new_record)
        await self.repository.session.flush()
        return new_record
