"""SEO router (Phase 2.3 §13). Generic across every content type —
`entity_type` is a path parameter, not a separate route per module."""

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.seo.repository import SeoMetadataRepository
from app.modules.seo.schemas import SeoMetadataOut, UpsertSeoMetadataIn
from app.modules.seo.service import SeoService
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/seo", tags=["seo"])


def get_seo_service(session: AsyncSession = Depends(get_db_session)) -> SeoService:
    return SeoService(SeoMetadataRepository(session))


@router.get("/{entity_type}/{entity_id}", summary="Get SEO overrides for a content entity")
async def get_seo_metadata(
    request: Request,
    entity_type: str,
    entity_id: uuid.UUID,
    service: SeoService = Depends(get_seo_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    record = await service.get_for_entity(entity_type, entity_id)
    data = SeoMetadataOut.model_validate(record).model_dump(mode="json") if record else None
    return success_envelope(data, request)


@router.patch("/{entity_type}/{entity_id}", summary="Set SEO overrides for a content entity")
async def upsert_seo_metadata(
    request: Request,
    entity_type: str,
    entity_id: uuid.UUID,
    payload: UpsertSeoMetadataIn,
    service: SeoService = Depends(get_seo_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    record = await service.upsert_for_entity(entity_type, entity_id, payload)
    return success_envelope(SeoMetadataOut.model_validate(record).model_dump(mode="json"), request)
