"""SEO repository (Phase 2.8 §3, §4)."""

import uuid

from sqlalchemy import select

from app.modules.seo.models import SeoMetadata
from app.shared.repository_base import BaseRepository


class SeoMetadataRepository(BaseRepository[SeoMetadata]):
    model = SeoMetadata

    async def get_for_entity(self, entity_type: str, entity_id: uuid.UUID) -> SeoMetadata | None:
        stmt = select(SeoMetadata).where(
            SeoMetadata.entity_type == entity_type, SeoMetadata.entity_id == entity_id
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()
