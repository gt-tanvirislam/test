"""SEO schemas (Phase 2.3 §13)."""

import uuid

from pydantic import BaseModel, ConfigDict, Field


class SeoMetadataOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    entity_type: str
    entity_id: uuid.UUID
    meta_title: str | None
    meta_description: str | None
    og_image_id: uuid.UUID | None
    canonical_override: str | None
    noindex: bool
    twitter_card_type: str | None
    robots_directive: str | None
    json_ld_override: str | None


class UpsertSeoMetadataIn(BaseModel):
    meta_title: str | None = Field(default=None, max_length=70)  # Google's practical title limit
    meta_description: str | None = Field(default=None, max_length=160)
    og_image_id: uuid.UUID | None = None
    canonical_override: str | None = None
    noindex: bool = False
    twitter_card_type: str | None = None
    robots_directive: str | None = None
    json_ld_override: str | None = None
