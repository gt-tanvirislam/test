"""
Scheduler router (Sprint 10 BUG-2). Exposes the due-publish sweep as a
single protected endpoint a cron/scheduler calls on an interval (e.g. every
5 minutes).

Auth is deliberately NOT `require_permission`: the caller is an automated
scheduler with no Supabase user JWT. It authenticates with a shared secret
(`SCHEDULER_SECRET`) in the `X-Scheduler-Secret` header, mirroring the
existing `revalidation_secret` shared-secret pattern in config.py. The check
fails closed — if the secret is unset the endpoint is disabled, and the
comparison is constant-time.
"""

import hmac
from typing import Any

from fastapi import APIRouter, Depends, Header, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.exceptions import UnauthorizedError
from app.db.session import get_db_session
from app.modules.scheduler.service import PublishScheduledService, default_publishers
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/scheduler", tags=["scheduler"])


def require_scheduler_secret(
    x_scheduler_secret: str | None = Header(default=None, alias="X-Scheduler-Secret"),
) -> None:
    """Fail-closed shared-secret gate. Unset secret ⇒ endpoint disabled;
    wrong/missing header ⇒ 401. Constant-time comparison to avoid leaking
    the secret through timing."""
    expected = get_settings().scheduler_secret
    if not expected:
        raise UnauthorizedError("Scheduled publishing endpoint is not configured")
    if not x_scheduler_secret or not hmac.compare_digest(x_scheduler_secret, expected):
        raise UnauthorizedError("Invalid scheduler credentials")


@router.post("/run-due", summary="Publish all content whose scheduled time has arrived")
async def run_due(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
    _: None = Depends(require_scheduler_secret),
) -> dict[str, Any]:
    service = PublishScheduledService(session, default_publishers(session))
    result = await service.run()
    return success_envelope(result.model_dump(mode="json"), request)
