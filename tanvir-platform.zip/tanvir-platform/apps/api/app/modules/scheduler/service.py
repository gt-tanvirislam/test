"""
Scheduled-publishing sweep (Sprint 10 BUG-2 fix).

The bug: `ContentLifecycleService.schedule()` sets an item to SCHEDULED with
a future `scheduled_at`, but nothing ever published it when that time
arrived — scheduled content stayed scheduled forever. This module supplies
the missing half.

Design decisions:

* **Reuse the real `publish()`, don't reinvent it.** Each content module's
  `publish(id, actor_id)` re-fetches the entity, re-runs publish-time
  validation (featured image + excerpt/description required), transitions
  status via the shared lifecycle, and snapshots a revision. The sweep
  calls that exact method with `actor_id=None` (a system action — the
  revision's `created_by` is nullable), so a scheduled publish and an
  editor's manual "Publish" click are behaviourally identical. No publish
  logic is duplicated here.

* **Per-item savepoints for failure isolation.** A scheduled item can
  legitimately fail to publish now — e.g. its featured image was deleted
  after scheduling, so publish-time validation rejects it. Each item is
  published inside its own `SAVEPOINT` (`session.begin_nested()`); if it
  fails, only that item's writes roll back and it's recorded in `failed`,
  while the rest of the batch proceeds and commits. One bad item can't
  abort the sweep.

* **Idempotent by construction.** The due query selects only status ==
  'scheduled'. A successfully published item is no longer 'scheduled', so a
  second sweep won't touch it. Running the sweep twice (overlapping crons,
  a manual retry) is safe.

The single surrounding transaction is still owned by `get_db_session`
(BUG-1's unit-of-work): this service only flushes/uses savepoints; the
request boundary commits once at the end.
"""

from __future__ import annotations

from datetime import datetime, timezone

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.blog.models import BlogPost
from app.modules.blog.repository import BlogCategoryRepository, BlogPostRepository
from app.modules.blog.service import BlogService
from app.modules.media.repository import ContentMediaRepository
from app.modules.portfolio.models import PortfolioItem
from app.modules.portfolio.repository import (
    BeforeAfterPairRepository,
    PortfolioCategoryRepository,
    PortfolioItemRepository,
)
from app.modules.portfolio.service import PortfolioService
from app.modules.scheduler.schemas import (
    FailedItemOut,
    PublishedItemOut,
    SchedulerRunOut,
)
from app.modules.services.models import Service
from app.modules.services.repository import (
    ServiceCategoryRepository,
    ServiceListItemRepository,
    ServiceRepository,
)
from app.modules.services.service import ServiceService
from app.modules.taxonomy.repository import TagRepository
from app.shared.scheduling import select_due_scheduled_ids

logger = structlog.get_logger(__name__)


class ContentPublisher:
    """Binds a publishable model (for the due query) to the concrete
    service whose `publish(id, actor_id)` performs the real transition.
    Kept as a tiny value object so the sweep is a plain loop over these and
    tests can inject a single publisher without standing up all modules."""

    def __init__(self, name: str, model: type, service) -> None:
        self.name = name
        self.model = model
        self.service = service

    async def publish(self, item_id) -> None:
        # actor_id=None: this is a system action, not a user's. The revision
        # helper accepts a nullable actor, so the snapshot is still recorded.
        await self.service.publish(item_id, None)


def default_publishers(session: AsyncSession) -> list[ContentPublisher]:
    """Every publishable module, wired exactly as each module's own router
    builds its service (same repositories, same order) so the sweep's
    publish path is identical to the interactive one."""
    return [
        ContentPublisher(
            "blog",
            BlogPost,
            BlogService(
                BlogPostRepository(session),
                BlogCategoryRepository(session),
                TagRepository(session),
            ),
        ),
        ContentPublisher(
            "portfolio",
            PortfolioItem,
            PortfolioService(
                PortfolioItemRepository(session),
                PortfolioCategoryRepository(session),
                TagRepository(session),
                ContentMediaRepository(session),
                BeforeAfterPairRepository(session),
            ),
        ),
        ContentPublisher(
            "service",
            Service,
            ServiceService(
                ServiceRepository(session),
                ServiceCategoryRepository(session),
                TagRepository(session),
                ContentMediaRepository(session),
                ServiceListItemRepository(session),
            ),
        ),
    ]


class PublishScheduledService:
    def __init__(self, session: AsyncSession, publishers: list[ContentPublisher]):
        self.session = session
        self.publishers = publishers

    async def run(self, now: datetime | None = None) -> SchedulerRunOut:
        """Publish every item whose scheduled time has arrived, across all
        configured modules. `now` is injectable for deterministic tests;
        production passes None → current UTC time."""
        effective_now = now or datetime.now(timezone.utc)
        published: list[PublishedItemOut] = []
        failed: list[FailedItemOut] = []

        for publisher in self.publishers:
            due_ids = await select_due_scheduled_ids(
                self.session, publisher.model, effective_now
            )
            for item_id in due_ids:
                try:
                    # SAVEPOINT per item: a failure here rolls back only this
                    # item, not the whole sweep (BUG-2 failure-isolation).
                    async with self.session.begin_nested():
                        await publisher.publish(item_id)
                    published.append(PublishedItemOut(module=publisher.name, id=item_id))
                except Exception as exc:  # noqa: BLE001 — batch job: isolate & report, don't abort
                    # Recorded, not swallowed: the failure is surfaced in the
                    # response so an operator sees which items couldn't be
                    # published and why. The savepoint has already undone any
                    # partial write for this item.
                    failed.append(
                        FailedItemOut(
                            module=publisher.name,
                            id=item_id,
                            error=f"{type(exc).__name__}: {exc}",
                        )
                    )
                    logger.warning(
                        "scheduled_publish_item_failed",
                        module=publisher.name,
                        item_id=str(item_id),
                        error=str(exc),
                    )

        logger.info(
            "scheduled_publish_sweep_complete",
            published=len(published),
            failed=len(failed),
        )
        return SchedulerRunOut(
            ran_at=effective_now,
            published_count=len(published),
            failed_count=len(failed),
            published=published,
            failed=failed,
        )
