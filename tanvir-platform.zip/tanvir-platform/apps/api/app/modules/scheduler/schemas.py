"""Scheduler schemas (Sprint 10 BUG-2). The response of the due-publish
sweep — a per-run report of what was published and what failed, so an
operator (or the calling cron's logs) can see exactly what happened rather
than a bare 200."""

import uuid
from datetime import datetime

from pydantic import BaseModel


class PublishedItemOut(BaseModel):
    module: str
    id: uuid.UUID


class FailedItemOut(BaseModel):
    module: str
    id: uuid.UUID
    error: str


class SchedulerRunOut(BaseModel):
    """Result of one due-publish sweep. `failed` is populated (not raised)
    when an individual item can't be published — e.g. a scheduled post
    whose featured image was deleted before its publish time — so one bad
    item never aborts the batch."""

    ran_at: datetime
    published_count: int
    failed_count: int
    published: list[PublishedItemOut]
    failed: list[FailedItemOut]
