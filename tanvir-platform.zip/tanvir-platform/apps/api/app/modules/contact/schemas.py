"""Contact / inquiry schemas.

`CreateInquiryIn` is the public submission shape (low-friction: only name,
email, and message required). `InquiryOut` / `InquiryListItem` are the
authenticated dashboard read shapes. `UpdateInquiryStatusIn` drives the
lifecycle transitions.
"""

import re
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.modules.contact.models import INQUIRY_STATUSES

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class CreateInquiryIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=160)
    email: str = Field(..., min_length=1, max_length=254)
    company: str | None = Field(default=None, max_length=160)
    service: str | None = Field(default=None, max_length=120)
    project_type: str | None = Field(default=None, max_length=120)
    budget_range: str | None = Field(default=None, max_length=60)
    preferred_contact: str | None = Field(default=None, max_length=60)
    message: str = Field(..., min_length=1, max_length=5000)

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: str) -> str:
        if not _EMAIL_RE.match(value):
            raise ValueError("A valid email address is required")
        return value


class InquiryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    email: str
    company: str | None
    service: str | None
    project_type: str | None
    budget_range: str | None
    preferred_contact: str | None
    message: str
    status: str
    created_at: datetime
    updated_at: datetime


class InquiryListItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    email: str
    company: str | None
    service: str | None
    status: str
    created_at: datetime


class UpdateInquiryStatusIn(BaseModel):
    status: str = Field(...)

    @field_validator("status")
    @classmethod
    def validate_status(cls, value: str) -> str:
        if value not in INQUIRY_STATUSES:
            raise ValueError(f"status must be one of {', '.join(INQUIRY_STATUSES)}")
        return value
