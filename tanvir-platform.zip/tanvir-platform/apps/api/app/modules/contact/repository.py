"""Contact / inquiry repository. Extends BaseRepository for soft-delete +
offset pagination; adds inquiry-specific create and a status-filtered list."""

import uuid
from typing import Any

from sqlalchemy import func, or_, select

from app.modules.contact.models import ContactInquiry
from app.shared.repository_base import BaseRepository


class ContactInquiryRepository(BaseRepository[ContactInquiry]):
    model = ContactInquiry

    async def create(self, **fields: Any) -> ContactInquiry:
        inquiry = ContactInquiry(id=uuid.uuid4(), **fields)
        self.session.add(inquiry)
        await self.session.flush()
        return inquiry

    async def list_inquiries(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        status: str | None = None,
        search: str | None = None,
    ) -> tuple[list[ContactInquiry], int]:
        """Paginated, newest-first, with optional status filter and a simple
        name/email/company search. Soft-deleted rows are excluded."""
        stmt = select(ContactInquiry).where(ContactInquiry.deleted_at.is_(None))
        count_stmt = (
            select(func.count()).select_from(ContactInquiry).where(ContactInquiry.deleted_at.is_(None))
        )

        if status:
            stmt = stmt.where(ContactInquiry.status == status)
            count_stmt = count_stmt.where(ContactInquiry.status == status)

        if search:
            pattern = f"%{search}%"
            condition = or_(
                ContactInquiry.name.ilike(pattern),
                ContactInquiry.email.ilike(pattern),
                ContactInquiry.company.ilike(pattern),
            )
            stmt = stmt.where(condition)
            count_stmt = count_stmt.where(condition)

        stmt = stmt.order_by(ContactInquiry.created_at.desc())
        stmt = stmt.offset((page - 1) * per_page).limit(per_page)

        result = await self.session.execute(stmt)
        total = (await self.session.execute(count_stmt)).scalar_one()
        return list(result.scalars().all()), total

    async def count_recent_from_email(self, email: str, since) -> int:
        """How many inquiries this email has submitted since `since` — the
        rate-limit signal (defends against a single address flooding the
        form)."""
        stmt = (
            select(func.count())
            .select_from(ContactInquiry)
            .where(ContactInquiry.email == email, ContactInquiry.created_at >= since)
        )
        return (await self.session.execute(stmt)).scalar_one()
