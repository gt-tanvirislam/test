"""Contact / inquiry router.

One public endpoint (the lead-capture form) and four authenticated
management endpoints. The public `POST /contact` is intentionally unguarded —
it's how anonymous visitors reach out — but it's rate-limited in the service
and writes to a table that has no public read path. Management reads require
`inquiries.view`; lifecycle mutations require `inquiries.manage`.
"""

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.contact.repository import ContactInquiryRepository
from app.modules.contact.schemas import (
    CreateInquiryIn,
    InquiryListItem,
    InquiryOut,
    UpdateInquiryStatusIn,
)
from app.modules.contact.service import ContactInquiryService
from app.modules.settings.repository import SiteSettingsRepository
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/contact", tags=["contact"])


async def _build_service(session: AsyncSession) -> ContactInquiryService:
    """The notification target is the site's configured contact email (from
    SiteSettings). Fetched per-request so a settings change takes effect
    without a restart; falls back to no recipient (log-only) if unset."""
    settings = await SiteSettingsRepository(session).get_singleton()
    return ContactInquiryService(
        ContactInquiryRepository(session),
        notify_to=settings.contact_email,
    )


# ── Public submission ─────────────────────────────────────────────────


@router.post("", summary="Submit a contact inquiry (public)", status_code=201)
async def submit_inquiry(
    request: Request,
    payload: CreateInquiryIn,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    service = await _build_service(session)
    inquiry = await service.submit(payload)
    # Echo back only a minimal confirmation — never the full record, and
    # nothing that would let an anonymous caller enumerate inquiries.
    return success_envelope(
        {"id": str(inquiry.id), "status": inquiry.status}, request
    )


# ── Authenticated management ──────────────────────────────────────────


@router.get("/inquiries", summary="List contact inquiries")
async def list_inquiries(
    request: Request,
    page: int = 1,
    per_page: int = 20,
    status: str | None = None,
    search: str | None = None,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("inquiries.view")),
) -> dict[str, Any]:
    service = await _build_service(session)
    items, total = await service.list(
        page=page, per_page=per_page, status=status, search=search
    )
    return {
        "data": [
            InquiryListItem.model_validate(i).model_dump(mode="json") for i in items
        ],
        "meta": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "total_pages": max(1, (total + per_page - 1) // per_page),
        },
    }


@router.get("/inquiries/{inquiry_id}", summary="Get a single inquiry")
async def get_inquiry(
    request: Request,
    inquiry_id: uuid.UUID,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("inquiries.view")),
) -> dict[str, Any]:
    service = await _build_service(session)
    inquiry = await service.get(inquiry_id)
    return success_envelope(
        InquiryOut.model_validate(inquiry).model_dump(mode="json"), request
    )


@router.patch("/inquiries/{inquiry_id}/status", summary="Update inquiry status")
async def update_inquiry_status(
    request: Request,
    inquiry_id: uuid.UUID,
    payload: UpdateInquiryStatusIn,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("inquiries.manage")),
) -> dict[str, Any]:
    service = await _build_service(session)
    inquiry = await service.update_status(inquiry_id, payload.status)
    return success_envelope(
        InquiryOut.model_validate(inquiry).model_dump(mode="json"), request
    )


@router.delete("/inquiries/{inquiry_id}", summary="Delete an inquiry", status_code=204)
async def delete_inquiry(
    inquiry_id: uuid.UUID,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("inquiries.manage")),
) -> None:
    service = await _build_service(session)
    await service.delete(inquiry_id)
