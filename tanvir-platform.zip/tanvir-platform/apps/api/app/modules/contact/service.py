"""Contact / inquiry service.

Submission path (public): rate-limit by email → persist → best-effort
notify. Persistence happens before notification so a mail failure never
loses a lead. Rate limiting is a soft cap per email over a rolling window —
enough to blunt a single address flooding the form without a heavyweight
dependency.

Management path (authenticated): list/get/status-transition/soft-delete.
"""

from datetime import datetime, timedelta, timezone

from app.core.exceptions import NotFoundError, RateLimitedError
from app.modules.contact.models import ContactInquiry
from app.modules.contact.repository import ContactInquiryRepository
from app.modules.contact.schemas import CreateInquiryIn
from app.shared.notifications import notify_new_inquiry

# Soft rate limit: at most N inquiries from one email within the window.
_RATE_LIMIT_MAX = 5
_RATE_LIMIT_WINDOW = timedelta(hours=1)


class ContactInquiryService:
    def __init__(self, repository: ContactInquiryRepository, *, notify_to: str | None = None):
        self.repository = repository
        self.notify_to = notify_to

    async def submit(self, payload: CreateInquiryIn) -> ContactInquiry:
        since = datetime.now(timezone.utc) - _RATE_LIMIT_WINDOW
        recent = await self.repository.count_recent_from_email(payload.email, since)
        if recent >= _RATE_LIMIT_MAX:
            raise RateLimitedError(
                "You've sent several messages recently. Please wait a little while before sending another."
            )

        inquiry = await self.repository.create(
            name=payload.name.strip(),
            email=payload.email.strip(),
            company=(payload.company or None),
            service=(payload.service or None),
            project_type=(payload.project_type or None),
            budget_range=(payload.budget_range or None),
            preferred_contact=(payload.preferred_contact or None),
            message=payload.message.strip(),
        )

        # Best-effort, post-persist. notify_new_inquiry never raises.
        await notify_new_inquiry(
            to_email=self.notify_to,
            inquiry_id=str(inquiry.id),
            name=inquiry.name,
            email=inquiry.email,
        )
        return inquiry

    async def list(
        self, *, page: int, per_page: int, status: str | None, search: str | None
    ) -> tuple[list[ContactInquiry], int]:
        return await self.repository.list_inquiries(
            page=page, per_page=per_page, status=status, search=search
        )

    async def get(self, inquiry_id) -> ContactInquiry:
        inquiry = await self.repository.get_by_id(inquiry_id)
        if inquiry is None:
            raise NotFoundError("Inquiry not found")
        return inquiry

    async def update_status(self, inquiry_id, status: str) -> ContactInquiry:
        inquiry = await self.get(inquiry_id)
        inquiry.status = status
        await self.repository.session.flush()
        return inquiry

    async def delete(self, inquiry_id) -> None:
        inquiry = await self.get(inquiry_id)
        await self.repository.soft_delete(inquiry)
