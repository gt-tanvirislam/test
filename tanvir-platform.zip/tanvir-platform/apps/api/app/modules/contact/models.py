"""Contact / inquiry model (agency lead-capture).

A public visitor submits a project inquiry from the Contact page; it's
stored here and managed in the dashboard. Never exposed through any public
read endpoint — only the authenticated `inquiries.view`/`inquiries.manage`
screens read it.

Status is a simple lifecycle: `new` → `contacted` → `resolved` (or
`archived`). Kept as a plain string (validated at the schema layer),
consistent with how ContentStatus is handled elsewhere.
"""

import uuid

from sqlalchemy import String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import AuditMixin, Base, SoftDeleteMixin

INQUIRY_STATUS_NEW = "new"
INQUIRY_STATUS_CONTACTED = "contacted"
INQUIRY_STATUS_RESOLVED = "resolved"
INQUIRY_STATUS_ARCHIVED = "archived"
INQUIRY_STATUSES = (
    INQUIRY_STATUS_NEW,
    INQUIRY_STATUS_CONTACTED,
    INQUIRY_STATUS_RESOLVED,
    INQUIRY_STATUS_ARCHIVED,
)


class ContactInquiry(Base, AuditMixin, SoftDeleteMixin):
    __tablename__ = "contact_inquiries"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    name: Mapped[str] = mapped_column(String(160), nullable=False)
    email: Mapped[str] = mapped_column(String(254), nullable=False)
    company: Mapped[str | None] = mapped_column(String(160), nullable=True)

    # Conversion-qualifying fields — all optional so the form stays low
    # friction, but captured when the visitor provides them.
    service: Mapped[str | None] = mapped_column(String(120), nullable=True)
    project_type: Mapped[str | None] = mapped_column(String(120), nullable=True)
    budget_range: Mapped[str | None] = mapped_column(String(60), nullable=True)
    preferred_contact: Mapped[str | None] = mapped_column(String(60), nullable=True)

    message: Mapped[str] = mapped_column(Text, nullable=False)

    status: Mapped[str] = mapped_column(String(20), nullable=False, default=INQUIRY_STATUS_NEW)
