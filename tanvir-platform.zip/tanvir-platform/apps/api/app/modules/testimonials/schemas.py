"""Testimonial schemas.

`TestimonialOut` is the full dashboard read shape. `PublicTestimonialOut`
is the trimmed shape exposed on the public site — no internal flags, no
timestamps, just what the UI renders. Create/Update are the dashboard write
shapes; Update is a partial PATCH (all-optional, `model_fields_set` decides
what's written).
"""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class CreateTestimonialIn(BaseModel):
    quote: str = Field(..., min_length=1, max_length=2000)
    author_name: str = Field(..., min_length=1, max_length=160)
    author_title: str | None = Field(default=None, max_length=160)
    author_company: str | None = Field(default=None, max_length=160)
    avatar_image_id: uuid.UUID | None = None
    is_published: bool = False
    is_featured: bool = False
    sort_order: int = 0


class UpdateTestimonialIn(BaseModel):
    quote: str | None = Field(default=None, min_length=1, max_length=2000)
    author_name: str | None = Field(default=None, min_length=1, max_length=160)
    author_title: str | None = Field(default=None, max_length=160)
    author_company: str | None = Field(default=None, max_length=160)
    avatar_image_id: uuid.UUID | None = None
    is_published: bool | None = None
    is_featured: bool | None = None
    sort_order: int | None = None


class TestimonialOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    quote: str
    author_name: str
    author_title: str | None
    author_company: str | None
    avatar_image_id: uuid.UUID | None
    is_published: bool
    is_featured: bool
    sort_order: int
    created_at: datetime
    updated_at: datetime


class PublicTestimonialOut(BaseModel):
    """Public projection — internal flags and timestamps deliberately omitted."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    quote: str
    author_name: str
    author_title: str | None
    author_company: str | None
    avatar_image_id: uuid.UUID | None
