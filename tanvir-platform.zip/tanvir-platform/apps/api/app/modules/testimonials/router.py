"""Testimonials router.

Public: `GET /testimonials` returns published testimonials only (optionally
featured-only) — this is what the public site renders, and it returns an
empty list when none exist (no fake social proof). Management: full CRUD
gated by `testimonials.view` (reads) / `testimonials.manage` (writes).
"""

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.testimonials.repository import TestimonialRepository
from app.modules.testimonials.schemas import (
    CreateTestimonialIn,
    PublicTestimonialOut,
    TestimonialOut,
    UpdateTestimonialIn,
)
from app.modules.testimonials.service import TestimonialService
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/testimonials", tags=["testimonials"])


def get_testimonial_service(
    session: AsyncSession = Depends(get_db_session),
) -> TestimonialService:
    return TestimonialService(TestimonialRepository(session))


# ── Public ────────────────────────────────────────────────────────────


@router.get("", summary="List published testimonials (public)")
async def list_public_testimonials(
    request: Request,
    featured: bool = False,
    service: TestimonialService = Depends(get_testimonial_service),
) -> dict[str, Any]:
    items = await service.list_published(featured_only=featured)
    return success_envelope(
        [PublicTestimonialOut.model_validate(i).model_dump(mode="json") for i in items],
        request,
    )


# ── Management ────────────────────────────────────────────────────────


@router.get("/manage", summary="List all testimonials (dashboard)")
async def list_all_testimonials(
    request: Request,
    service: TestimonialService = Depends(get_testimonial_service),
    _: CurrentUserOut = Depends(require_permission("testimonials.view")),
) -> dict[str, Any]:
    items = await service.list_all()
    return success_envelope(
        [TestimonialOut.model_validate(i).model_dump(mode="json") for i in items],
        request,
    )


@router.get("/manage/{testimonial_id}", summary="Get a single testimonial (dashboard)")
async def get_testimonial(
    request: Request,
    testimonial_id: uuid.UUID,
    service: TestimonialService = Depends(get_testimonial_service),
    _: CurrentUserOut = Depends(require_permission("testimonials.view")),
) -> dict[str, Any]:
    testimonial = await service.get(testimonial_id)
    return success_envelope(
        TestimonialOut.model_validate(testimonial).model_dump(mode="json"), request
    )


@router.post("/manage", summary="Create a testimonial", status_code=201)
async def create_testimonial(
    request: Request,
    payload: CreateTestimonialIn,
    service: TestimonialService = Depends(get_testimonial_service),
    _: CurrentUserOut = Depends(require_permission("testimonials.manage")),
) -> dict[str, Any]:
    testimonial = await service.create(payload)
    return success_envelope(
        TestimonialOut.model_validate(testimonial).model_dump(mode="json"), request
    )


@router.patch("/manage/{testimonial_id}", summary="Update a testimonial")
async def update_testimonial(
    request: Request,
    testimonial_id: uuid.UUID,
    payload: UpdateTestimonialIn,
    service: TestimonialService = Depends(get_testimonial_service),
    _: CurrentUserOut = Depends(require_permission("testimonials.manage")),
) -> dict[str, Any]:
    testimonial = await service.update(testimonial_id, payload)
    return success_envelope(
        TestimonialOut.model_validate(testimonial).model_dump(mode="json"), request
    )


@router.delete("/manage/{testimonial_id}", summary="Delete a testimonial", status_code=204)
async def delete_testimonial(
    testimonial_id: uuid.UUID,
    service: TestimonialService = Depends(get_testimonial_service),
    _: CurrentUserOut = Depends(require_permission("testimonials.manage")),
) -> None:
    await service.delete(testimonial_id)
