"""Testimonial repository. Extends BaseRepository for soft-delete + get_by_id;
adds ordered list helpers for the dashboard (all rows) and the public site
(published only)."""

import uuid
from typing import Any

from sqlalchemy import select

from app.modules.testimonials.models import Testimonial
from app.shared.repository_base import BaseRepository


class TestimonialRepository(BaseRepository[Testimonial]):
    model = Testimonial

    async def create(self, **fields: Any) -> Testimonial:
        testimonial = Testimonial(id=uuid.uuid4(), **fields)
        self.session.add(testimonial)
        await self.session.flush()
        return testimonial

    async def list_all(self) -> list[Testimonial]:
        """Dashboard list — every non-deleted testimonial, manual order first,
        newest as the tiebreak."""
        stmt = (
            select(Testimonial)
            .where(Testimonial.deleted_at.is_(None))
            .order_by(Testimonial.sort_order.asc(), Testimonial.created_at.desc())
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def list_published(self, *, featured_only: bool = False) -> list[Testimonial]:
        """Public list — published rows only, same ordering. `featured_only`
        narrows to the pinned subset for highlight strips."""
        stmt = (
            select(Testimonial)
            .where(Testimonial.deleted_at.is_(None), Testimonial.is_published.is_(True))
            .order_by(Testimonial.sort_order.asc(), Testimonial.created_at.desc())
        )
        if featured_only:
            stmt = stmt.where(Testimonial.is_featured.is_(True))
        result = await self.session.execute(stmt)
        return list(result.scalars().all())
