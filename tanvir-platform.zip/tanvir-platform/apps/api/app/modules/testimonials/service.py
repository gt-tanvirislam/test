"""Testimonial service. Thin orchestration over the repository — create,
partial update (only fields present in the request body), soft-delete, and
the two read paths (all / published)."""

import uuid

from app.core.exceptions import NotFoundError
from app.modules.testimonials.models import Testimonial
from app.modules.testimonials.repository import TestimonialRepository
from app.modules.testimonials.schemas import CreateTestimonialIn, UpdateTestimonialIn


class TestimonialService:
    def __init__(self, repository: TestimonialRepository):
        self.repository = repository

    async def create(self, payload: CreateTestimonialIn) -> Testimonial:
        data = payload.model_dump()
        # Normalise the free-text fields; drop-to-None for blank optionals.
        data["quote"] = data["quote"].strip()
        data["author_name"] = data["author_name"].strip()
        return await self.repository.create(**data)

    async def update(self, testimonial_id: uuid.UUID, payload: UpdateTestimonialIn) -> Testimonial:
        testimonial = await self.get(testimonial_id)
        provided = payload.model_dump(include=payload.model_fields_set)
        for field, value in provided.items():
            if field in ("quote", "author_name") and isinstance(value, str):
                value = value.strip()
            setattr(testimonial, field, value)
        await self.repository.session.flush()
        return testimonial

    async def get(self, testimonial_id: uuid.UUID) -> Testimonial:
        testimonial = await self.repository.get_by_id(testimonial_id)
        if testimonial is None:
            raise NotFoundError("Testimonial not found")
        return testimonial

    async def list_all(self) -> list[Testimonial]:
        return await self.repository.list_all()

    async def list_published(self, *, featured_only: bool = False) -> list[Testimonial]:
        return await self.repository.list_published(featured_only=featured_only)

    async def delete(self, testimonial_id: uuid.UUID) -> None:
        testimonial = await self.get(testimonial_id)
        await self.repository.soft_delete(testimonial)
