"""Testimonial model (agency social proof).

A testimonial is a real client quote the site owner enters in the
dashboard. Nothing here is fabricated — the public site only renders rows
that actually exist and are published, so an empty table simply means no
testimonials section renders (honest-by-default, per the project's no-fake-
social-proof rule).

`is_published` gates public visibility; `is_featured` lets the owner pin a
subset (e.g. a homepage highlight strip). `sort_order` gives manual ordering
independent of creation time. `avatar_image_id` is an optional reference into
`media_assets` (same bare-UUID convention as Service.featured_image_id — no
DB-level FK, resolved at the serialization layer).
"""

import uuid

from sqlalchemy import Boolean, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import AuditMixin, Base, SoftDeleteMixin


class Testimonial(Base, AuditMixin, SoftDeleteMixin):
    __tablename__ = "testimonials"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # The quote and who said it. Author name is required; the rest is optional
    # context that strengthens the quote when present.
    quote: Mapped[str] = mapped_column(Text, nullable=False)
    author_name: Mapped[str] = mapped_column(String(160), nullable=False)
    author_title: Mapped[str | None] = mapped_column(String(160), nullable=True)
    author_company: Mapped[str | None] = mapped_column(String(160), nullable=True)

    avatar_image_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    is_published: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_featured: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
