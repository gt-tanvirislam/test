"""
Blog repository (Phase 2.8 §3, §4). Extends BaseRepository (Sprint 2) —
its generic `list()` handles equality filters, but Blog needs richer
filtering (search across title/excerpt, tag membership, status) that
doesn't fit BaseRepository's plain equality-filter dict, so this
overrides `list_filtered` as a dedicated method rather than forcing
BaseRepository's generic method to grow special cases for one module.
"""

import uuid

from sqlalchemy import func, or_, select
from sqlalchemy.orm import selectinload

from app.modules.blog.models import BlogCategory, BlogPost, blog_post_tags
from app.shared.content_query import list_filtered_content
from app.shared.repository_base import BaseRepository


class BlogPostRepository(BaseRepository[BlogPost]):
    model = BlogPost

    def _detail_query(self):
        """Full eager-load — category + tags. Used for single-post reads
        (detail view, editor load) where both are actually rendered."""
        return select(BlogPost).options(selectinload(BlogPost.category), selectinload(BlogPost.tags))

    def _list_query(self):
        """List-view query (Sprint 5 fix): eager-loads category only —
        `BlogPostListItemOut` never includes tags, so loading them for
        every row in a paginated list was pure waste. Detail reads still
        use `_detail_query()` above."""
        return select(BlogPost).options(selectinload(BlogPost.category))

    async def get_by_id_full(self, post_id: uuid.UUID) -> BlogPost | None:
        stmt = self._detail_query().where(BlogPost.id == post_id, BlogPost.deleted_at.is_(None))
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_slug(self, slug: str, *, published_only: bool = False) -> BlogPost | None:
        stmt = self._detail_query().where(BlogPost.slug == slug, BlogPost.deleted_at.is_(None))
        if published_only:
            stmt = stmt.where(BlogPost.status == "published")
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def slug_exists(self, slug: str, *, exclude_id: uuid.UUID | None = None) -> bool:
        """Backs the dashboard's live slug-availability check (Sprint 5
        — wiring TitleSlugFields' checkAvailability prop to a real
        endpoint for the first time). Reuses the same existence-check
        shape as app/shared/slug.py's internal `_slug_exists`, but that
        helper is intentionally private to the slug-generation flow —
        this is a distinct, public-facing "can I use this?" query."""
        stmt = select(BlogPost.id).where(BlogPost.slug == slug, BlogPost.deleted_at.is_(None))
        if exclude_id:
            stmt = stmt.where(BlogPost.id != exclude_id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none() is not None

    async def list_filtered(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        status: str | None = None,
        category_id: uuid.UUID | None = None,
        tag_id: uuid.UUID | None = None,
        author_id: uuid.UUID | None = None,
        search: str | None = None,
        featured: bool | None = None,
    ) -> tuple[list[BlogPost], int]:
        """
        Backs the dashboard list view's filter bar and, with
        `status="published"` forced, the public blog index (see
        `list_published` below). Delegates the mechanical filter/search/
        paginate work to the shared `list_filtered_content()` helper
        (Sprint 8) — this method's job is only to declare which columns
        are filterable/searchable for Blog specifically, matching Phase
        2.8 §4's injection-prevention whitelist principle.
        """
        list_stmt = self._list_query().where(BlogPost.deleted_at.is_(None))
        count_stmt = select(func.count(func.distinct(BlogPost.id))).select_from(BlogPost).where(
            BlogPost.deleted_at.is_(None)
        )

        return await list_filtered_content(
            self.session,
            list_stmt=list_stmt,
            count_stmt=count_stmt,
            page=page,
            per_page=per_page,
            equality_filters={
                BlogPost.status: status,
                BlogPost.category_id: category_id,
                BlogPost.author_id: author_id,
                BlogPost.featured: featured,
            },
            search_columns=[BlogPost.title, BlogPost.excerpt],
            search_term=search,
            tag_join_table=blog_post_tags,
            tag_id_column=blog_post_tags.c.tag_id,
            tag_id=tag_id,
            order_by_column=BlogPost.updated_at,
        )

    async def list_published(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        category_slug: str | None = None,
        tag_slug: str | None = None,
        search: str | None = None,
    ) -> tuple[list[BlogPost], int]:
        """
        Public blog API (Sprint 5's §4). Deliberately delegates to
        `list_filtered` with `status="published"` forced, rather than a
        parallel query implementation — the only genuinely public-specific
        need is resolving category/tag by SLUG (public URLs use slugs,
        the dashboard filter bar uses IDs since it already has them from
        a loaded dropdown), so that resolution happens here before
        delegating.
        """
        category_id = None
        if category_slug:
            category = await self.session.execute(
                select(BlogCategory.id).where(BlogCategory.slug == category_slug)
            )
            category_id = category.scalar_one_or_none()
            if category_id is None:
                return [], 0  # unknown category slug — empty result, not an error

        tag_id = None
        if tag_slug:
            from app.modules.taxonomy.models import Tag

            tag = await self.session.execute(select(Tag.id).where(Tag.slug == tag_slug))
            tag_id = tag.scalar_one_or_none()
            if tag_id is None:
                return [], 0

        return await self.list_filtered(
            page=page,
            per_page=per_page,
            status="published",
            category_id=category_id,
            tag_id=tag_id,
            search=search,
        )


class BlogCategoryRepository(BaseRepository[BlogCategory]):
    model = BlogCategory

    async def list_all(self) -> list[BlogCategory]:
        result = await self.session.execute(select(BlogCategory).order_by(BlogCategory.name))
        return list(result.scalars().all())

    async def get_by_name(self, name: str) -> BlogCategory | None:
        result = await self.session.execute(select(BlogCategory).where(BlogCategory.name == name))
        return result.scalar_one_or_none()
