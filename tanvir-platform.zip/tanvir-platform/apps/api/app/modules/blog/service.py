"""
Blog service (Phase 2.8 §1). This is the sprint's core reference
implementation: composes ContentLifecycleService (Sprint 3) for state
transitions, generate_unique_slug (Sprint 3) for slugs, and
get_or_create_many (Sprint 4 taxonomy) for tags — none of that logic is
reimplemented here, only orchestrated.

A future PortfolioService follows this exact composition shape.
"""

import uuid
from datetime import datetime

from app.core.exceptions import NotFoundError, ValidationError
from app.modules.blog.models import BlogPost, BlogPostRevision
from app.modules.blog.repository import BlogCategoryRepository, BlogPostRepository
from app.modules.blog.schemas import CreateBlogPostIn, UpdateBlogPostIn
from app.modules.taxonomy.repository import TagRepository
from app.shared.publishable import ContentLifecycleService, ContentStatus
from app.shared.revision import create_revision
from app.shared.slug import generate_unique_slug

WORDS_PER_MINUTE = 200


class BlogService:
    def __init__(
        self,
        post_repository: BlogPostRepository,
        category_repository: BlogCategoryRepository,
        tag_repository: TagRepository,
        lifecycle: ContentLifecycleService | None = None,
    ):
        self.post_repository = post_repository
        self.category_repository = category_repository
        self.tag_repository = tag_repository
        self.lifecycle = lifecycle or ContentLifecycleService()

    async def create(self, author_id: uuid.UUID, payload: CreateBlogPostIn) -> BlogPost:
        slug = payload.slug or await generate_unique_slug(
            self.post_repository.session, BlogPost, payload.title
        )
        tags = await self.tag_repository.get_or_create_many(payload.tag_names)

        post = BlogPost(
            id=uuid.uuid4(),
            author_id=author_id,
            category_id=payload.category_id,
            title=payload.title,
            slug=slug,
            excerpt=payload.excerpt,
            body_mdx=payload.body_mdx,
            featured_image_id=payload.featured_image_id,
            canonical_url=payload.canonical_url,
            featured=payload.featured,
            reading_time_minutes=_estimate_reading_time(payload.body_mdx),
            status=ContentStatus.DRAFT.value,
        )
        post.tags = tags

        self.post_repository.session.add(post)
        await self.post_repository.session.flush()
        return post

    async def update(self, post_id: uuid.UUID, payload: UpdateBlogPostIn) -> BlogPost:
        """
        Handles autosave (Sprint 3's useAutosave hook calls this) AND
        manual edits — both are the same operation, updating the draft
        content in place, per Phase 2.2 §5's "drafts and published
        content share the same table" decision: editing a PUBLISHED post
        also goes through this method, live, without creating a revision
        (a revision is created explicitly by save_version/publish only,
        per Phase 2.2 §21).
        """
        post = await self.post_repository.get_by_id_full(post_id)
        if post is None:
            raise NotFoundError("Blog post not found")

        data = payload.model_dump(exclude_unset=True)

        if "title" in data and data["title"] is not None:
            post.title = data["title"]
        if "slug" in data and data["slug"]:
            # Slug immutability-after-publish is enforced at the app layer
            # per Phase 2.2 §4.2's design note — not blocked outright here
            # (an explicit override is allowed), but a future sprint adds
            # the redirects-table write this triggers (Phase 2.1 §1).
            post.slug = await generate_unique_slug(
                self.post_repository.session, BlogPost, data["slug"], exclude_id=post.id
            )
        if "excerpt" in data:
            post.excerpt = data["excerpt"]
        if "body_mdx" in data and data["body_mdx"] is not None:
            post.body_mdx = data["body_mdx"]
            post.reading_time_minutes = _estimate_reading_time(data["body_mdx"])
        if "category_id" in data:
            post.category_id = data["category_id"]
        if "featured_image_id" in data:
            post.featured_image_id = data["featured_image_id"]
        if "canonical_url" in data:
            post.canonical_url = data["canonical_url"]
        if "featured" in data and data["featured"] is not None:
            post.featured = data["featured"]
        if "tag_names" in data and data["tag_names"] is not None:
            post.tags = await self.tag_repository.get_or_create_many(data["tag_names"])
        if "author_id" in data and data["author_id"] is not None:
            # Reassignment permission is enforced at the route level
            # (content.edit_any, per Phase 2.3 §2's matrix — only
            # editor+ can reassign, matching who can edit any post at all).
            post.author_id = data["author_id"]

        await self.post_repository.session.flush()
        return post

    async def delete(self, post_id: uuid.UUID) -> None:
        post = await self.post_repository.get_by_id(post_id)
        if post is None:
            raise NotFoundError("Blog post not found")
        await self.post_repository.soft_delete(post)

    async def restore(self, post_id: uuid.UUID) -> BlogPost:
        post = await self.post_repository.get_by_id(post_id, include_deleted=True)
        if post is None:
            raise NotFoundError("Blog post not found")
        await self.post_repository.restore(post)
        return post

    # ── Lifecycle transitions — delegate to ContentLifecycleService,
    # only adding blog-specific validation and revision snapshots ────────

    async def publish(self, post_id: uuid.UUID, actor_id: uuid.UUID) -> BlogPost:
        post = await self.post_repository.get_by_id_full(post_id)
        if post is None:
            raise NotFoundError("Blog post not found")

        if not post.featured_image_id or not post.excerpt:
            raise ValidationError(
                "Featured image and excerpt are required to publish",
                fields={
                    "featured_image_id": "Required" if not post.featured_image_id else "",
                    "excerpt": "Required" if not post.excerpt else "",
                },
            )

        self.lifecycle.publish(post)
        await self._create_revision(post, actor_id)
        await self.post_repository.session.flush()
        return post

    async def unpublish(self, post_id: uuid.UUID) -> BlogPost:
        post = await self.post_repository.get_by_id_full(post_id)
        if post is None:
            raise NotFoundError("Blog post not found")
        self.lifecycle.unpublish(post)
        await self.post_repository.session.flush()
        return post

    async def schedule(self, post_id: uuid.UUID, scheduled_at: datetime) -> BlogPost:
        post = await self.post_repository.get_by_id_full(post_id)
        if post is None:
            raise NotFoundError("Blog post not found")
        self.lifecycle.schedule(post, scheduled_at)
        await self.post_repository.session.flush()
        return post

    async def archive(self, post_id: uuid.UUID) -> BlogPost:
        post = await self.post_repository.get_by_id_full(post_id)
        if post is None:
            raise NotFoundError("Blog post not found")
        self.lifecycle.archive(post)
        await self.post_repository.session.flush()
        return post

    async def restore_from_archive(self, post_id: uuid.UUID) -> BlogPost:
        post = await self.post_repository.get_by_id_full(post_id)
        if post is None:
            raise NotFoundError("Blog post not found")
        self.lifecycle.restore_from_archive(post)
        await self.post_repository.session.flush()
        return post

    async def save_version(self, post_id: uuid.UUID, actor_id: uuid.UUID) -> BlogPost:
        """Explicit 'Save Version' action (Phase 2.4 §4) — creates a
        revision snapshot without changing publish status."""
        post = await self.post_repository.get_by_id_full(post_id)
        if post is None:
            raise NotFoundError("Blog post not found")
        await self._create_revision(post, actor_id)
        return post

    async def _create_revision(self, post: BlogPost, actor_id: uuid.UUID) -> None:
        snapshot = {
            "title": post.title,
            "slug": post.slug,
            "excerpt": post.excerpt,
            "body_mdx": post.body_mdx,
            "category_id": str(post.category_id) if post.category_id else None,
            "featured_image_id": str(post.featured_image_id) if post.featured_image_id else None,
            "tag_names": [t.name for t in post.tags],
        }
        create_revision(
            self.post_repository.session,
            BlogPostRevision,
            entity_fk_field="blog_post_id",
            entity_id=post.id,
            snapshot=snapshot,
            actor_id=actor_id,
        )


def _estimate_reading_time(body_mdx: str) -> int:
    word_count = len(body_mdx.split())
    return max(1, round(word_count / WORDS_PER_MINUTE))
