"""Blog router (Phase 2.3 §5). Reference implementation for every future
content module's router shape."""

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ConflictError, NotFoundError
from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.blog.models import BlogCategory
from app.modules.blog.repository import BlogCategoryRepository, BlogPostRepository
from app.modules.blog.schemas import (
    BlogCategoryOut,
    BlogPostListItemOut,
    BlogPostOut,
    CreateBlogCategoryIn,
    CreateBlogPostIn,
    ScheduleBlogPostIn,
    UpdateBlogPostIn,
)
from app.modules.blog.service import BlogService
from app.modules.taxonomy.repository import TagRepository
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope
from app.shared.slug import generate_unique_slug

router = APIRouter(prefix="/blog", tags=["blog"])


def get_blog_service(session: AsyncSession = Depends(get_db_session)) -> BlogService:
    return BlogService(
        BlogPostRepository(session), BlogCategoryRepository(session), TagRepository(session)
    )


# ── Posts ─────────────────────────────────────────────────────────────


@router.get("/posts", summary="List blog posts")
async def list_posts(
    request: Request,
    page: int = 1,
    per_page: int = 20,
    status: str | None = None,
    category_id: uuid.UUID | None = None,
    tag_id: uuid.UUID | None = None,
    author_id: uuid.UUID | None = None,
    search: str | None = None,
    featured: bool | None = None,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.view_drafts")),
) -> dict[str, Any]:
    repository = BlogPostRepository(session)
    items, total = await repository.list_filtered(
        page=page,
        per_page=per_page,
        status=status,
        category_id=category_id,
        tag_id=tag_id,
        author_id=author_id,
        search=search,
        featured=featured,
    )
    return {
        "data": [BlogPostListItemOut.model_validate(item).model_dump(mode="json") for item in items],
        "meta": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "total_pages": max(1, (total + per_page - 1) // per_page),
        },
    }


@router.get("/posts/check-slug", summary="Check whether a slug is available")
async def check_slug_availability(
    request: Request,
    slug: str,
    exclude_id: uuid.UUID | None = None,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.create")),
) -> dict[str, Any]:
    """Backs TitleSlugFields' live availability check (Sprint 5 —
    wiring a Sprint 3 prop to a real endpoint for the first time)."""
    repository = BlogPostRepository(session)
    exists = await repository.slug_exists(slug, exclude_id=exclude_id)
    return success_envelope({"available": not exists}, request)


@router.get("/posts/{post_id}", summary="Get a single blog post by ID")
async def get_post(
    request: Request,
    post_id: uuid.UUID,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.view_drafts")),
) -> dict[str, Any]:
    repository = BlogPostRepository(session)
    post = await repository.get_by_id_full(post_id)
    if post is None:
        raise NotFoundError("Blog post not found")
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


@router.post("/posts", summary="Create a draft blog post")
async def create_post(
    request: Request,
    payload: CreateBlogPostIn,
    service: BlogService = Depends(get_blog_service),
    current_user: CurrentUserOut = Depends(require_permission("content.create")),
) -> dict[str, Any]:
    post = await service.create(current_user.id, payload)
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


@router.patch("/posts/{post_id}", summary="Update a blog post (also the autosave target)")
async def update_post(
    request: Request,
    post_id: uuid.UUID,
    payload: UpdateBlogPostIn,
    service: BlogService = Depends(get_blog_service),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    post = await service.update(post_id, payload)
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


@router.delete("/posts/{post_id}", status_code=204, summary="Soft-delete a blog post")
async def delete_post(
    post_id: uuid.UUID,
    service: BlogService = Depends(get_blog_service),
    _: CurrentUserOut = Depends(require_permission("content.delete")),
) -> None:
    await service.delete(post_id)


@router.post("/posts/{post_id}/restore", summary="Restore a soft-deleted post")
async def restore_post(
    request: Request,
    post_id: uuid.UUID,
    service: BlogService = Depends(get_blog_service),
    _: CurrentUserOut = Depends(require_permission("content.restore")),
) -> dict[str, Any]:
    post = await service.restore(post_id)
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


# ── Lifecycle ─────────────────────────────────────────────────────────


@router.post("/posts/{post_id}/publish", summary="Publish a draft or scheduled post")
async def publish_post(
    request: Request,
    post_id: uuid.UUID,
    service: BlogService = Depends(get_blog_service),
    current_user: CurrentUserOut = Depends(require_permission("content.publish")),
) -> dict[str, Any]:
    post = await service.publish(post_id, current_user.id)
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


@router.post("/posts/{post_id}/unpublish", summary="Revert a published post to draft")
async def unpublish_post(
    request: Request,
    post_id: uuid.UUID,
    service: BlogService = Depends(get_blog_service),
    _: CurrentUserOut = Depends(require_permission("content.publish")),
) -> dict[str, Any]:
    post = await service.unpublish(post_id)
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


@router.post("/posts/{post_id}/schedule", summary="Schedule a draft to publish later")
async def schedule_post(
    request: Request,
    post_id: uuid.UUID,
    payload: ScheduleBlogPostIn,
    service: BlogService = Depends(get_blog_service),
    _: CurrentUserOut = Depends(require_permission("content.publish")),
) -> dict[str, Any]:
    post = await service.schedule(post_id, payload.scheduled_at)
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


@router.post("/posts/{post_id}/archive", summary="Archive a post")
async def archive_post(
    request: Request,
    post_id: uuid.UUID,
    service: BlogService = Depends(get_blog_service),
    _: CurrentUserOut = Depends(require_permission("content.delete")),
) -> dict[str, Any]:
    post = await service.archive(post_id)
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


@router.post("/posts/{post_id}/restore-from-archive", summary="Restore an archived post to draft")
async def restore_from_archive(
    request: Request,
    post_id: uuid.UUID,
    service: BlogService = Depends(get_blog_service),
    _: CurrentUserOut = Depends(require_permission("content.restore")),
) -> dict[str, Any]:
    post = await service.restore_from_archive(post_id)
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


@router.post("/posts/{post_id}/save-version", summary="Save an explicit revision snapshot")
async def save_version(
    request: Request,
    post_id: uuid.UUID,
    service: BlogService = Depends(get_blog_service),
    current_user: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    post = await service.save_version(post_id, current_user.id)
    return success_envelope(BlogPostOut.model_validate(post).model_dump(mode="json"), request)


# ── Categories ────────────────────────────────────────────────────────


@router.get("/categories", summary="List blog categories")
async def list_categories(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    repository = BlogCategoryRepository(session)
    categories = await repository.list_all()
    return success_envelope(
        [BlogCategoryOut.model_validate(c).model_dump(mode="json") for c in categories], request
    )


@router.post("/categories", summary="Create a blog category")
async def create_category(
    request: Request,
    payload: CreateBlogCategoryIn,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("content.edit_any")),
) -> dict[str, Any]:
    repository = BlogCategoryRepository(session)
    if await repository.get_by_name(payload.name):
        raise ConflictError("A category with this name already exists")

    slug = await generate_unique_slug(session, BlogCategory, payload.name)
    category = BlogCategory(id=uuid.uuid4(), name=payload.name, slug=slug, description=payload.description)
    session.add(category)
    await session.flush()
    return success_envelope(BlogCategoryOut.model_validate(category).model_dump(mode="json"), request)


# ── Public API (Sprint 5 §4) ─────────────────────────────────────────
# No auth dependency on any route in this section — published content
# only, enforced in the repository layer (list_published/get_by_slug's
# published_only flag), never left to the caller to filter correctly.


@router.get("/public/posts", summary="List published blog posts (public)")
async def list_public_posts(
    request: Request,
    page: int = 1,
    per_page: int = 20,
    category: str | None = None,
    tag: str | None = None,
    search: str | None = None,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    repository = BlogPostRepository(session)
    items, total = await repository.list_published(
        page=page, per_page=per_page, category_slug=category, tag_slug=tag, search=search
    )
    return {
        "data": [BlogPostListItemOut.model_validate(item).model_dump(mode="json") for item in items],
        "meta": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "total_pages": max(1, (total + per_page - 1) // per_page),
        },
    }


@router.get("/public/posts/{slug}", summary="Get a published post by slug, with SEO overrides (public)")
async def get_public_post(
    request: Request,
    slug: str,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    """
    'SEO-ready response' (this sprint's §4 requirement): merges the
    post's own fields with any `seo_metadata` override via the SEO
    module built in Sprint 3 — reused here, not reimplemented, so a
    future public post-detail page gets one response with everything
    `buildMetadata()` (Phase 2.7 §10) needs, rather than two round trips.
    """
    from app.modules.seo.repository import SeoMetadataRepository
    from app.modules.seo.schemas import SeoMetadataOut

    repository = BlogPostRepository(session)
    post = await repository.get_by_slug(slug, published_only=True)
    if post is None:
        raise NotFoundError("Post not found")

    seo_repository = SeoMetadataRepository(session)
    seo_record = await seo_repository.get_for_entity("blog_post", post.id)

    data = BlogPostOut.model_validate(post).model_dump(mode="json")
    data["seo"] = (
        SeoMetadataOut.model_validate(seo_record).model_dump(mode="json") if seo_record else None
    )
    return success_envelope(data, request)
