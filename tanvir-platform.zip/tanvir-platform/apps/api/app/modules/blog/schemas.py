"""Blog schemas (Phase 2.3 §5). Extends nothing structurally shared on
the backend (Pydantic has no cross-module "extend" equivalent to the
frontend's Zod contentBaseSchema) — but every FIELD here maps 1:1 to
Sprint 3's shared contentBaseSchema, so the two stay conceptually
identical even without a literal shared base class."""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.modules.taxonomy.schemas import TagOut


class BlogCategoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    slug: str
    description: str | None


class CreateBlogCategoryIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: str | None = None


class BlogPostOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    author_id: uuid.UUID
    category_id: uuid.UUID | None
    category: BlogCategoryOut | None = None
    tags: list[TagOut] = []

    title: str
    slug: str
    excerpt: str | None
    body_mdx: str
    featured_image_id: uuid.UUID | None
    reading_time_minutes: int | None
    canonical_url: str | None
    featured: bool
    locale: str

    status: str
    scheduled_at: datetime | None
    published_at: datetime | None
    created_at: datetime
    updated_at: datetime


class BlogPostListItemOut(BaseModel):
    """Slimmer shape for list views (Phase 2.4 §4) — omits body_mdx,
    which can be large and isn't needed to render a table row."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str
    slug: str
    status: str
    featured: bool
    category: BlogCategoryOut | None = None
    published_at: datetime | None
    updated_at: datetime


class CreateBlogPostIn(BaseModel):
    title: str = Field(..., min_length=3, max_length=200)
    slug: str | None = None  # auto-generated from title if omitted, per Phase 2.9 §3
    excerpt: str | None = Field(default=None, max_length=300)
    body_mdx: str = ""
    category_id: uuid.UUID | None = None
    tag_names: list[str] = []
    featured_image_id: uuid.UUID | None = None
    canonical_url: str | None = None
    featured: bool = False


class UpdateBlogPostIn(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=200)
    slug: str | None = None
    excerpt: str | None = Field(default=None, max_length=300)
    body_mdx: str | None = None
    category_id: uuid.UUID | None = None
    tag_names: list[str] | None = None
    featured_image_id: uuid.UUID | None = None
    canonical_url: str | None = None
    featured: bool | None = None
    author_id: uuid.UUID | None = None  # Sprint 5 — author reassignment


class ScheduleBlogPostIn(BaseModel):
    scheduled_at: datetime


class BlogPostRevisionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    snapshot: dict
    created_by: uuid.UUID | None
    created_at: datetime
