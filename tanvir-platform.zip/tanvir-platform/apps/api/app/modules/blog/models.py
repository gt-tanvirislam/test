"""
Blog models (Phase 2.2 §4.2). The first concrete content type — composes
every shared piece built in Sprints 0–3 rather than reimplementing any of
it:
  - AuditMixin, SoftDeleteMixin (Sprint 0, app/db/base.py)
  - PublishableStatusMixin (Sprint 3, app/shared/publishable.py)
  - Tag (Sprint 4's taxonomy module, shared table)

This is the blueprint Portfolio/Services/Pages copy the SHAPE of, not the
content — each future content type still gets its own table (Phase 2.2's
explicit design), but the composition pattern below is what gets reused.
"""

import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Table, Column, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import AuditMixin, Base, SoftDeleteMixin
from app.shared.publishable import PublishableStatusMixin

blog_post_tags = Table(
    "blog_post_tags",
    Base.metadata,
    Column("blog_post_id", UUID(as_uuid=True), ForeignKey("blog_posts.id", ondelete="CASCADE"), primary_key=True),
    Column("tag_id", UUID(as_uuid=True), ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
)


class BlogCategory(Base):
    __tablename__ = "blog_categories"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(String, nullable=True)


class BlogPost(Base, AuditMixin, SoftDeleteMixin, PublishableStatusMixin):
    __tablename__ = "blog_posts"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    author_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    category_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("blog_categories.id", ondelete="SET NULL"), nullable=True
    )

    title: Mapped[str] = mapped_column(String, nullable=False)
    slug: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    excerpt: Mapped[str | None] = mapped_column(String, nullable=True)
    body_mdx: Mapped[str] = mapped_column(Text, nullable=False, default="")
    featured_image_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    reading_time_minutes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    canonical_url: Mapped[str | None] = mapped_column(String, nullable=True)
    featured: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    locale: Mapped[str] = mapped_column(String, default="en", nullable=False)  # Phase 2.2 §8, 2.11 §10

    category: Mapped[BlogCategory | None] = relationship()
    tags: Mapped[list["Tag"]] = relationship(secondary=blog_post_tags)  # noqa: F821


class BlogPostRevision(Base):
    """Per-content-type revision table (Phase 2.2 §7's decision — not a
    generic polymorphic revisions table)."""

    __tablename__ = "blog_post_revisions"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    blog_post_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("blog_posts.id", ondelete="CASCADE"), nullable=False
    )
    snapshot: Mapped[dict] = mapped_column(JSONB, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


# Deferred import to avoid a circular import between blog.models and
# taxonomy.models at module load time (Tag is only needed for the type
# hint on BlogPost.tags above).
from app.modules.taxonomy.models import Tag  # noqa: E402
