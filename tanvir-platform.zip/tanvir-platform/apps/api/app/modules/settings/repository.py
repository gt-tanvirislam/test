"""Site settings repository (Phase 2.8 §3). The table is a singleton — one
row addressed by `SITE_SETTINGS_ID` — so instead of generic list/CRUD this
exposes a single `get_singleton()` that lazily creates the row on first read.
Lazy creation makes the API robust even if the seed migration hasn't run
(e.g. a fresh test DB), while the migration still seeds it for production."""

from app.modules.settings.models import SITE_SETTINGS_ID, SiteSettings
from app.shared.repository_base import BaseRepository


class SiteSettingsRepository(BaseRepository[SiteSettings]):
    model = SiteSettings

    async def get_singleton(self) -> SiteSettings:
        existing = await self.session.get(SiteSettings, SITE_SETTINGS_ID)
        if existing is not None:
            return existing

        # First-ever read on a DB where the row wasn't seeded: create it with
        # honest defaults. No commit here — the request's unit-of-work (BUG-1)
        # commits at the boundary.
        settings = SiteSettings(id=SITE_SETTINGS_ID, site_name="Tamvir Islam", social_links=[])
        self.session.add(settings)
        await self.session.flush()
        return settings
