"""Site settings schemas (Phase 2.2 §4.7, Phase 2.3 §1).

`SocialLink` is validated (platform + absolute URL) so the stored JSON can't
drift into malformed shapes the public footer would then have to defend
against. `UpdateSiteSettingsIn` is fully partial — the dashboard PATCHes only
the fields that changed — with `model_fields_set` used by the service to
distinguish "set to null/empty" from "not provided".
"""

import re
import uuid

from pydantic import BaseModel, ConfigDict, Field, field_validator

# Deliberately a pragmatic "looks like an email" check rather than pulling in
# pydantic's EmailStr (which requires the email-validator package, not a
# project dependency). A single public contact address doesn't warrant a new
# runtime dependency; this rejects the obvious malformed cases.
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class SocialLink(BaseModel):
    platform: str = Field(..., min_length=1, max_length=50)
    url: str = Field(..., min_length=1, max_length=500)

    @field_validator("url")
    @classmethod
    def url_must_be_absolute(cls, value: str) -> str:
        if not (value.startswith("http://") or value.startswith("https://")):
            raise ValueError("Social link URL must start with http:// or https://")
        return value


class SiteSettingsOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    site_name: str
    tagline: str | None
    contact_email: str | None
    social_links: list[SocialLink]
    default_meta_description: str | None
    default_og_image_id: uuid.UUID | None


class UpdateSiteSettingsIn(BaseModel):
    """All fields optional — a PATCH updates only what's provided. The service
    inspects `model_fields_set` so omitting a field leaves it untouched, while
    explicitly sending null clears it."""

    site_name: str | None = Field(default=None, min_length=1, max_length=120)
    tagline: str | None = Field(default=None, max_length=200)
    contact_email: str | None = Field(default=None, max_length=254)
    social_links: list[SocialLink] | None = Field(default=None)
    default_meta_description: str | None = Field(default=None, max_length=320)
    default_og_image_id: uuid.UUID | None = Field(default=None)

    @field_validator("contact_email")
    @classmethod
    def validate_contact_email(cls, value: str | None) -> str | None:
        if value is None or value == "":
            return None
        if not _EMAIL_RE.match(value):
            raise ValueError("contact_email must be a valid email address")
        return value
