"""Site settings router (Phase 2.2 §4.7, Phase 2.3 §1).

GET is public: the site name, contact email, and social links render on every
public page (footer/nav chrome via `getSiteConfig()`), so there's no auth gate
on reads. PATCH requires `settings.manage` — the admin-only permission seeded
in migration 0001 and enforced here as the authoritative check.
"""

from typing import Any

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.permissions import require_permission
from app.db.session import get_db_session
from app.modules.settings.repository import SiteSettingsRepository
from app.modules.settings.schemas import SiteSettingsOut, UpdateSiteSettingsIn
from app.modules.settings.service import SiteSettingsService
from app.modules.users.schemas import CurrentUserOut
from app.shared.envelope import success_envelope

router = APIRouter(prefix="/settings", tags=["settings"])


def _service(session: AsyncSession) -> SiteSettingsService:
    return SiteSettingsService(SiteSettingsRepository(session))


@router.get("", summary="Get global site settings")
async def get_settings(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
) -> dict[str, Any]:
    settings = await _service(session).get()
    return success_envelope(
        SiteSettingsOut.model_validate(settings).model_dump(mode="json"), request
    )


@router.patch("", summary="Update global site settings")
async def update_settings(
    request: Request,
    payload: UpdateSiteSettingsIn,
    session: AsyncSession = Depends(get_db_session),
    _: CurrentUserOut = Depends(require_permission("settings.manage")),
) -> dict[str, Any]:
    settings = await _service(session).update(payload)
    return success_envelope(
        SiteSettingsOut.model_validate(settings).model_dump(mode="json"), request
    )
