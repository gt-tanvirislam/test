"""
Site settings model (Phase 2.2 §4.7's `settings` table). A single-row
("singleton") table holding global, site-wide configuration that the public
site and dashboard both read: the brand name, tagline, public contact email,
social profile links, and default SEO values.

Why single-row rather than key/value: every field here is strongly typed and
consumed structurally by `getSiteConfig()` on the frontend (siteName,
contactEmail, socialLinks). A typed row gives real columns, validation, and a
stable API shape; a key/value bag would push parsing/typing onto every reader.
The row is addressed by a fixed sentinel id (`SITE_SETTINGS_ID`) so reads are
deterministic and seeding/upsert is idempotent.

Content policy (Phase 2.10 §8): defaults are honest and empty — no invented
tagline, no fake social links, no placeholder contact address. Empty/NULL is
the correct state until Tamvir provides real values.
"""

import uuid

from sqlalchemy import String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import AuditMixin, Base

# Fixed identity of the one settings row. Reads target this id directly, and
# the migration seeds exactly this row, so there is never more than one.
SITE_SETTINGS_ID = uuid.UUID("00000000-0000-0000-0000-000000000001")


class SiteSettings(Base, AuditMixin):
    __tablename__ = "site_settings"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    site_name: Mapped[str] = mapped_column(String, nullable=False, default="Tamvir Islam")
    tagline: Mapped[str | None] = mapped_column(String, nullable=True)
    contact_email: Mapped[str | None] = mapped_column(String, nullable=True)

    # List of {"platform": str, "url": str}. Empty until real profiles are
    # confirmed — an empty list is correct, not a missing value.
    social_links: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)

    # Site-wide SEO fallbacks used when a page has no per-entity override
    # (consumed by the SEO work in task #17).
    default_meta_description: Mapped[str | None] = mapped_column(Text, nullable=True)
    default_og_image_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), nullable=True
    )
