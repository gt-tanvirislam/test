"""Site settings service (Phase 2.8 §1).

The update path is a partial PATCH: only fields the client actually sent
(`model_fields_set`) are written, so omitting a field leaves it untouched
while explicitly sending it (including null/empty) clears it. `model_dump`
recursively converts nested `SocialLink` models to plain dicts, which is
exactly what the JSONB `social_links` column needs.
"""

from app.modules.settings.models import SiteSettings
from app.modules.settings.repository import SiteSettingsRepository
from app.modules.settings.schemas import UpdateSiteSettingsIn


class SiteSettingsService:
    def __init__(self, repository: SiteSettingsRepository):
        self.repository = repository

    async def get(self) -> SiteSettings:
        return await self.repository.get_singleton()

    async def update(self, payload: UpdateSiteSettingsIn) -> SiteSettings:
        settings = await self.repository.get_singleton()

        # Only the fields present in the request body are applied; nested
        # models are already dicts after model_dump (JSONB-ready).
        provided = payload.model_dump(include=payload.model_fields_set)
        for field, value in provided.items():
            setattr(settings, field, value)

        await self.repository.session.flush()
        return settings

