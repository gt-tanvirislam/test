"""
Storage service abstraction (Phase 2.8 §8, §14's CDN-readiness pattern).
Services depend on this interface, never on the Supabase Storage client
directly — swapping in a CDN-fronted or different storage backend later
is a change to this one file.

NOTE: the Supabase Storage signed-upload-URL request shape below is
implemented against Supabase's documented Storage API, but has not been
exercised against a live project in this environment — verify the exact
request/response shape against current Supabase Storage API docs during
first real integration (this is infrastructure-boundary code, the one
place in this sprint where "matches the docs" needs a live check rather
than being verified by a test run here).
"""

from abc import ABC, abstractmethod

import httpx

from app.core.config import get_settings

BUCKET_BY_FOLDER = {
    "Images": "images",
    "Videos": "videos",
    "Documents": "documents",
    "Blog Media": "blog-media",
    "Portfolio Media": "portfolio-media",
    "Gallery": "gallery",
    "Temporary Uploads": "temporary-uploads",
    "Profile Images": "profile-images",
}


class StorageService(ABC):
    @abstractmethod
    async def create_signed_upload_url(self, bucket: str, path: str) -> str: ...

    @abstractmethod
    def get_public_url(self, bucket: str, path: str) -> str:
        """The single function every media URL flows through (Phase 2.7
        §12, Phase 2.8 §8) — fronting storage with a CDN later changes
        this method's implementation only."""
        ...


class SupabaseStorageService(StorageService):
    def __init__(self) -> None:
        settings = get_settings()
        self._base_url = settings.supabase_url.rstrip("/")
        self._service_key = settings.supabase_service_role_key

    async def create_signed_upload_url(self, bucket: str, path: str) -> str:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self._base_url}/storage/v1/object/upload/sign/{bucket}/{path}",
                headers={"Authorization": f"Bearer {self._service_key}"},
            )
            response.raise_for_status()
            data = response.json()
            # Supabase returns a relative signed URL; resolve to absolute.
            return f"{self._base_url}{data['url']}"

    def get_public_url(self, bucket: str, path: str) -> str:
        return f"{self._base_url}/storage/v1/object/public/{bucket}/{path}"


def get_storage_service() -> StorageService:
    return SupabaseStorageService()
