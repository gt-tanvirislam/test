"""
Domain-level exceptions (Phase 2.8 §6, §13). Services raise these; a
global exception handler (registered in app/main.py) maps each to the
correct HTTP status and the standard error envelope from Phase 2.3 §1.
Routers never construct error responses manually.
"""


class DomainError(Exception):
    """Base class for all domain-level exceptions."""

    code: str = "INTERNAL_ERROR"
    status_code: int = 500

    def __init__(self, message: str, fields: dict[str, str] | None = None):
        super().__init__(message)
        self.message = message
        self.fields = fields


class UnauthorizedError(DomainError):
    code = "UNAUTHORIZED"
    status_code = 401


class ForbiddenError(DomainError):
    code = "FORBIDDEN"
    status_code = 403


class NotFoundError(DomainError):
    code = "NOT_FOUND"
    status_code = 404


class ValidationError(DomainError):
    code = "VALIDATION_ERROR"
    status_code = 422


class ConflictError(DomainError):
    code = "CONFLICT"
    status_code = 409


class RateLimitedError(DomainError):
    code = "RATE_LIMITED"
    status_code = 429
