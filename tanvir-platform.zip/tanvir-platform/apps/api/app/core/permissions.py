"""
Authentication + authorization dependencies (Phase 2.3 §2, Phase 2.8 §5).

`get_current_user` decodes the bearer JWT and resolves the full domain
user (roles + permissions) via UserService — this is the dependency every
protected route in every future module depends on, composed exactly once
here.

`require_permission(key)` is the RBAC enforcement point (Phase 2.3 §2's
matrix, Phase 2.10 §4 — "a new endpoint without an explicit permission
dependency... fails review"). A route declares the permission it needs;
this raises ForbiddenError if the resolved user doesn't have it.
"""

from fastapi import Depends, Header
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ForbiddenError, UnauthorizedError
from app.core.security import decode_supabase_jwt
from app.db.session import get_db_session
from app.modules.users.repository import UserRepository
from app.modules.users.schemas import CurrentUserOut
from app.modules.users.service import UserService


async def get_current_user(
    authorization: str | None = Header(default=None),
    session: AsyncSession = Depends(get_db_session),
) -> CurrentUserOut:
    if not authorization or not authorization.startswith("Bearer "):
        raise UnauthorizedError("Missing or malformed Authorization header")

    token = authorization.removeprefix("Bearer ").strip()
    payload = decode_supabase_jwt(token)

    user_id = payload.get("sub")
    if not user_id:
        raise UnauthorizedError("Token missing subject claim")

    repository = UserRepository(session)
    service = UserService(repository)
    return await service.get_current_user(user_id)


def require_permission(permission_key: str):
    """
    Factory returning a dependency that enforces a single permission.
    Usage: `Depends(require_permission("blog.publish"))` on a route.
    """

    async def dependency(
        current_user: CurrentUserOut = Depends(get_current_user),
    ) -> CurrentUserOut:
        if permission_key not in current_user.permissions:
            raise ForbiddenError(f"Missing required permission: {permission_key}")
        return current_user

    return dependency
