"""
Application configuration — the single source of truth for environment
variables (Phase 1.4, Phase 2.9 §6). Loaded once at startup via
`get_settings()`; a missing required variable raises immediately so the
app fails fast rather than running in a partially-broken state
(Phase 2.10 §13's secrets-management rule).
"""

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    environment: Literal["development", "test", "staging", "production"] = "development"
    log_level: str = "info"

    database_url: str = Field(..., description="Postgres connection string (async driver)")

    supabase_url: str = Field(..., description="Supabase project URL")
    supabase_jwt_secret: str = Field(..., description="Used to validate incoming JWTs")
    supabase_service_role_key: str = Field(
        default="", description="Server-only Supabase key — never exposed to the client"
    )

    cors_allowed_origins: str = Field(
        default="http://localhost:3000", description="Comma-separated list of allowed origins"
    )
    frontend_url: str = Field(default="http://localhost:3000")
    revalidation_secret: str = Field(
        default="", description="Shared secret for the Next.js ISR revalidation webhook"
    )
    scheduler_secret: str = Field(
        default="",
        description=(
            "Shared secret protecting POST /scheduler/run-due — the due-publish "
            "sweep a cron/scheduler calls (BUG-2). A scheduler has no user JWT, so "
            "this endpoint authenticates with this secret instead. Unset (empty) "
            "means the endpoint is disabled and fails closed."
        ),
    )

    @field_validator("database_url")
    @classmethod
    def validate_database_url(cls, value: str) -> str:
        if not value.startswith("postgresql"):
            raise ValueError("DATABASE_URL must be a PostgreSQL connection string")
        return value

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_allowed_origins.split(",") if origin.strip()]

    @property
    def is_production(self) -> bool:
        return self.environment == "production"


@lru_cache
def get_settings() -> Settings:
    """
    Cached settings instance. Raising here (via Pydantic's validation) at
    import/first-call time is the fail-fast mechanism — the app will not
    start with a missing required variable, per Phase 2.10 §13.
    """
    return Settings()  # type: ignore[call-arg]  # values loaded from env/`.env`
