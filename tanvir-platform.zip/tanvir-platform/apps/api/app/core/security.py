"""
Supabase JWT validation (Phase 2.8 §5). Stateless — every request's
Authorization header is validated against Supabase's JWT secret, no
server-side session store.

This sprint implements token decoding only. The `get_current_user`
dependency that resolves a full domain User (with roles/permissions
joined from the database) is completed once the Users & Roles module
exists (Sprint 2) — it depends on tables that don't exist yet. What's
built here is the reusable piece every future module needs regardless.
"""

from typing import Any

from jose import JWTError, jwt

from app.core.config import get_settings
from app.core.exceptions import UnauthorizedError


def decode_supabase_jwt(token: str) -> dict[str, Any]:
    """
    Decodes and validates a Supabase-issued JWT's signature and expiry.
    Raises UnauthorizedError on any failure — callers never need to
    distinguish "expired" from "malformed" from "wrong signature" at the
    API boundary (Phase 2.3 §1's uniform error envelope).
    """
    settings = get_settings()

    try:
        payload = jwt.decode(
            token,
            settings.supabase_jwt_secret,
            algorithms=["HS256"],
            audience="authenticated",
        )
    except JWTError as exc:
        raise UnauthorizedError("Invalid or expired session") from exc

    return payload
