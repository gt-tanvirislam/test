"""
Scheduled-publishing due-query (Sprint 10 BUG-2 fix).

`ContentLifecycleService.schedule()` (app/shared/publishable.py) moves an
item to SCHEDULED with a future `scheduled_at`, but nothing ever
transitioned it to PUBLISHED once that time arrived — so scheduled content
stayed scheduled indefinitely. This is the missing query half; the sweep
that acts on it lives in app/modules/scheduler/service.py.

`select_due_scheduled_ids` returns IDs only — deliberately. Each content
module's own `publish()` re-fetches by id with the correct eager-loading
and re-runs publish-time validation + revision snapshotting, so a
scheduled publish and an editor's manual "Publish" click are the exact
same operation. Returning whole rows here would either duplicate that
eager-loading or hand `publish()` a half-loaded object.
"""

import uuid
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.shared.publishable import ContentStatus


async def select_due_scheduled_ids(
    session: AsyncSession, model: type, now: datetime
) -> list[uuid.UUID]:
    """IDs of every item of `model` whose scheduled time has arrived.

    Due == status is 'scheduled', scheduled_at is set and not in the
    future, and the row is not soft-deleted. Ordered oldest-first so a
    backlog (e.g. after downtime) publishes in the intended sequence.

    `model` must expose the publishable columns (`id`, `status`,
    `scheduled_at`) and the soft-delete `deleted_at` — every content model
    composing PublishableStatusMixin + SoftDeleteMixin does.
    """
    stmt = (
        select(model.id)
        .where(model.status == ContentStatus.SCHEDULED.value)
        .where(model.scheduled_at.is_not(None))
        .where(model.scheduled_at <= now)
        .where(model.deleted_at.is_(None))
        .order_by(model.scheduled_at.asc())
    )
    result = await session.execute(stmt)
    return list(result.scalars().all())
