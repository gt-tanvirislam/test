"""
Generic base repository (Phase 2.8 §3, §4). Every module's repository
extends this rather than reimplementing pagination/soft-delete/CRUD
plumbing.

`list()` is implemented now (Sprint 2 — Media is the first module with a
real paginated/filterable list view) rather than in Sprint 1, per the
YAGNI principle noted when this file was created: stubbing it generically
before a real consumer existed risked guessing the shape wrong.
"""

from datetime import datetime, timezone
from typing import Any, Generic, TypeVar
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import Base

ModelType = TypeVar("ModelType", bound=Base)


class BaseRepository(Generic[ModelType]):
    model: type[ModelType]

    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_id(self, id: UUID, *, include_deleted: bool = False) -> ModelType | None:
        stmt = select(self.model).where(self.model.id == id)  # type: ignore[attr-defined]
        if not include_deleted and hasattr(self.model, "deleted_at"):
            stmt = stmt.where(self.model.deleted_at.is_(None))  # type: ignore[attr-defined]
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def list(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        filters: dict[str, Any] | None = None,
        order_by: str = "created_at",
        descending: bool = True,
    ) -> tuple[list[ModelType], int]:
        """
        Offset-based pagination (Phase 2.8 §4 — appropriate for bounded
        lists like Media; the activity log's cursor-based pagination is
        implemented separately when that module is built).

        `filters` is a plain equality-filter dict; callers pass only
        whitelisted fields (Phase 2.8 §4's "a whitelist, preventing
        arbitrary column injection") — the whitelist itself lives in each
        module's repository method, not here, since valid filter fields
        differ per module.
        """
        stmt = select(self.model)
        count_stmt = select(func.count()).select_from(self.model)

        if hasattr(self.model, "deleted_at"):
            stmt = stmt.where(self.model.deleted_at.is_(None))  # type: ignore[attr-defined]
            count_stmt = count_stmt.where(self.model.deleted_at.is_(None))  # type: ignore[attr-defined]

        for field, value in (filters or {}).items():
            column = getattr(self.model, field)
            stmt = stmt.where(column == value)
            count_stmt = count_stmt.where(column == value)

        order_column = getattr(self.model, order_by)
        stmt = stmt.order_by(order_column.desc() if descending else order_column.asc())
        stmt = stmt.offset((page - 1) * per_page).limit(per_page)

        result = await self.session.execute(stmt)
        total = (await self.session.execute(count_stmt)).scalar_one()

        return list(result.scalars().all()), total

    async def soft_delete(self, instance: ModelType) -> None:
        if not hasattr(instance, "deleted_at"):
            raise NotImplementedError(f"{self.model.__name__} does not support soft delete")
        instance.deleted_at = datetime.now(timezone.utc)  # type: ignore[attr-defined]
        await self.session.flush()

    async def restore(self, instance: ModelType) -> None:
        if not hasattr(instance, "deleted_at"):
            raise NotImplementedError(f"{self.model.__name__} does not support soft delete")
        instance.deleted_at = None  # type: ignore[attr-defined]
        await self.session.flush()

    # create()/update() are added once a module needs mutation beyond what
    # its own repository's custom methods handle directly (e.g. Media's
    # `create_pending_asset` below) — no generic version forced onto every
    # module until a second module's needs reveal the right shared shape.
