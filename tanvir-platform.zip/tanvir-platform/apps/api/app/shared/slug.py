"""
Slug utilities (Phase 2.9 §3, §9). The source of truth for what actually
gets persisted — the frontend's generateSlug() (packages/utils) mirrors
this for live preview only, per Sprint 0's note on that function.

Used by every future content module (Blog, Portfolio, Services) rather
than each reimplementing slug generation and duplicate-checking.
"""

import re
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


def slugify(title: str) -> str:
    slug = title.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    return slug.strip("-")


async def generate_unique_slug(
    session: AsyncSession,
    model: type,
    title: str,
    *,
    exclude_id: uuid.UUID | None = None,
) -> str:
    """
    Generates a slug from `title` and appends `-2`, `-3`, etc. until it's
    unique within `model`'s table (Phase 2.9 §9's "auto-suffix suggested
    on collision" behavior, Phase 2.3 §5's slug-uniqueness rule).

    `model` must have a `.slug` column. Generic over any future content
    model — Blog and Portfolio both call this rather than each writing
    their own collision-checking loop.
    """
    base_slug = slugify(title)
    candidate = base_slug
    suffix = 2

    while await _slug_exists(session, model, candidate, exclude_id):
        candidate = f"{base_slug}-{suffix}"
        suffix += 1

    return candidate


async def _slug_exists(
    session: AsyncSession, model: type, slug: str, exclude_id: uuid.UUID | None
) -> bool:
    stmt = select(model.id).where(model.slug == slug)  # type: ignore[attr-defined]
    if exclude_id is not None:
        stmt = stmt.where(model.id != exclude_id)  # type: ignore[attr-defined]
    result = await session.execute(stmt)
    return result.scalar_one_or_none() is not None
