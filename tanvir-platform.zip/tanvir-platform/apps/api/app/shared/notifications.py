"""Notification abstraction (lead-capture email).

Deliberately minimal: a single `notify_new_inquiry` that, in this
environment, logs a structured event rather than sending real email. A real
provider (Resend/Postmark/SES) plugs in behind this one function later
without touching callers.

Contract: notification is best-effort and MUST NOT block persistence. The
service stores the inquiry first, then calls this; any failure here is
swallowed and logged so a flaky mail provider can never lose a lead.
"""

from __future__ import annotations

import structlog

logger = structlog.get_logger(__name__)


async def notify_new_inquiry(*, to_email: str | None, inquiry_id: str, name: str, email: str) -> None:
    """Best-effort notification that a new inquiry arrived. Never raises."""
    try:
        # Dev/default behaviour: log it. Swap this body for a provider call
        # when credentials exist — the signature stays the same.
        logger.info(
            "contact.inquiry.notification",
            inquiry_id=inquiry_id,
            from_name=name,
            from_email=email,
            notify_to=to_email,
            delivered=False,  # no provider wired in this environment
        )
    except Exception:  # noqa: BLE001 — notification must never break the request
        logger.warning("contact.inquiry.notification_failed", inquiry_id=inquiry_id)
