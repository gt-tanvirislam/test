"""
Shared content list/filter/search/paginate helper (Sprint 8). Extracted
the moment a THIRD content module (Services) needed the identical shape
BlogPostRepository.list_filtered and PortfolioItemRepository.list_filtered
already had. Sprint 6 deliberately deferred this extraction at two
occurrences, documenting that two consumers didn't yet justify the risk
of a leaky generic query builder — three real, byte-for-byte-identical
consumers is the point where the abstraction pays for itself.

Each repository still owns its own list_query()/detail_query() (eager-
load shape differs meaningfully per model) and still owns which fields
are filterable/searchable (Phase 2.8 §4's injection-prevention
whitelist) — this helper only takes over the mechanical filter-
application + tag-join + pagination + count, which was previously
duplicated line-for-line.
"""

from typing import Any

from sqlalchemy import Select, func, or_
from sqlalchemy.ext.asyncio import AsyncSession


async def list_filtered_content(
    session: AsyncSession,
    *,
    list_stmt: Select,
    count_stmt: Select,
    page: int,
    per_page: int,
    equality_filters: dict[Any, Any] | None = None,
    search_columns: list[Any] | None = None,
    search_term: str | None = None,
    tag_join_table: Any = None,
    tag_id_column: Any = None,
    tag_id: Any = None,
    order_by_column: Any,
    descending: bool = True,
) -> tuple[list[Any], int]:
    """
    `list_stmt`/`count_stmt` arrive pre-built with the caller's own
    eager-load options and base WHERE clauses (e.g. `deleted_at IS
    NULL`) already applied. `equality_filters` maps SQLAlchemy columns
    to values — `None` values are skipped automatically so callers don't
    need to pre-filter their own optional query params.
    """
    for column, value in (equality_filters or {}).items():
        if value is not None:
            list_stmt = list_stmt.where(column == value)
            count_stmt = count_stmt.where(column == value)

    if search_term and search_columns:
        pattern = f"%{search_term}%"
        clause = or_(*[col.ilike(pattern) for col in search_columns])
        list_stmt = list_stmt.where(clause)
        count_stmt = count_stmt.where(clause)

    if tag_id is not None and tag_join_table is not None and tag_id_column is not None:
        list_stmt = list_stmt.join(tag_join_table).where(tag_id_column == tag_id)
        count_stmt = count_stmt.join(tag_join_table).where(tag_id_column == tag_id)

    list_stmt = list_stmt.order_by(order_by_column.desc() if descending else order_by_column.asc())
    list_stmt = list_stmt.offset((page - 1) * per_page).limit(per_page)

    result = await session.execute(list_stmt)
    total = (await session.execute(count_stmt)).scalar_one()

    return list(result.unique().scalars().all()), total
