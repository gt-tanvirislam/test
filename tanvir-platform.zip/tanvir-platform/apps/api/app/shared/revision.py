"""
Shared revision-snapshot helper (Sprint 6). Extracted from BlogService
(Sprint 4) the moment PortfolioService needed the identical mechanics —
create a revision row, add it to the session — with only the model class
and snapshot shape differing per content type. Per Phase 2.2 §7's
decision, each content type keeps its OWN revision table (not a generic
polymorphic one), so this helper takes the concrete model as a parameter
rather than trying to hide that away.
"""

import uuid
from typing import Any, Protocol


class RevisionModel(Protocol):
    """Structural type every per-content-type revision model satisfies
    (BlogPostRevision, PortfolioItemRevision, ...) — each has its own
    `{entity}_id` foreign key column, so this is intentionally loose
    rather than forcing a shared base class onto tables that Phase 2.2
    §7 deliberately keeps separate."""


def create_revision(
    session: Any,
    revision_model: type,
    *,
    entity_fk_field: str,
    entity_id: uuid.UUID,
    snapshot: dict,
    actor_id: uuid.UUID | None,
) -> None:
    """
    Creates and stages a revision row. Does not flush/commit — callers
    control the transaction boundary (usually flushing once alongside
    the parent entity's own status change, per Phase 2.8 §4's
    single-transaction rule for multi-write Service methods).

    Usage (from a concrete service):
        create_revision(
            self.repository.session, BlogPostRevision,
            entity_fk_field="blog_post_id", entity_id=post.id,
            snapshot={...}, actor_id=actor_id,
        )
    """
    revision = revision_model(
        id=uuid.uuid4(), **{entity_fk_field: entity_id}, snapshot=snapshot, created_by=actor_id
    )
    session.add(revision)
