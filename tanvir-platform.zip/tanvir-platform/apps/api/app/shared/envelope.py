"""Shared response envelope helper (Phase 2.3 §1). Every success response
uses this rather than routers constructing the {data, meta} shape by hand
inconsistently."""

from datetime import datetime, timezone
from typing import Any

from fastapi import Request


def success_envelope(data: Any, request: Request) -> dict[str, Any]:
    return {
        "data": data,
        "meta": {
            "request_id": getattr(request.state, "request_id", ""),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
    }
