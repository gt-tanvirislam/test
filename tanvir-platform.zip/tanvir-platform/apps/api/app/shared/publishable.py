"""
Publishable content lifecycle (Phase 2.8 §7's `PublishableMixin`,
Phase 2.3 §18's state machine). This is the reusable engine every future
content module (Blog, Portfolio, and — with adaptation — Services) composes
rather than reimplementing draft/publish/schedule/archive independently.

Two pieces:
  1. `PublishableStatusMixin` — SQLAlchemy columns every publishable model
     includes (status, scheduled_at, published_at).
  2. `ContentLifecycleService` — generic state-transition logic, given a
     repository for the concrete model. A future BlogService composes
     this rather than extending it via inheritance, since composition
     keeps each module's own methods (e.g. Blog-specific validation like
     "featured_image required to publish") cleanly separate from the
     lifecycle mechanics themselves.
"""

from datetime import datetime, timezone
from enum import StrEnum
from typing import Generic, Protocol, TypeVar

from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.exceptions import ConflictError, ValidationError


class ContentStatus(StrEnum):
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    PUBLISHED = "published"
    ARCHIVED = "archived"


class PublishableStatusMixin:
    """Composed into every future publishable model (BlogPost,
    PortfolioItem, ...) alongside AuditMixin/SoftDeleteMixin from
    app/db/base.py."""

    status: Mapped[str] = mapped_column(String, nullable=False, default=ContentStatus.DRAFT.value)
    scheduled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class PublishableModel(Protocol):
    """Structural type every model passed to ContentLifecycleService must
    satisfy — status/scheduled_at/published_at at minimum."""

    status: str
    scheduled_at: datetime | None
    published_at: datetime | None


ModelT = TypeVar("ModelT", bound=PublishableModel)


class ContentLifecycleService(Generic[ModelT]):
    """
    Generic state-transition logic implementing the workflow from
    Phase 2.3 §18 exactly:

        draft --(Publish)--> published
        draft --(Schedule)--> scheduled
        published --(Unpublish)--> draft
        any --(Archive)--> archived
        archived --(Restore)--> draft

    Does NOT create revisions or write activity log entries itself — a
    concrete module's service calls this for the state transition, then
    separately calls the (future) revision-snapshot and activity-logger
    utilities, keeping this class focused on one responsibility (Phase
    2.10 §2's Single Responsibility rule).
    """

    def publish(self, instance: ModelT) -> None:
        if instance.status == ContentStatus.PUBLISHED:
            raise ConflictError("Already published")
        instance.status = ContentStatus.PUBLISHED.value
        instance.published_at = datetime.now(timezone.utc)
        instance.scheduled_at = None

    def unpublish(self, instance: ModelT) -> None:
        if instance.status != ContentStatus.PUBLISHED:
            raise ValidationError("Only published content can be unpublished")
        instance.status = ContentStatus.DRAFT.value

    def schedule(self, instance: ModelT, scheduled_at: datetime) -> None:
        if scheduled_at <= datetime.now(timezone.utc):
            raise ValidationError(
                "Scheduled time must be in the future", fields={"scheduled_at": "Must be a future date"}
            )
        if instance.status == ContentStatus.PUBLISHED:
            raise ConflictError("Already published — unpublish before scheduling")
        instance.status = ContentStatus.SCHEDULED.value
        instance.scheduled_at = scheduled_at

    def archive(self, instance: ModelT) -> None:
        instance.status = ContentStatus.ARCHIVED.value

    def restore_from_archive(self, instance: ModelT) -> None:
        if instance.status != ContentStatus.ARCHIVED:
            raise ValidationError("Only archived content can be restored")
        instance.status = ContentStatus.DRAFT.value
