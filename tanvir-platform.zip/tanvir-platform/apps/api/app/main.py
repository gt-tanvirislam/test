"""
Application entry point (Phase 2.8 §1, §3). Instantiates FastAPI,
registers middleware, exception handlers, and mounts each module's
router as it's built, per the development order in Phase 2.8 §19. This
file stays deliberately thin.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.core.error_handlers import register_exception_handlers
from app.core.logging import configure_logging
from app.core.middleware import RequestIDMiddleware
from app.modules.auth.router import router as auth_router
from app.modules.blog.router import router as blog_router
from app.modules.contact.router import router as contact_router
from app.modules.faq.router import router as faq_router
from app.modules.media.router import router as media_router
from app.modules.navigation.router import router as navigation_router
from app.modules.portfolio.router import router as portfolio_router
from app.modules.scheduler.router import router as scheduler_router
from app.modules.seo.router import router as seo_router
from app.modules.services.router import router as services_router
from app.modules.settings.router import router as settings_router
from app.modules.taxonomy.router import router as tags_router
from app.modules.testimonials.router import router as testimonials_router
from app.modules.users.router import router as users_router
from app.monitoring.health import router as health_router

settings = get_settings()
configure_logging()

app = FastAPI(
    title="Tamvir Islam Platform API",
    version="0.1.0",
    description="Backend for the Tamvir Islam personal brand, portfolio, and CMS platform.",
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
)

app.add_middleware(RequestIDMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

register_exception_handlers(app)

app.include_router(health_router)
app.include_router(auth_router, prefix="/api/v1")
app.include_router(media_router, prefix="/api/v1")
app.include_router(seo_router, prefix="/api/v1")
app.include_router(tags_router, prefix="/api/v1")
app.include_router(users_router, prefix="/api/v1")
app.include_router(blog_router, prefix="/api/v1")
app.include_router(contact_router, prefix="/api/v1")
app.include_router(portfolio_router, prefix="/api/v1")
app.include_router(services_router, prefix="/api/v1")
app.include_router(settings_router, prefix="/api/v1")
app.include_router(navigation_router, prefix="/api/v1")
app.include_router(testimonials_router, prefix="/api/v1")
app.include_router(faq_router, prefix="/api/v1")
app.include_router(scheduler_router, prefix="/api/v1")

# Future sprints add, in the order specified by Phase 2.8 §19:
#   app.include_router(testimonials_router, prefix="/api/v1/testimonials")
#   ...and so on, one module at a time.
