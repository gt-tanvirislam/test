/**
 * Generates a URL-safe slug from a title. Used for live slug preview in
 * content editors (Phase 2.4 §7) — the backend's slug generation
 * (apps/api/app/shared/slug.py) is the source of truth for what's actually
 * persisted; this mirrors that logic so the dashboard can show a preview
 * without a round-trip.
 */
export function generateSlug(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}
