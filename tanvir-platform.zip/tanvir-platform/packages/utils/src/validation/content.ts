import { z } from "zod";

/**
 * Shared content validation (this sprint's "Reusable Form System" /
 * "Validation" requirement, Phase 2.10 §2's DRY rule applied to forms).
 *
 * Every future content module's form schema EXTENDS this rather than
 * redefining title/slug/excerpt/status validation independently:
 *
 *   const blogPostSchema = contentBaseSchema.extend({
 *     category_id: z.string().uuid().nullable(),
 *     body_mdx: z.string().min(1, "Content is required"),
 *   });
 *
 * Client-side validation here is always a UX convenience — the backend
 * (Pydantic, per Phase 2.10 §13) re-validates everything regardless.
 */
export const contentStatusSchema = z.enum(["draft", "scheduled", "published", "archived"]);

export const contentBaseSchema = z.object({
  title: z
    .string()
    .min(3, "Title must be at least 3 characters")
    .max(200, "Title must be under 200 characters"),
  slug: z
    .string()
    .min(1, "Slug is required")
    .regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Use lowercase letters, numbers, and hyphens only"),
  excerpt: z.string().max(300, "Excerpt must be under 300 characters").optional(),
  status: contentStatusSchema,
  scheduled_at: z.string().datetime().nullable().optional(),
  featured_image_id: z.string().uuid().nullable().optional(),
});

export type ContentBaseValues = z.infer<typeof contentBaseSchema>;

/**
 * SEO panel schema (Phase 2.3 §13's field limits — 70/160 char practical
 * limits for title/description, matching the backend's Pydantic Field
 * constraints in modules/seo/schemas.py exactly, so the character-count
 * UI and the server's actual validation never disagree).
 */
export const seoMetadataSchema = z.object({
  meta_title: z.string().max(70, "Keep titles under 70 characters for search results").optional(),
  meta_description: z
    .string()
    .max(160, "Keep descriptions under 160 characters for search results")
    .optional(),
  og_image_id: z.string().uuid().nullable().optional(),
  canonical_override: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  noindex: z.boolean().default(false),
  twitter_card_type: z.string().optional(),
  robots_directive: z.string().optional(),
  json_ld_override: z.string().optional(),
});

export type SeoMetadataValues = z.infer<typeof seoMetadataSchema>;
