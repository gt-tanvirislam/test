/**
 * Shared formatting helpers. Framework-agnostic, pure functions only
 * (Phase 2.10 §2) — no React, no fetch, trivially unit-testable.
 */

export function formatDate(iso: string, locale = "en-US"): string {
  return new Date(iso).toLocaleDateString(locale, {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

/** Reading time estimate at ~200 words/minute, matching Phase 2.3 §5's
 * server-side calculation — kept here only for optimistic client-side
 * preview while drafting; the persisted value always comes from the API. */
export function estimateReadingTimeMinutes(bodyText: string): number {
  const words = bodyText.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 200));
}

export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return `${text.slice(0, maxLength).trimEnd()}…`;
}

/** Human-readable file size (Phase 2.4 §8's media detail panel). */
export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
