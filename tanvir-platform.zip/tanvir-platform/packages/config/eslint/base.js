/**
 * Shared ESLint base config. Enforces the conventions from the Engineering
 * Handbook (Phase 2.10 §2): import ordering, no unexplained `any`, named
 * exports preferred.
 */
module.exports = {
  extends: ["next/core-web-vitals", "eslint:recommended"],
  rules: {
    "@typescript-eslint/no-explicit-any": "warn", // warn, not error — the
    // handbook allows `any` with a justifying comment; a hard error would
    // block legitimate documented exceptions.
    "import/order": [
      "warn",
      {
        groups: ["builtin", "external", "internal", "parent", "sibling", "index"],
        "newlines-between": "always",
        alphabetize: { order: "asc", caseInsensitive: true },
      },
    ],
    "no-console": ["warn", { allow: ["warn", "error"] }],
    "prefer-const": "error",
  },
};
