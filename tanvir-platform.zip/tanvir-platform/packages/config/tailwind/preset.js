/**
 * Shared Tailwind preset. Extends Tailwind's theme with the platform's
 * design tokens (packages/ui/src/tokens) so `bg-accent-500`, `rounded-md`,
 * `duration-fast`, etc. resolve to the exact values specified in Phase 2.5.
 *
 * Colors reference CSS custom properties (defined in
 * apps/web/styles/globals.css) rather than raw hex values, so dark mode and
 * future dashboard-driven theme overrides (Phase 2.4 §14) work by swapping
 * the underlying CSS variable, not by duplicating the Tailwind config.
 */
module.exports = {
  darkMode: ["class", '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        neutral: {
          0: "var(--color-neutral-0)",
          50: "var(--color-neutral-50)",
          100: "var(--color-neutral-100)",
          200: "var(--color-neutral-200)",
          300: "var(--color-neutral-300)",
          400: "var(--color-neutral-400)",
          500: "var(--color-neutral-500)",
          600: "var(--color-neutral-600)",
          700: "var(--color-neutral-700)",
          800: "var(--color-neutral-800)",
          900: "var(--color-neutral-900)",
        },
        accent: {
          50: "var(--color-accent-50)",
          400: "var(--color-accent-400)",
          500: "var(--color-accent-500)",
          600: "var(--color-accent-600)",
        },
        success: { 50: "var(--color-success-50)", 500: "var(--color-success-500)" },
        warning: { 50: "var(--color-warning-50)", 500: "var(--color-warning-500)" },
        error: { 50: "var(--color-error-50)", 500: "var(--color-error-500)" },
        info: { 50: "var(--color-info-50)", 500: "var(--color-info-500)" },
        "surface-dark": {
          base: "var(--color-surface-dark-base)",
          1: "var(--color-surface-dark-1)",
          2: "var(--color-surface-dark-2)",
          border: "var(--color-surface-dark-border)",
        },
        "text-dark": {
          primary: "var(--color-text-dark-primary)",
          secondary: "var(--color-text-dark-secondary)",
        },
      },
      borderRadius: {
        sm: "var(--radius-sm)",
        md: "var(--radius-md)",
        lg: "var(--radius-lg)",
        full: "var(--radius-full)",
      },
      spacing: {
        1: "var(--space-1)",
        2: "var(--space-2)",
        3: "var(--space-3)",
        4: "var(--space-4)",
        5: "var(--space-5)",
        6: "var(--space-6)",
        7: "var(--space-7)",
        8: "var(--space-8)",
        9: "var(--space-9)",
        10: "var(--space-10)",
        12: "var(--space-12)",
        16: "var(--space-16)",
        20: "var(--space-20)",
      },
      fontSize: {
        display: ["var(--text-display-size)", { lineHeight: "var(--text-display-lh)" }],
        h1: ["var(--text-h1-size)", { lineHeight: "var(--text-h1-lh)" }],
        h2: ["var(--text-h2-size)", { lineHeight: "var(--text-h2-lh)" }],
        h3: ["var(--text-h3-size)", { lineHeight: "var(--text-h3-lh)" }],
        h4: ["var(--text-h4-size)", { lineHeight: "var(--text-h4-lh)" }],
        "card-title": ["var(--text-card-title-size)", { lineHeight: "var(--text-card-title-lh)" }],
        subtitle: ["var(--text-subtitle-size)", { lineHeight: "var(--text-subtitle-lh)" }],
        body: ["var(--text-body-size)", { lineHeight: "var(--text-body-lh)" }],
        "body-sm": ["var(--text-body-sm-size)", { lineHeight: "var(--text-body-sm-lh)" }],
        caption: ["var(--text-caption-size)", { lineHeight: "var(--text-caption-lh)" }],
        label: ["var(--text-label-size)", { lineHeight: "var(--text-label-lh)" }],
        button: ["var(--text-button-size)", { lineHeight: "1" }],
      },
      boxShadow: {
        xs: "var(--shadow-xs)",
        sm: "var(--shadow-sm)",
        md: "var(--shadow-md)",
        lg: "var(--shadow-lg)",
        glow: "var(--shadow-glow)",
      },
      transitionDuration: {
        instant: "100ms",
        fast: "150ms",
        base: "220ms",
        slow: "400ms",
        cinematic: "700ms",
      },
      transitionTimingFunction: {
        standard: "cubic-bezier(0.4, 0, 0.2, 1)",
        out: "cubic-bezier(0, 0, 0.2, 1)",
        in: "cubic-bezier(0.4, 0, 1, 1)",
        spring: "cubic-bezier(0.34, 1.56, 0.64, 1)",
      },
      zIndex: {
        sticky: "10",
        dropdown: "20",
        overlay: "30",
        modal: "40",
        toast: "50",
        tooltip: "60",
      },
      screens: {
        sm: "480px",
        md: "768px",
        lg: "1024px",
        xl: "1440px",
        "2xl": "1920px",
      },
    },
  },
  plugins: [],
};
