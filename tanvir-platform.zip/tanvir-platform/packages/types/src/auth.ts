/**
 * Identity and permission types — matches the RBAC matrix from Phase 2.3 §2
 * and the users/roles schema from Phase 2.2 §4.1.
 */

export type Role = "owner" | "admin" | "editor" | "contributor" | "viewer";

export interface CurrentUser {
  id: string;
  email: string;
  full_name: string;
  avatar_url: string | null;
  roles: Role[];
  permissions: string[]; // permission keys, e.g. "blog.publish"
}
