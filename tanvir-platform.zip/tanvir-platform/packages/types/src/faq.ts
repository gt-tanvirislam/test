/**
 * FAQ types — mirror the backend `faq` module schemas. `PublicFAQItem` is
 * the trimmed shape the public accordion renders; `FAQItem` is the full
 * dashboard shape.
 */

export interface PublicFAQItem {
  id: string;
  question: string;
  answer: string;
  category: string | null;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string | null;
  is_published: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface CreateFAQItemInput {
  question: string;
  answer: string;
  category?: string | null;
  is_published?: boolean;
  sort_order?: number;
}

export interface UpdateFAQItemInput {
  question?: string;
  answer?: string;
  category?: string | null;
  is_published?: boolean;
  sort_order?: number;
}
