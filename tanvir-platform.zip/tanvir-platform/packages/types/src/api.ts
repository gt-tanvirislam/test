/**
 * Shared API contract types — mirrors the response envelopes defined in
 * Phase 2.3 §1. These are the ONLY shapes the frontend's API layer
 * (apps/web/lib/api) should expect from the backend. Entity-specific types
 * (BlogPost, PortfolioItem, etc.) are added module-by-module in future
 * sprints as each backend module is implemented — not stubbed speculatively
 * here, per the YAGNI principle (Phase 2.10 §2).
 */

export interface ApiSuccessResponse<T> {
  data: T;
  meta: {
    request_id: string;
    timestamp: string;
  };
}

export interface PaginationMeta {
  page: number;
  per_page: number;
  total: number;
  total_pages: number;
}

export interface ApiListResponse<T> {
  data: T[];
  meta: PaginationMeta;
}

export type ApiErrorCode =
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "VALIDATION_ERROR"
  | "CONFLICT"
  | "RATE_LIMITED"
  | "INTERNAL_ERROR";

export interface ApiErrorResponse {
  error: {
    code: ApiErrorCode;
    message: string;
    fields?: Record<string, string>;
  };
}

export type ContentStatus = "draft" | "scheduled" | "published" | "archived";
