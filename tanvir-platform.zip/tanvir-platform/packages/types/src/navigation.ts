/**
 * Navigation types (Phase 2.2 §4.7). Mirrors the backend's `NavigationOut`
 * (resolved read shape) and `ReplaceNavigationIn` (full-replace write
 * shape). Drives the public header menu and footer columns, editable in the
 * dashboard under `navigation.manage`.
 */

export interface NavLink {
  label: string;
  url: string;
}

export interface FooterNavColumn {
  title: string;
  items: NavLink[];
}

/** Resolved navigation tree returned by `GET /navigation`. */
export interface Navigation {
  header: NavLink[];
  footer: FooterNavColumn[];
}

/**
 * Full desired navigation tree sent to `PUT /navigation`. The backend
 * replaces the stored tree with this wholesale, so it always expresses the
 * complete intended state — the same shape as `Navigation`.
 */
export type ReplaceNavigationInput = Navigation;
