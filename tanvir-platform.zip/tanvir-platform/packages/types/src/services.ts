import type { ContentStatus, Tag } from "./blog";

export interface ServiceCategory {
  id: string;
  name: string;
  slug: string;
  description: string | null;
}

export type ServiceListItemType = "feature" | "benefit" | "process_step";

export interface ServiceListItem {
  id: string;
  item_type: ServiceListItemType;
  title: string;
  description: string | null;
  sort_order: number;
}

export interface ServiceListItemInput {
  title: string;
  description?: string | null;
}

export interface Service {
  id: string;
  author_id: string;
  category_id: string | null;
  category: ServiceCategory | null;
  tags: Tag[];
  list_items: ServiceListItem[];

  title: string;
  slug: string;
  short_description: string | null;
  full_description: string;
  icon_key: string | null;
  featured_image_id: string | null;

  pricing_text: string | null;
  delivery_time: string | null;
  cta_text: string | null;
  cta_link: string | null;

  featured: boolean;
  sort_order: number;

  status: ContentStatus;
  scheduled_at: string | null;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface ServiceListItemSlim {
  id: string;
  title: string;
  slug: string;
  status: ContentStatus;
  featured: boolean;
  category: ServiceCategory | null;
  icon_key: string | null;
  sort_order: number;
  published_at: string | null;
  updated_at: string;
}

export interface CreateServiceInput {
  title: string;
  slug?: string;
  short_description?: string;
  full_description?: string;
  category_id?: string | null;
  tag_names?: string[];
  featured_image_id?: string | null;
  icon_key?: string | null;
  pricing_text?: string | null;
  delivery_time?: string | null;
  featured?: boolean;
  sort_order?: number;
}

export type UpdateServiceInput = Partial<CreateServiceInput> & {
  author_id?: string;
  cta_text?: string | null;
  cta_link?: string | null;
};

export interface ServiceListFilters {
  page?: number;
  per_page?: number;
  status?: ContentStatus;
  category_id?: string;
  tag_id?: string;
  author_id?: string;
  search?: string;
  featured?: boolean;
}
