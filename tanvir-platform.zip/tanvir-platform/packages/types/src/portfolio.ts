import type { ContentStatus, Tag } from "./blog";

export interface PortfolioCategory {
  id: string;
  name: string;
  slug: string;
  description: string | null;
}

export interface BeforeAfterPair {
  id: string;
  before_media_id: string;
  after_media_id: string;
  caption: string | null;
  sort_order: number;
}

export interface BeforeAfterPairInput {
  before_media_id: string;
  after_media_id: string;
  caption?: string | null;
}

export interface PortfolioItem {
  id: string;
  author_id: string;
  category_id: string | null;
  category: PortfolioCategory | null;
  tags: Tag[];
  before_after_pairs: BeforeAfterPair[];

  title: string;
  slug: string;
  short_description: string | null;
  full_case_study: string;
  featured_image_id: string | null;

  client_name: string | null;
  industry: string | null;
  project_date: string | null;
  services_used: string[];
  technologies: string[];

  is_case_study: boolean;
  challenge: string | null;
  solution: string | null;
  results: string | null;
  results_metrics: Record<string, unknown> | null;

  cta_text: string | null;
  cta_link: string | null;
  featured: boolean;

  status: ContentStatus;
  scheduled_at: string | null;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface PortfolioItemListItem {
  id: string;
  title: string;
  slug: string;
  status: ContentStatus;
  featured: boolean;
  category: PortfolioCategory | null;
  featured_image_id: string | null;
  featured_image_url: string | null;
  published_at: string | null;
  updated_at: string;
}

export interface CreatePortfolioItemInput {
  title: string;
  slug?: string;
  short_description?: string;
  full_case_study?: string;
  category_id?: string | null;
  tag_names?: string[];
  featured_image_id?: string | null;
  client_name?: string | null;
  industry?: string | null;
  project_date?: string | null;
  services_used?: string[];
  technologies?: string[];
  is_case_study?: boolean;
  featured?: boolean;
}

export type UpdatePortfolioItemInput = Partial<CreatePortfolioItemInput> & {
  author_id?: string;
  challenge?: string | null;
  solution?: string | null;
  results?: string | null;
  cta_text?: string | null;
  cta_link?: string | null;
};

export interface PortfolioItemListFilters {
  page?: number;
  per_page?: number;
  status?: ContentStatus;
  category_id?: string;
  tag_id?: string;
  author_id?: string;
  search?: string;
  featured?: boolean;
}
