export interface MediaVariant {
  id: string;
  variant_label: string;
  storage_path: string;
  width: number | null;
  height: number | null;
}

export interface MediaAsset {
  id: string;
  folder_id: string | null;
  storage_path: string;
  file_name: string;
  mime_type: string;
  file_size_bytes: number;
  alt_text: string | null;
  width: number | null;
  height: number | null;
  duration_seconds: number | null;
  created_at: string;
  variants: MediaVariant[];
  public_url: string;
}

export interface MediaFolder {
  id: string;
  name: string;
  parent_id: string | null;
}

export interface MediaUsage {
  entity_type: string;
  entity_id: string;
  role: string | null;
}
