/**
 * Testimonial types — mirror the backend `testimonials` module schemas.
 * `PublicTestimonial` is the trimmed shape the public site renders (no
 * internal flags); `Testimonial` is the full dashboard shape.
 */

export interface PublicTestimonial {
  id: string;
  quote: string;
  author_name: string;
  author_title: string | null;
  author_company: string | null;
  avatar_image_id: string | null;
}

export interface Testimonial {
  id: string;
  quote: string;
  author_name: string;
  author_title: string | null;
  author_company: string | null;
  avatar_image_id: string | null;
  is_published: boolean;
  is_featured: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface CreateTestimonialInput {
  quote: string;
  author_name: string;
  author_title?: string | null;
  author_company?: string | null;
  avatar_image_id?: string | null;
  is_published?: boolean;
  is_featured?: boolean;
  sort_order?: number;
}

export interface UpdateTestimonialInput {
  quote?: string;
  author_name?: string;
  author_title?: string | null;
  author_company?: string | null;
  avatar_image_id?: string | null;
  is_published?: boolean;
  is_featured?: boolean;
  sort_order?: number;
}
