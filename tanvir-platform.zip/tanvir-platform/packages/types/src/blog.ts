export interface Tag {
  id: string;
  name: string;
  slug: string;
}

export interface BlogCategory {
  id: string;
  name: string;
  slug: string;
  description: string | null;
}

export type ContentStatus = "draft" | "scheduled" | "published" | "archived";

export interface BlogPost {
  id: string;
  author_id: string;
  category_id: string | null;
  category: BlogCategory | null;
  tags: Tag[];
  title: string;
  slug: string;
  excerpt: string | null;
  body_mdx: string;
  featured_image_id: string | null;
  reading_time_minutes: number | null;
  canonical_url: string | null;
  featured: boolean;
  locale: string;
  status: ContentStatus;
  scheduled_at: string | null;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface BlogPostListItem {
  id: string;
  title: string;
  slug: string;
  status: ContentStatus;
  featured: boolean;
  category: BlogCategory | null;
  published_at: string | null;
  updated_at: string;
}

export interface CreateBlogPostInput {
  title: string;
  slug?: string;
  excerpt?: string;
  body_mdx?: string;
  category_id?: string | null;
  tag_names?: string[];
  featured_image_id?: string | null;
  canonical_url?: string | null;
  featured?: boolean;
  author_id?: string;
}

export type UpdateBlogPostInput = Partial<CreateBlogPostInput>;

export interface BlogPostListFilters {
  page?: number;
  per_page?: number;
  status?: ContentStatus;
  category_id?: string;
  tag_id?: string;
  author_id?: string;
  search?: string;
  featured?: boolean;
}
