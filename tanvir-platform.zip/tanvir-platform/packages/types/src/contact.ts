/**
 * Contact / inquiry types — mirror the backend `contact` module's schemas
 * (CreateInquiryIn / InquiryOut / InquiryListItem / UpdateInquiryStatusIn).
 * The public Contact form sends `CreateInquiryInput`; the dashboard reads
 * `ContactInquiry` / `InquiryListItem` and drives lifecycle with
 * `UpdateInquiryStatusInput`.
 */

export type InquiryStatus = "new" | "contacted" | "resolved" | "archived";

export const INQUIRY_STATUSES: InquiryStatus[] = [
  "new",
  "contacted",
  "resolved",
  "archived",
];

export interface CreateInquiryInput {
  name: string;
  email: string;
  message: string;
  company?: string | null;
  service?: string | null;
  project_type?: string | null;
  budget_range?: string | null;
  preferred_contact?: string | null;
}

export interface ContactInquiry {
  id: string;
  name: string;
  email: string;
  company: string | null;
  service: string | null;
  project_type: string | null;
  budget_range: string | null;
  preferred_contact: string | null;
  message: string;
  status: InquiryStatus;
  created_at: string;
  updated_at: string;
}

export interface InquiryListItem {
  id: string;
  name: string;
  email: string;
  company: string | null;
  service: string | null;
  status: InquiryStatus;
  created_at: string;
}

/** Minimal confirmation echoed by the public submit endpoint. */
export interface InquiryReceipt {
  id: string;
  status: InquiryStatus;
}

export interface UpdateInquiryStatusInput {
  status: InquiryStatus;
}
