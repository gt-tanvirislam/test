/**
 * Site settings types (Phase 2.2 §4.7). Mirrors the backend's
 * `SiteSettingsOut` / `UpdateSiteSettingsIn` schemas exactly. A single
 * global settings record edited in the dashboard (`settings.manage`) and
 * read by the public site chrome.
 */

export interface SocialLink {
  platform: string;
  url: string;
}

export interface SiteSettings {
  site_name: string;
  tagline: string | null;
  contact_email: string | null;
  social_links: SocialLink[];
  default_meta_description: string | null;
  default_og_image_id: string | null;
}

/**
 * Partial update payload — the backend PATCH applies only the fields
 * actually present in the request body (`model_fields_set`), so an omitted
 * field is left untouched while an explicit `null` clears it. Every field
 * is therefore optional here.
 */
export interface UpdateSiteSettingsInput {
  site_name?: string;
  tagline?: string | null;
  contact_email?: string | null;
  social_links?: SocialLink[];
  default_meta_description?: string | null;
  default_og_image_id?: string | null;
}
