// packages/ui — shared component library (Phase 2.5 design system, in code).
// Every new shared component gets exported here. Nothing outside this
// package should import from `packages/ui/src/components/*` directly.

export * from "./tokens";
export * from "./utils/cn";
export * from "./components/Button";
export * from "./components/Card";
export * from "./components/StatCard";
export * from "./components/EmptyState";
export * from "./components/Headers";
export * from "./components/ActionBar";
export * from "./components/Modal";
export * from "./components/Drawer";
export * from "./components/Table";
export * from "./components/Form";
export * from "./components/Textarea";
export * from "./components/Select";
export * from "./components/Badge";
export * from "./components/Tabs";
export * from "./components/Skeleton";
export * from "./components/Toast";

// Future sprints add: DataTable (virtualized), Avatar, Tooltip, Popover,
// etc. (Phase 2.5 §3) — each following the pattern established above.
