/**
 * Design Tokens — single source of truth for the platform's visual language.
 *
 * Implements Phase 2.5 §1 exactly. No component anywhere in the app should
 * hardcode a color, spacing, radius, or duration value — everything derives
 * from here (or the CSS custom properties generated from this file, see
 * apps/web/styles/globals.css).
 *
 * Changing brand values (e.g. the accent color) happens in exactly one
 * place: here, or — once the Theme Manager (Phase 2.4 §14) ships — in the
 * `settings` table, which overrides these at request time.
 */

export const colors = {
  neutral: {
    0: "#FFFFFF",
    50: "#FAFAF9",
    100: "#F2F1EF",
    200: "#E6E4E1",
    300: "#D3D0CB",
    400: "#A8A49C",
    500: "#78746C",
    600: "#56534D",
    700: "#3A3733",
    800: "#24221F",
    900: "#16150F",
  },
  surfaceDark: {
    base: "#16171A",
    1: "#1D1E22",
    2: "#26272C",
    border: "#34353B",
  },
  textDark: {
    primary: "#F2F1ED",
    secondary: "#B5B2AA",
  },
  accent: {
    50: "#FBF1E7",
    400: "#D89257",
    500: "#C77D3A", // primary accent — pending final confirmation via Theme Manager, see Phase 2.5 §1.1
    600: "#A8672E",
  },
  semantic: {
    success: { 50: "#EAF5EE", 500: "#3E8A5C" },
    warning: { 50: "#FBF3E3", 500: "#C48A2B" },
    error: { 50: "#FAEBEA", 500: "#C4443A" },
    info: { 50: "#EAF1F8", 500: "#3E6FA8" },
  },
} as const;

export const radius = {
  sm: "6px",
  md: "12px",
  lg: "20px",
  full: "9999px",
} as const;

export const spacing = {
  1: "4px",
  2: "8px",
  3: "12px",
  4: "16px",
  5: "20px",
  6: "24px",
  7: "32px",
  8: "40px",
  9: "48px",
  10: "56px",
  12: "64px",
  16: "96px",
  20: "128px",
} as const;

export const typography = {
  display: { size: "64px", lineHeight: 1.05, letterSpacing: "-0.02em", weight: 600 },
  h1: { size: "44px", lineHeight: 1.1, letterSpacing: "-0.01em", weight: 600 },
  h2: { size: "32px", lineHeight: 1.15, weight: 600 },
  h3: { size: "24px", lineHeight: 1.2, weight: 600 },
  h4: { size: "20px", lineHeight: 1.25, weight: 600 },
  cardTitle: { size: "18px", lineHeight: 1.3, weight: 600 },
  subtitle: { size: "17px", lineHeight: 1.4, weight: 500 },
  body: { size: "16px", lineHeight: 1.6, weight: 400 },
  bodySm: { size: "14px", lineHeight: 1.55, weight: 400 },
  caption: { size: "13px", lineHeight: 1.4, weight: 400 },
  label: { size: "13px", lineHeight: 1.2, letterSpacing: "0.02em", weight: 500 },
  buttonText: { size: "15px", lineHeight: 1, weight: 500 },
  navText: { size: "15px", lineHeight: 1, weight: 500 },
  code: { size: "14px", lineHeight: 1.6, weight: 400 },
} as const;

export const shadow = {
  xs: "0 1px 2px rgba(22,21,15,0.04)",
  sm: "0 2px 6px rgba(22,21,15,0.06)",
  md: "0 6px 16px rgba(22,21,15,0.08)",
  lg: "0 16px 32px rgba(22,21,15,0.10)",
  glow: "0 0 0 3px rgba(199,125,58,0.16)",
  dark: "0 1px 0 rgba(255,255,255,0.04) inset, 0 8px 20px rgba(0,0,0,0.35)",
} as const;

export const glass = {
  light: {
    background: "rgba(255,255,255,0.72)",
    backdropFilter: "blur(16px)",
    border: "1px solid rgba(255,255,255,0.4)",
  },
  dark: {
    background: "rgba(29,30,34,0.72)",
    backdropFilter: "blur(16px)",
    border: "1px solid rgba(255,255,255,0.06)",
  },
} as const;

export const iconSize = {
  xs: "14px",
  sm: "16px",
  md: "20px",
  lg: "24px",
  xl: "32px",
} as const;

export const motion = {
  duration: {
    instant: 100,
    fast: 150,
    base: 220,
    slow: 400,
    cinematic: 700,
  },
  easing: {
    standard: "cubic-bezier(0.4, 0, 0.2, 1)",
    out: "cubic-bezier(0, 0, 0.2, 1)",
    in: "cubic-bezier(0.4, 0, 1, 1)",
    spring: "cubic-bezier(0.34, 1.56, 0.64, 1)",
  },
} as const;

export const zIndex = {
  base: 0,
  sticky: 10,
  dropdown: 20,
  overlay: 30,
  modal: 40,
  toast: 50,
  tooltip: 60,
} as const;

export const breakpoints = {
  xs: 0,
  sm: 480,
  md: 768,
  lg: 1024,
  xl: 1440,
  "2xl": 1920,
} as const;

export type ColorTokens = typeof colors;
export type MotionTokens = typeof motion;
