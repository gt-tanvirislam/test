import * as React from "react";
import { cn } from "../utils/cn";

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  hasError?: boolean;
}

/**
 * Textarea — auto-growing up to a max height per Phase 2.5 §3.6. Used by
 * Excerpt, and by RichTextField as this sprint's foundation editing
 * surface (a full WYSIWYG/MDX toolbar is Blog-sprint scope).
 */
export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, hasError, onInput, ...props }, ref) => {
    const internalRef = React.useRef<HTMLTextAreaElement>(null);

    function autoGrow(el: HTMLTextAreaElement) {
      el.style.height = "auto";
      el.style.height = `${Math.min(el.scrollHeight, 480)}px`;
    }

    return (
      <textarea
        ref={(node) => {
          internalRef.current = node;
          if (typeof ref === "function") ref(node);
          else if (ref) ref.current = node;
        }}
        onInput={(e) => {
          autoGrow(e.currentTarget);
          onInput?.(e);
        }}
        className={cn(
          "w-full resize-none rounded-sm border bg-neutral-0 px-3 py-2.5 text-body text-neutral-800",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/40",
          "disabled:cursor-not-allowed disabled:opacity-40",
          "dark:bg-surface-dark-1 dark:text-text-dark-primary",
          hasError ? "border-error-500" : "border-neutral-300 dark:border-surface-dark-border",
          className
        )}
        aria-invalid={hasError || undefined}
        {...props}
      />
    );
  }
);
Textarea.displayName = "Textarea";
