"use client";

import { AnimatePresence, motion } from "framer-motion";
import * as React from "react";
import { cn } from "../utils/cn";

export interface DrawerProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  side?: "left" | "right";
  children: React.ReactNode;
  className?: string;
}

/**
 * Drawer foundation (Phase 2.5 §3.8). Same motion token family as Modal,
 * different transform axis. Used by: dashboard mobile nav, Media asset
 * detail, and (this sprint) the public site's mobile navigation.
 *
 * Sprint 7 fix: added Escape-to-close and focus management, matching
 * what Modal already had — the public mobile nav's "Keyboard
 * Accessibility" requirement is what exposed this gap, but the fix
 * benefits every existing Drawer consumer, not just the new one.
 */
export function Drawer({ open, onClose, title, side = "right", children, className }: DrawerProps) {
  const isLeft = side === "left";
  const drawerRef = React.useRef<HTMLDivElement>(null);
  const triggerRef = React.useRef<HTMLElement | null>(null);

  React.useEffect(() => {
    if (open) {
      triggerRef.current = document.activeElement as HTMLElement;
      drawerRef.current?.focus();
    } else {
      triggerRef.current?.focus();
    }
  }, [open]);

  React.useEffect(() => {
    if (!open) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-overlay">
          <motion.div
            className="absolute inset-0 bg-neutral-900/40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            aria-hidden
          />
          <motion.div
            ref={drawerRef}
            role="dialog"
            aria-modal="true"
            aria-label={title}
            tabIndex={-1}
            initial={{ x: isLeft ? "-100%" : "100%" }}
            animate={{ x: 0, transition: { duration: 0.22, ease: [0, 0, 0.2, 1] } }}
            exit={{ x: isLeft ? "-100%" : "100%", transition: { duration: 0.15, ease: [0.4, 0, 1, 1] } }}
            className={cn(
              "absolute top-0 h-full w-full max-w-xs bg-neutral-0 p-6 shadow-lg dark:bg-surface-dark-2",
              isLeft ? "left-0" : "right-0",
              className
            )}
          >
            {title && (
              <h2 className="text-h4 font-semibold text-neutral-800 dark:text-text-dark-primary">{title}</h2>
            )}
            <div className={title ? "mt-4" : ""}>{children}</div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
