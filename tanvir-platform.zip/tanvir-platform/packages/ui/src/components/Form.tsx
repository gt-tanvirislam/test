import * as React from "react";
import { cn } from "../utils/cn";

/**
 * Form primitives (Phase 2.5 §3.6). Real label above the field always
 * (Phase 2.10 §11 — "never placeholder-only, for accessibility"). Used
 * by the Login form this sprint and every future CMS form.
 */
export const Label = React.forwardRef<HTMLLabelElement, React.LabelHTMLAttributes<HTMLLabelElement>>(
  ({ className, ...props }, ref) => (
    <label
      ref={ref}
      className={cn("mb-1.5 block text-label text-neutral-700 dark:text-text-dark-secondary", className)}
      {...props}
    />
  )
);
Label.displayName = "Label";

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  hasError?: boolean;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, hasError, ...props }, ref) => (
    <input
      ref={ref}
      className={cn(
        "h-11 w-full rounded-sm border bg-neutral-0 px-3 text-body text-neutral-800",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/40",
        "disabled:cursor-not-allowed disabled:opacity-40",
        "dark:bg-surface-dark-1 dark:text-text-dark-primary",
        hasError
          ? "border-error-500"
          : "border-neutral-300 dark:border-surface-dark-border",
        className
      )}
      aria-invalid={hasError || undefined}
      {...props}
    />
  )
);
Input.displayName = "Input";

export interface FormFieldProps {
  label: string;
  htmlFor: string;
  error?: string;
  children: React.ReactNode;
}

/** Composes Label + input slot + inline error message consistently
 * (Phase 2.5 §3.6's Input Field spec — error replaces helper text). */
export function FormField({ label, htmlFor, error, children }: FormFieldProps) {
  return (
    <div>
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {error && (
        <p role="alert" className="mt-1.5 text-caption text-error-500">
          {error}
        </p>
      )}
    </div>
  );
}
