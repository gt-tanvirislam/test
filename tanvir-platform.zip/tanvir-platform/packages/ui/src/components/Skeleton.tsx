import * as React from "react";
import { cn } from "../utils/cn";

export interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "text" | "block" | "circle";
}

/**
 * Skeleton (Phase 2.5 §3.10 — "shape-matched placeholder... used instead
 * of spinners wherever content shape is predictable"). First built this
 * sprint since Sprints 2–4 used ad-hoc `animate-pulse` divs inline
 * (Media Library grid, Blog list) — this is the single source those get
 * migrated to, and every future module's loading states use this instead
 * of reinventing the shimmer.
 */
export function Skeleton({ variant = "block", className, ...props }: SkeletonProps) {
  return (
    <div
      className={cn(
        "animate-pulse bg-neutral-100 dark:bg-surface-dark-1",
        variant === "text" && "h-4 rounded",
        variant === "block" && "rounded-md",
        variant === "circle" && "rounded-full",
        className
      )}
      {...props}
    />
  );
}
