import * as React from "react";
import { cn } from "../utils/cn";

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  hasError?: boolean;
}

/** Select — native element, custom-styled (Phase 2.5 §3.6: "custom-styled
 * native select on mobile for OS-native picker UX, custom dropdown on
 * desktop" — this sprint ships the native-everywhere baseline; a
 * desktop-specific custom dropdown is a future polish pass, not required
 * for the foundation to be usable). */
export const Select = React.forwardRef<HTMLSelectElement, SelectProps>(
  ({ className, hasError, children, ...props }, ref) => (
    <select
      ref={ref}
      className={cn(
        "h-11 w-full rounded-sm border bg-neutral-0 px-3 text-body text-neutral-800",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/40",
        "disabled:cursor-not-allowed disabled:opacity-40",
        "dark:bg-surface-dark-1 dark:text-text-dark-primary",
        hasError ? "border-error-500" : "border-neutral-300 dark:border-surface-dark-border",
        className
      )}
      aria-invalid={hasError || undefined}
      {...props}
    >
      {children}
    </select>
  )
);
Select.displayName = "Select";
