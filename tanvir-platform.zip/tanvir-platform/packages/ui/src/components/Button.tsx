import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../utils/cn";

/**
 * Button — shared primitive, Phase 2.5 §3.3.
 *
 * Variants map directly to the design-token-driven Tailwind theme (see
 * packages/config/tailwind and apps/web/tailwind.config.ts) — never a
 * hardcoded color or spacing value here. This is the pattern every future
 * shared component in this package follows.
 *
 * States (default/hover/focus/active/disabled/loading) follow Phase 2.5 §4
 * universally via Tailwind's built-in state variants + the `disabled:` and
 * `aria-busy:` selectors below.
 */
export const buttonVariants = cva(
  [
    "inline-flex items-center justify-center gap-2 rounded-md",
    "text-button font-medium transition-colors",
    "duration-fast ease-standard",
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/40",
    "disabled:pointer-events-none disabled:opacity-40",
    "aria-busy:pointer-events-none aria-busy:opacity-70",
  ].join(" "),
  {
    variants: {
      variant: {
        primary: "bg-accent-500 text-white hover:bg-accent-400 active:bg-accent-600",
        secondary:
          "border border-neutral-300 text-neutral-800 hover:bg-neutral-50 dark:border-surface-dark-border dark:text-text-dark-primary dark:hover:bg-surface-dark-1",
        tertiary:
          "text-neutral-700 underline-offset-4 hover:underline dark:text-text-dark-secondary",
        destructive: "bg-error-500 text-white hover:opacity-90",
      },
      size: {
        sm: "h-9 px-3",
        md: "h-11 px-5",
        lg: "h-13 px-7 text-base",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  loading?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, disabled, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(buttonVariants({ variant, size }), className)}
        disabled={disabled}
        aria-busy={loading || undefined}
        {...props}
      >
        {children}
      </button>
    );
  }
);
Button.displayName = "Button";
