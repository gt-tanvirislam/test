import * as React from "react";
import { cn } from "../utils/cn";
import { Card } from "./Card";

export interface StatCardProps extends React.HTMLAttributes<HTMLDivElement> {
  label: string;
  value: string | number;
  trend?: { direction: "up" | "down"; label: string };
}

/**
 * StatCard — Phase 2.5 §3.4. Used on Dashboard Home once real activity
 * data exists (a future sprint); this establishes the visual pattern now
 * so that sprint only wires data, not design.
 */
export function StatCard({ label, value, trend, className, ...props }: StatCardProps) {
  return (
    <Card className={cn("flex flex-col gap-1", className)} {...props}>
      <span className="text-label uppercase tracking-wide text-neutral-400">{label}</span>
      <span className="text-h2 font-semibold text-neutral-800 dark:text-text-dark-primary">{value}</span>
      {trend && (
        <span
          className={cn(
            "text-caption",
            trend.direction === "up" ? "text-success-500" : "text-error-500"
          )}
        >
          {trend.label}
        </span>
      )}
    </Card>
  );
}
