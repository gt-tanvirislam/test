import * as React from "react";
import { cn } from "../utils/cn";

export interface PageHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}

/**
 * PageHeader — top-of-screen dashboard pattern (Phase 2.4 §4's list-view
 * shell: "New" button top-right, consistent position across every
 * module). Every dashboard list/detail screen composes this rather than
 * hand-rolling its own header row.
 */
export function PageHeader({ title, description, actions, className, ...props }: PageHeaderProps) {
  return (
    <div className={cn("mb-6 flex items-start justify-between gap-4", className)} {...props}>
      <div>
        <h1 className="text-h3 font-semibold text-neutral-800 dark:text-text-dark-primary">{title}</h1>
        {description && (
          <p className="mt-1 text-body-sm text-neutral-500 dark:text-text-dark-secondary">{description}</p>
        )}
      </div>
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </div>
  );
}

export interface SectionHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  eyebrow?: string;
  title: string;
  description?: string;
}

/** SectionHeader — Phase 2.5 §3.2, used to open a public-page section
 * (future sprint) or a dashboard sub-section consistently. */
export function SectionHeader({ eyebrow, title, description, className, ...props }: SectionHeaderProps) {
  return (
    <div className={cn("mb-4", className)} {...props}>
      {eyebrow && (
        <p className="text-label uppercase tracking-wide text-accent-500">{eyebrow}</p>
      )}
      <h2 className="mt-1 text-h4 font-semibold text-neutral-800 dark:text-text-dark-primary">{title}</h2>
      {description && (
        <p className="mt-1 text-body-sm text-neutral-500 dark:text-text-dark-secondary">{description}</p>
      )}
    </div>
  );
}
