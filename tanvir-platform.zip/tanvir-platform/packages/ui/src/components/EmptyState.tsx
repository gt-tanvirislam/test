import * as React from "react";
import { cn } from "../utils/cn";

export interface EmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

/**
 * EmptyState — Phase 2.5 §3.10, Phase 2.4 §20's rule: "every list view's
 * empty state includes a clear next action... never a bare 'no results.'"
 * `action` is a slot (usually a Button) so this stays presentation-only.
 */
export function EmptyState({ icon, title, description, action, className, ...props }: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-2 rounded-md border border-dashed border-neutral-300 px-6 py-16 text-center dark:border-surface-dark-border",
        className
      )}
      {...props}
    >
      {icon && <div className="mb-2 text-neutral-400">{icon}</div>}
      <p className="text-body font-medium text-neutral-700 dark:text-text-dark-primary">{title}</p>
      {description && (
        <p className="max-w-sm text-body-sm text-neutral-500 dark:text-text-dark-secondary">
          {description}
        </p>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
