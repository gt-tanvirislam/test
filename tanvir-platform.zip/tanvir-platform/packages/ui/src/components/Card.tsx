import * as React from "react";
import { cn } from "../utils/cn";

/**
 * Card — shared shell (Phase 2.5 §3.4): radius-md, shadow-sm default,
 * hover lift reserved for interactive card variants built on top of this
 * (PortfolioCard, BlogCard, etc. — future sprints), not applied here
 * since a plain dashboard Card is often static, non-clickable content.
 */
export const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        "rounded-md border border-neutral-200 bg-neutral-0 p-6 shadow-xs",
        "dark:border-surface-dark-border dark:bg-surface-dark-1",
        className
      )}
      {...props}
    />
  )
);
Card.displayName = "Card";

export const CardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("mb-4 flex items-center justify-between", className)} {...props} />
  )
);
CardHeader.displayName = "CardHeader";

export const CardTitle = React.forwardRef<HTMLHeadingElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3
      ref={ref}
      className={cn("text-card-title font-semibold text-neutral-800 dark:text-text-dark-primary", className)}
      {...props}
    />
  )
);
CardTitle.displayName = "CardTitle";
