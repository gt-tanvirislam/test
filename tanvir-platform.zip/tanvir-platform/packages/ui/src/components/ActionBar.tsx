import * as React from "react";
import { cn } from "../utils/cn";

/**
 * ActionBar — the filter bar + bulk-action row above dashboard list views
 * (Phase 2.4 §4). Layout-only; filters/search/bulk-actions are composed
 * into it by the feature component that uses it (e.g. a future
 * BlogListToolbar), not implemented here.
 */
export function ActionBar({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "mb-4 flex flex-wrap items-center justify-between gap-3 rounded-md border border-neutral-200 bg-neutral-50 p-3 dark:border-surface-dark-border dark:bg-surface-dark-1",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}
