"use client";

import * as React from "react";
import { cn } from "../utils/cn";

interface TabsContextValue {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const TabsContext = React.createContext<TabsContextValue | undefined>(undefined);

export interface TabsProps {
  defaultTab: string;
  children: React.ReactNode;
  className?: string;
}

/**
 * Tabs — Phase 2.5 §3.5, underline-indicator style, keyboard-navigable
 * (arrow keys switch tabs per the accessibility requirement). Used by
 * the Content Editor sidebar's Content/SEO/Advanced split (Phase 2.4 §4).
 */
export function Tabs({ defaultTab, children, className }: TabsProps) {
  const [activeTab, setActiveTab] = React.useState(defaultTab);
  return (
    <TabsContext.Provider value={{ activeTab, setActiveTab }}>
      <div className={className}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabsList({ children }: { children: React.ReactNode }) {
  const listRef = React.useRef<HTMLDivElement>(null);

  function handleKeyDown(event: React.KeyboardEvent) {
    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
    const buttons = Array.from(listRef.current?.querySelectorAll<HTMLButtonElement>("[role='tab']") ?? []);
    const currentIndex = buttons.findIndex((b) => b === document.activeElement);
    if (currentIndex === -1) return;
    const nextIndex =
      event.key === "ArrowRight"
        ? (currentIndex + 1) % buttons.length
        : (currentIndex - 1 + buttons.length) % buttons.length;
    buttons[nextIndex]?.focus();
    buttons[nextIndex]?.click();
  }

  return (
    <div
      ref={listRef}
      role="tablist"
      onKeyDown={handleKeyDown}
      className="flex gap-4 border-b border-neutral-200 dark:border-surface-dark-border"
    >
      {children}
    </div>
  );
}

export function TabsTrigger({ value, children }: { value: string; children: React.ReactNode }) {
  const ctx = React.useContext(TabsContext);
  if (!ctx) throw new Error("TabsTrigger must be used within Tabs");
  const isActive = ctx.activeTab === value;

  return (
    <button
      type="button"
      role="tab"
      aria-selected={isActive}
      tabIndex={isActive ? 0 : -1}
      onClick={() => ctx.setActiveTab(value)}
      className={cn(
        "border-b-2 px-1 pb-2 text-body-sm font-medium transition-colors",
        isActive
          ? "border-accent-500 text-neutral-800 dark:text-text-dark-primary"
          : "border-transparent text-neutral-500 hover:text-neutral-700 dark:text-text-dark-secondary"
      )}
    >
      {children}
    </button>
  );
}

export function TabsContent({ value, children }: { value: string; children: React.ReactNode }) {
  const ctx = React.useContext(TabsContext);
  if (!ctx) throw new Error("TabsContent must be used within Tabs");
  if (ctx.activeTab !== value) return null;

  return (
    <div role="tabpanel" className="pt-4">
      {children}
    </div>
  );
}
