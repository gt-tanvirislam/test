import * as React from "react";
import { cn } from "../utils/cn";

/**
 * Table foundation (Phase 2.5 §3.7). Sortable-column and bulk-select
 * behavior are added by the feature that wraps this (a future DataTable
 * built for Blog/Portfolio/Media list views) — this sprint only
 * establishes the semantic, accessible markup shell (Phase 2.10 §11:
 * "proper <th>/scope usage... a table used purely for visual layout is
 * never acceptable").
 */
export function Table({ className, ...props }: React.TableHTMLAttributes<HTMLTableElement>) {
  return (
    <div className="w-full overflow-x-auto rounded-md border border-neutral-200 dark:border-surface-dark-border">
      <table className={cn("w-full border-collapse text-body-sm", className)} {...props} />
    </div>
  );
}

export function TableHead({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) {
  return (
    <thead
      className={cn("bg-neutral-50 text-left dark:bg-surface-dark-1", className)}
      {...props}
    />
  );
}

export function TableHeaderCell({ className, ...props }: React.ThHTMLAttributes<HTMLTableCellElement>) {
  return (
    <th
      scope="col"
      className={cn(
        "px-4 py-3 text-label uppercase tracking-wide text-neutral-500 dark:text-text-dark-secondary",
        className
      )}
      {...props}
    />
  );
}

export function TableBody({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) {
  return <tbody className={cn("divide-y divide-neutral-200 dark:divide-surface-dark-border", className)} {...props} />;
}

export function TableRow({ className, ...props }: React.HTMLAttributes<HTMLTableRowElement>) {
  return (
    <tr
      className={cn("hover:bg-neutral-50 dark:hover:bg-surface-dark-1", className)}
      {...props}
    />
  );
}

export function TableCell({ className, ...props }: React.TdHTMLAttributes<HTMLTableCellElement>) {
  return (
    <td
      className={cn("px-4 py-3 text-neutral-700 dark:text-text-dark-secondary", className)}
      {...props}
    />
  );
}
