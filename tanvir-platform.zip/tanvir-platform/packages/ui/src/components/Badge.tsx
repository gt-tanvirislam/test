import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../utils/cn";

const badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-caption font-medium", {
  variants: {
    tone: {
      neutral: "bg-neutral-100 text-neutral-600 dark:bg-surface-dark-2 dark:text-text-dark-secondary",
      accent: "bg-accent-50 text-accent-600 dark:bg-surface-dark-2 dark:text-accent-400",
      success: "bg-success-50 text-success-500",
      warning: "bg-warning-50 text-warning-500",
      error: "bg-error-50 text-error-500",
    },
  },
  defaultVariants: { tone: "neutral" },
});

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement>, VariantProps<typeof badgeVariants> {}

/**
 * Badge — status indicators, category labels, tag pills (Phase 2.5
 * §3.7). Status→tone mapping (draft/published/scheduled/archived) is
 * decided by the consuming module (PublishPanel below), not hardcoded
 * here, since this component has no opinion on content-status semantics.
 */
export function Badge({ tone, className, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ tone }), className)} {...props} />;
}
