import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Merges Tailwind class lists safely (later classes override earlier
 * conflicting ones). Standard shadcn/ui utility — used by every component
 * in this package so consumers can override styles predictably via
 * `className` props without specificity fights.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
